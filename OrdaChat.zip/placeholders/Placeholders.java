package placeholders;

import config.GroupManager;
import config.TagsManager;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import me.clip.placeholderapi.PlaceholderAPI;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class Placeholders extends PlaceholderExpansion {
   private final GroupManager groupManager;
   private final OrdaChat plugin;

   public Placeholders(OrdaChat plugin, GroupManager groupManager) {
      this.plugin = plugin;
      this.groupManager = groupManager;
   }

   @NotNull
   public String getIdentifier() {
      return "tchat";
   }

   @NotNull
   public String getAuthor() {
      return this.plugin.getDescription().getAuthors().toString();
   }

   @NotNull
   public String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public boolean canRegister() {
      return true;
   }

   @Nullable
   public String onPlaceholderRequest(Player player, @NotNull String identifier) {
      if (player == null) {
         return "";
      } else {
         UUID playerId = player.getUniqueId();
         if (identifier.startsWith("chatgames_wins_top_")) {
            String topNumberStr = identifier.replace("chatgames_wins_top_", "");

            try {
               int topNumber = Integer.parseInt(topNumberStr);
               return this.getTopChatGamesWinsPlayer(topNumber);
            } catch (NumberFormatException var6) {
               return "Invalid number";
            }
         } else {
            byte var5 = -1;
            switch(identifier.hashCode()) {
            case -2074875608:
               if (identifier.equals("tag_displayname")) {
                  var5 = 18;
               }
               break;
            case -1406349009:
               if (identifier.equals("chatcolor_color")) {
                  var5 = 4;
               }
               break;
            case -1268779017:
               if (identifier.equals("format")) {
                  var5 = 15;
               }
               break;
            case -980110702:
               if (identifier.equals("prefix")) {
                  var5 = 0;
               }
               break;
            case -891422895:
               if (identifier.equals("suffix")) {
                  var5 = 1;
               }
               break;
            case -574389833:
               if (identifier.equals("group_format")) {
                  var5 = 16;
               }
               break;
            case -561082453:
               if (identifier.equals("chatcolor_format")) {
                  var5 = 5;
               }
               break;
            case -87028691:
               if (identifier.equals("chatgames_wins")) {
                  var5 = 9;
               }
               break;
            case 3832:
               if (identifier.equals("xp")) {
                  var5 = 7;
               }
               break;
            case 114586:
               if (identifier.equals("tag")) {
                  var5 = 17;
               }
               break;
            case 3381091:
               if (identifier.equals("nick")) {
                  var5 = 12;
               }
               break;
            case 3441010:
               if (identifier.equals("ping")) {
                  var5 = 10;
               }
               break;
            case 98629247:
               if (identifier.equals("group")) {
                  var5 = 2;
               }
               break;
            case 102865796:
               if (identifier.equals("level")) {
                  var5 = 8;
               }
               break;
            case 260666013:
               if (identifier.equals("staff_list")) {
                  var5 = 14;
               }
               break;
            case 738950403:
               if (identifier.equals("channel")) {
                  var5 = 6;
               }
               break;
            case 1129952854:
               if (identifier.equals("ping_color")) {
                  var5 = 11;
               }
               break;
            case 1460083080:
               if (identifier.equals("staff_number")) {
                  var5 = 13;
               }
               break;
            case 1538342635:
               if (identifier.equals("ignore_list")) {
                  var5 = 19;
               }
               break;
            case 1623651083:
               if (identifier.equals("chatcolor")) {
                  var5 = 3;
               }
            }

            String var10000;
            switch(var5) {
            case 0:
               var10000 = this.groupManager.getGroupPrefix(player);
               break;
            case 1:
               var10000 = this.groupManager.getGroupSuffix(player);
               break;
            case 2:
               var10000 = this.groupManager.getGroupName(player);
               break;
            case 3:
               var10000 = this.plugin.getSaveManager().getChatColor(playerId) + this.plugin.getSaveManager().getFormat(playerId);
               break;
            case 4:
               var10000 = this.plugin.getSaveManager().getChatColor(playerId);
               break;
            case 5:
               var10000 = this.plugin.getSaveManager().getFormat(playerId);
               break;
            case 6:
               var10000 = this.getChannel(player);
               break;
            case 7:
               var10000 = String.valueOf(this.plugin.getSaveManager().getXp(playerId));
               break;
            case 8:
               var10000 = String.valueOf(this.plugin.getSaveManager().getLevel(playerId));
               break;
            case 9:
               var10000 = String.valueOf(this.plugin.getSaveManager().getChatGamesWins(playerId));
               break;
            case 10:
               var10000 = this.plugin.getConfigManager().getColorForPing(player.getPing()) + player.getPing();
               break;
            case 11:
               var10000 = this.plugin.getConfigManager().getColorForPing(player.getPing());
               break;
            case 12:
               var10000 = this.plugin.getSaveManager().getNick(playerId, player);
               break;
            case 13:
               var10000 = String.valueOf(this.getStaffNumber());
               break;
            case 14:
               var10000 = this.getStaffList();
               break;
            case 15:
               var10000 = this.getFormat(player);
               break;
            case 16:
               var10000 = this.getGroupFormat(player);
               break;
            case 17:
               var10000 = this.plugin.getSaveManager().getSelectedTag(playerId);
               break;
            case 18:
               var10000 = this.getTagDisplayName(playerId);
               break;
            case 19:
               var10000 = this.getIgnoreList(playerId);
               break;
            default:
               var10000 = null;
            }

            return var10000;
         }
      }
   }

   @NotNull
   private String getIgnoreList(UUID playerId) {
      List<String> ignoreList = this.plugin.getSaveManager().getIgnoreList(playerId);
      return ignoreList.isEmpty() ? "No players ignored" : (String)ignoreList.stream().map(UUID::fromString).map((uuid) -> {
         return this.plugin.getServer().getOfflinePlayer(uuid).getName();
      }).collect(Collectors.joining(", "));
   }

   private String getTagDisplayName(UUID playerId) {
      String tagName = this.plugin.getSaveManager().getSelectedTag(playerId);
      TagsManager.Tag tag = (TagsManager.Tag)this.plugin.getTagsManager().getTags().get(tagName);
      return tag.getDisplay();
   }

   @NotNull
   private String getFormat(Player player) {
      String format = this.plugin.getConfigManager().getFormat().replace("¡", "");
      format = PlaceholderAPI.setPlaceholders(player, format);
      return format;
   }

   @NotNull
   private String getGroupFormat(Player player) {
      String channelName = this.plugin.getGroupManager().getGroupName(player);
      String groupFormat = this.plugin.getGroupManager().getGroupFormat(channelName).replace("¡", "");
      groupFormat = PlaceholderAPI.setPlaceholders(player, groupFormat);
      return groupFormat;
   }

   @NotNull
   private String getChannel(Player player) {
      String channel = this.plugin.getChannelsManager().getPlayerChannel(player);
      return channel != null ? channel : "null";
   }

   @NotNull
   private String getTopChatGamesWinsPlayer(int topNumber) {
      List<UUID> allPlayers = this.plugin.getSaveManager().getAllPlayerUUIDs();
      List<UUID> sortedPlayers = allPlayers.stream().sorted((p1, p2) -> {
         return Integer.compare(this.plugin.getSaveManager().getChatGamesWins(p2), this.plugin.getSaveManager().getChatGamesWins(p1));
      }).toList();
      if (topNumber > 0 && topNumber <= sortedPlayers.size()) {
         UUID topPlayerId = (UUID)sortedPlayers.get(topNumber - 1);
         return (String)Objects.requireNonNull(Bukkit.getOfflinePlayer(topPlayerId).getName());
      } else {
         return "No data";
      }
   }

   private int getStaffNumber() {
      return (int)Bukkit.getOnlinePlayers().stream().filter((p) -> {
         return p.hasPermission("tchat.admin") || p.hasPermission("tchat.staff") || p.isOp();
      }).count();
   }

   @NotNull
   private String getStaffList() {
      List<String> staffList = Bukkit.getOnlinePlayers().stream().filter((p) -> {
         return p.hasPermission("tchat.admin") || p.hasPermission("tchat.staff") || p.isOp();
      }).map(Player::getName).toList();
      return staffList.isEmpty() ? "No staff online" : String.join(", ", staffList);
   }
}
