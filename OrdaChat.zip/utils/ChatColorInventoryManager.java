package utils;

import config.ChatColorManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;

public class ChatColorInventoryManager implements Listener {
   private final OrdaChat plugin;
   private final Map<Player, Long> lastClickMap = new HashMap();

   public ChatColorInventoryManager(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public void openInventory(Player player, String title) {
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, this.plugin.getChatColorManager().getSlots(), this.plugin.getTranslateColors().translateColors(player, title));
      this.setBorderItems(player, inv);
      this.setMenuItems(inv, player);
      Bukkit.getPluginManager().registerEvents(this, this.plugin);
      player.openInventory(inv);
   }

   private void setBorderItems(Player player, Inventory inv) {
      this.setBorderItem(player, this.plugin.getChatColorManager().getAddTop(), inv, this.plugin.getChatColorManager().getStartTop(), this.plugin.getChatColorManager().getEndTop(), this.plugin.getChatColorManager().getTopMaterial(), this.plugin.getChatColorManager().getAmountTop(), this.plugin.getChatColorManager().getTopName(), this.plugin.getChatColorManager().getLoreTop());
      this.setBorderItem(player, this.plugin.getChatColorManager().getAddLeft(), inv, this.plugin.getChatColorManager().getStartLeft(), this.plugin.getChatColorManager().getEndLeft(), this.plugin.getChatColorManager().getLeftMaterial(), this.plugin.getChatColorManager().getAmountLeft(), this.plugin.getChatColorManager().getLeftName(), this.plugin.getChatColorManager().getLoreLeft());
      this.setBorderItem(player, this.plugin.getChatColorManager().getAddRight(), inv, this.plugin.getChatColorManager().getStartRight(), this.plugin.getChatColorManager().getEndRight(), this.plugin.getChatColorManager().getRightMaterial(), this.plugin.getChatColorManager().getAmountRight(), this.plugin.getChatColorManager().getRightName(), this.plugin.getChatColorManager().getLoreRight());
      this.setBorderItem(player, this.plugin.getChatColorManager().getAddBottom(), inv, this.plugin.getChatColorManager().getStartBottom(), this.plugin.getChatColorManager().getEndBottom(), this.plugin.getChatColorManager().getBottomMaterial(), this.plugin.getChatColorManager().getAmountBottom(), this.plugin.getChatColorManager().getBottomName(), this.plugin.getChatColorManager().getLoreBottom());
      this.setItem(player, inv, this.plugin.getChatColorManager().getCloseSlot(), this.plugin.getChatColorManager().getCloseMaterial(), this.plugin.getChatColorManager().getAmountClose(), this.plugin.getChatColorManager().getCloseName(), this.plugin.getChatColorManager().getLoreClose());
   }

   private void setBorderItem(Player player, int add, Inventory inv, int startSlot, int endSlot, Material material, int amount, String name, List<String> loreMessages) {
      ItemStack item = this.createItem(player, material, amount, name, loreMessages, "border_item");

      for(int i = startSlot; i <= endSlot; i += add) {
         inv.setItem(i, item);
      }

   }

   private void setMenuItems(Inventory inv, Player player) {
      ChatColorManager chatColorManager = this.plugin.getChatColorManager();
      Iterator var4 = chatColorManager.items.entrySet().iterator();

      while(var4.hasNext()) {
         Entry<String, ChatColorManager.ChatColorItem> entry = (Entry)var4.next();
         String key = (String)entry.getKey();
         ChatColorManager.ChatColorItem item = (ChatColorManager.ChatColorItem)entry.getValue();
         Material material = Material.getMaterial(item.getMaterial());
         if (material == null) {
            String message = this.plugin.getMessagesManager().getMaterialNotFound();
            String prefix = this.plugin.getMessagesManager().getPrefix();
            Bukkit.getConsoleSender().sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message).replace("%material%", item.getMaterial()));
         } else {
            int slot = item.getSlot();
            int amount = item.getAmount();
            List<String> loreMessages = player.hasPermission("tchat.chatcolor." + key) ? item.getLorePerm() : item.getLoreNoPerm();
            ItemStack itemStack = this.createItem(player, material, amount, item.getName(), loreMessages, "menu_item");
            inv.setItem(slot, itemStack);
         }
      }

   }

   private void setItem(Player player, @NotNull Inventory inv, int slot, Material material, int amount, String name, List<String> loreMessages) {
      ItemStack item = this.createItem(player, material, amount, name, loreMessages, "menu_item");
      inv.setItem(slot, item);
   }

   @NotNull
   private ItemStack createItem(Player player, Material material, int amount, String name, List<String> loreMessages, String id) {
      ItemStack item = new ItemStack(material, amount);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(this.plugin.getTranslateColors().translateColors(player, name));
         List<String> lore = new ArrayList();
         Iterator var10 = loreMessages.iterator();

         while(var10.hasNext()) {
            String msg = (String)var10.next();
            lore.add(this.plugin.getTranslateColors().translateColors(player, msg));
         }

         meta.setLore(lore);
         meta.getPersistentDataContainer().set(new NamespacedKey(this.plugin, id), PersistentDataType.STRING, id);
         item.setItemMeta(meta);
      }

      return item;
   }

   @EventHandler
   public void onInventoryClick(@NotNull InventoryClickEvent event) {
      if (this.plugin.getConfigManager().isChatColorMenuEnabled()) {
         String inventory = event.getView().getTitle().replace("§", "&");
         if (inventory.equals(this.plugin.getChatColorManager().getTitle())) {
            event.setCancelled(true);
            HumanEntity var4 = event.getWhoClicked();
            if (var4 instanceof Player) {
               Player player = (Player)var4;
               long currentTime = System.currentTimeMillis();
               Long lastClickTime = (Long)this.lastClickMap.get(player);
               long COOLDOWN = this.plugin.getChatColorManager().getCooldown();
               if (lastClickTime == null || currentTime - lastClickTime >= COOLDOWN) {
                  this.lastClickMap.put(player, currentTime);
                  ItemStack clickedItem = event.getCurrentItem();
                  if (clickedItem != null && clickedItem.hasItemMeta()) {
                     ItemMeta meta = clickedItem.getItemMeta();
                     if (meta != null && meta.hasDisplayName()) {
                        String displayName = ChatColor.stripColor(meta.getDisplayName());
                        String itemKey = displayName.toLowerCase().replace(" ", "_");
                        int closeSlot = this.plugin.getChatColorManager().getCloseSlot();
                        if (event.getSlot() == closeSlot) {
                           player.closeInventory();
                        } else {
                           ChatColorManager.ChatColorItem item = this.plugin.getChatColorManager().getItem(itemKey);
                           if (item != null) {
                              String id = item.getId();
                              String permission = "tchat.chatcolor." + itemKey;
                              String prefix = this.plugin.getMessagesManager().getPrefix();
                              String message;
                              if (!player.hasPermission(permission) && !player.hasPermission("tchat.admin") && !player.hasPermission("tchat.chatcolor.all")) {
                                 message = this.plugin.getMessagesManager().getNoPermission();
                                 player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                              } else {
                                 String message;
                                 if (id.matches("&[0-9a-f]")) {
                                    this.plugin.getSaveManager().setChatColor(player.getUniqueId(), id);
                                    message = this.plugin.getSaveManager().getFormat(player.getUniqueId());
                                    message = this.plugin.getMessagesManager().getColorSelectedMessage().replace("%id%", id).replace("%color%", itemKey).replace("%format%", message);
                                    player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                                 } else if (id.matches("&[k-o&r]")) {
                                    this.plugin.getSaveManager().setFormat(player.getUniqueId(), id);
                                    message = this.plugin.getSaveManager().getChatColor(player.getUniqueId());
                                    message = this.plugin.getMessagesManager().getFormatSelectedMessage().replace("%id%", id).replace("%format%", itemKey).replace("%color%", message);
                                    player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                                 } else if (id.equalsIgnoreCase("reset")) {
                                    this.plugin.getSaveManager().removeFormat(player.getUniqueId());
                                    this.plugin.getSaveManager().removeChatColor(player.getUniqueId());
                                    message = this.plugin.getMessagesManager().getColorReset();
                                    player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                                 } else {
                                    message = this.plugin.getMessagesManager().getInvalidIdMessage();
                                    player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                                 }
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }
}
