package utils;

import java.util.HashMap;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.jetbrains.annotations.NotNull;

public class BlockBreakGame implements Listener {
   private final OrdaChat plugin;
   private final Material blockType;
   private final int requiredAmount;
   private final Map<Player, Integer> playerBreakCounts;

   public BlockBreakGame(@NotNull OrdaChat plugin, Material blockType, int requiredAmount) {
      this.plugin = plugin;
      this.blockType = blockType;
      this.requiredAmount = requiredAmount;
      this.playerBreakCounts = new HashMap();
      plugin.getServer().getPluginManager().registerEvents(this, plugin);
   }

   @EventHandler
   public void onBlockBreak(@NotNull BlockBreakEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getChatGamesSender().isGameActive()) {
         if (event.getBlock().getType() == this.blockType) {
            int currentCount = (Integer)this.playerBreakCounts.getOrDefault(player, 0) + 1;
            this.playerBreakCounts.put(player, currentCount);
            if (currentCount >= this.requiredAmount) {
               this.plugin.getChatGamesSender().notifyWinner(player);
               this.cleanup();
            }
         }

      }
   }

   private void cleanup() {
      BlockBreakEvent.getHandlerList().unregister(this);
   }
}
