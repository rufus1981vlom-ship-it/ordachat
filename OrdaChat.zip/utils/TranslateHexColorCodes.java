package utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jetbrains.annotations.NotNull;

public class TranslateHexColorCodes {
   @NotNull
   public static String translateHexColorCodes(String startTag, String endTag, String message) {
      Pattern hexPattern = Pattern.compile(startTag + "([A-Fa-f0-9]{6})" + endTag);
      Matcher matcher = hexPattern.matcher(message);
      StringBuilder buffer = new StringBuilder(message.length() + 32);

      while(matcher.find()) {
         String group = matcher.group(1);
         char var10002 = group.charAt(0);
         matcher.appendReplacement(buffer, "§x§" + var10002 + "§" + group.charAt(1) + "§" + group.charAt(2) + "§" + group.charAt(3) + "§" + group.charAt(4) + "§" + group.charAt(5));
      }

      return matcher.appendTail(buffer).toString();
   }
}
