package utils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.bukkit.entity.Player;

public class ChannelsManager {
   private final Map<Player, String> playerChannels = new HashMap();

   public void setPlayerChannel(Player player, String channelName) {
      this.playerChannels.put(player, channelName);
   }

   public String getPlayerChannel(Player player) {
      return (String)this.playerChannels.get(player);
   }

   public boolean isPlayerInChannel(Player player) {
      return this.playerChannels.containsKey(player);
   }

   public int getChannelPlayerCount(String channelName) {
      int count = 0;
      Iterator var3 = this.playerChannels.values().iterator();

      while(var3.hasNext()) {
         String channel = (String)var3.next();
         if (channel.equalsIgnoreCase(channelName)) {
            ++count;
         }
      }

      return count;
   }

   public void removePlayerFromChannel(Player player) {
      this.playerChannels.remove(player);
   }

   public Set<Player> getPlayersInChannel(String channelName) {
      Set<Player> playersInChannel = new HashSet();
      Iterator var3 = this.playerChannels.entrySet().iterator();

      while(var3.hasNext()) {
         Entry<Player, String> entry = (Entry)var3.next();
         if (((String)entry.getValue()).equalsIgnoreCase(channelName)) {
            playersInChannel.add((Player)entry.getKey());
         }
      }

      return playersInChannel;
   }
}
