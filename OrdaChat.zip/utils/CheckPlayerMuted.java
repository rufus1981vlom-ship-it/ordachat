package utils;

import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;

public class CheckPlayerMuted {
   private final OrdaChat plugin;

   public CheckPlayerMuted(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public void checkMuted(@NotNull AsyncPlayerChatEvent e) {
      Player p = e.getPlayer();
      if (!p.hasPermission("tchat.admin") && !p.hasPermission("tchat.bypass.mute") && this.plugin.getSaveManager().isPlayerMuted(p.getUniqueId())) {
         String prefix = this.plugin.getMessagesManager().getPrefix();
         String m = this.plugin.getMessagesManager().getMuted();
         p.sendMessage(this.plugin.getTranslateColors().translateColors(p, prefix + m));
         e.setCancelled(true);
      }

   }
}
