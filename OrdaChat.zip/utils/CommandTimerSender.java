package utils;

import config.CommandTimerManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.jetbrains.annotations.NotNull;

public class CommandTimerSender {
   private final OrdaChat plugin;
   private final CommandTimerManager commandTimerManager;
   private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
   private final List<String> commandKeys = new ArrayList();
   private int currentIndex = 0;

   public CommandTimerSender(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.commandTimerManager = plugin.getCommandTimerManager();
      this.initializeCommands();
   }

   private void initializeCommands() {
      Map<String, CommandTimerManager.CommandConfig> commandConfigMap = this.commandTimerManager.getCommandConfig();
      this.commandKeys.addAll(commandConfigMap.keySet());
      long interval = (long)this.commandTimerManager.getTime();
      this.scheduler.scheduleAtFixedRate(this::executeNextCommand, 0L, interval, TimeUnit.SECONDS);
   }

   private void executeNextCommand() {
      if (!this.commandKeys.isEmpty()) {
         String currentKey = (String)this.commandKeys.get(this.currentIndex);
         CommandTimerManager.CommandConfig config = (CommandTimerManager.CommandConfig)this.commandTimerManager.getCommandConfig().get(currentKey);
         if (config != null && config.isEnabled()) {
            Iterator var3 = config.getCommands().iterator();

            while(var3.hasNext()) {
               String command = (String)var3.next();
               this.executeCommand(command);
            }
         }

         this.currentIndex = (this.currentIndex + 1) % this.commandKeys.size();
      }
   }

   private void executeCommand(String command) {
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         String playerCommand;
         if (command.startsWith("[CONSOLE]")) {
            playerCommand = command.substring("[CONSOLE]".length()).trim();
            Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), playerCommand);
         } else if (command.startsWith("[PLAYER]")) {
            playerCommand = command.substring("[PLAYER]".length()).trim();
            Bukkit.getOnlinePlayers().stream().findFirst().ifPresent((player) -> {
               player.performCommand(playerCommand);
            });
         }

      });
   }

   public void stop() {
      this.scheduler.shutdown();
   }
}
