package utils;

import config.ChatGamesManager;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

public class ChatGamesSender {
   private final OrdaChat plugin;
   private int currentGameIndex = 0;
   private ChatGamesManager.Game currentGame;
   private BukkitRunnable countdownTask;
   private final Set<String> winners;
   private boolean gameActive;

   public ChatGamesSender(OrdaChat plugin) {
      this.plugin = plugin;
      this.winners = new HashSet();
      this.startNextGame();
   }

   public void startNextGame() {
      if (!this.gameActive) {
         final String prefix = this.plugin.getMessagesManager().getPrefix();
         List<ChatGamesManager.Game> games = this.plugin.getChatGamesManager().getGames();
         if (!games.isEmpty()) {
            do {
               this.currentGame = (ChatGamesManager.Game)games.get(this.currentGameIndex);
               this.currentGameIndex = (this.currentGameIndex + 1) % games.size();
            } while(!this.currentGame.isEnabled() && this.currentGameIndex != 0);

            String message;
            if (!this.currentGame.isEnabled()) {
               message = this.plugin.getMessagesManager().getNoEnabledGames();
               this.sendToAllPlayers(prefix + message);
            } else {
               assert this.winners != null;

               this.winners.clear();
               this.gameActive = true;
               this.showStartEffects();
               Iterator var5;
               if (this.currentGame.getMessages() != null && !this.currentGame.getMessages().isEmpty()) {
                  var5 = Bukkit.getOnlinePlayers().iterator();

                  while(var5.hasNext()) {
                     Player player = (Player)var5.next();
                     this.sendMessagesWithEffects(player, this.currentGame.getMessages(), this.currentGame.isHoverEnabled(), this.currentGame.getHover(), this.currentGame.isActionEnabled(), this.currentGame.getAction());
                  }
               } else {
                  message = this.plugin.getMessagesManager().getNoMessages();
                  this.sendToAllPlayers(prefix + message);
               }

               var5 = this.currentGame.getKeywords().iterator();

               while(var5.hasNext()) {
                  String keyword = (String)var5.next();
                  if (keyword.startsWith("[BREAK]")) {
                     this.startBlockBreakGame(keyword);
                     break;
                  }
               }

               this.countdownTask = new BukkitRunnable() {
                  public void run() {
                     String var10001 = prefix;
                     ChatGamesSender.this.sendToAllPlayers(var10001 + ChatGamesSender.this.plugin.getMessagesManager().getTimeFinished());
                     ChatGamesSender.this.endGame();
                  }
               };
               this.countdownTask.runTaskLater(this.plugin, (long)this.currentGame.getOptions().getEndTime() * 20L);
            }
         }
      }
   }

   private void endGame() {
      this.stopGame();
      this.showEndEffects();
      BukkitRunnable endGameTask = new BukkitRunnable() {
         public void run() {
            ChatGamesSender.this.startNextGame();
         }
      };
      endGameTask.runTaskLater(this.plugin, (long)this.currentGame.getOptions().getTime() * 20L);
   }

   private void showStartEffects() {
      this.showEffects(this.currentGame.getStartEffects(), (Player)null);
   }

   private void showEndEffects() {
      Iterator var1 = Bukkit.getOnlinePlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         if (this.winners.contains(player.getName())) {
            this.showEffects(this.currentGame.getWinnerEffects(), player);
         } else {
            this.showEffects(this.currentGame.getEndEffects(), player);
         }
      }

   }

   private void showEffects(@NotNull ChatGamesManager.Effects effects, Player winner) {
      TranslateColors translateColors = this.plugin.getTranslateColors();
      if (translateColors != null) {
         if (effects.getTitle().isEnabled()) {
            String titleText = translateColors.translateColors(winner, effects.getTitle().getText());
            String subtitleText = translateColors.translateColors(winner, effects.getTitle().getSubtitle());
            if (titleText.contains("%winner%") && winner != null) {
               titleText = titleText.replace("%winner%", winner.getName());
            }

            if (subtitleText.contains("%winner%") && winner != null) {
               subtitleText = subtitleText.replace("%winner%", winner.getName());
            }

            Iterator var6 = Bukkit.getOnlinePlayers().iterator();

            while(var6.hasNext()) {
               Player player = (Player)var6.next();
               player.sendTitle(titleText, subtitleText, effects.getTitle().getFadeIn(), effects.getTitle().getStay(), effects.getTitle().getFadeOut());
            }
         }

         Iterator var13;
         Player player;
         if (effects.getSound().isEnabled()) {
            try {
               Sound sound = Sound.valueOf(effects.getSound().getName().toUpperCase());
               var13 = Bukkit.getOnlinePlayers().iterator();

               while(var13.hasNext()) {
                  player = (Player)var13.next();
                  player.playSound(player.getLocation(), sound, effects.getSound().getVolume(), effects.getSound().getPitch());
               }
            } catch (IllegalArgumentException var9) {
               this.plugin.getLogger().warning("Invalid sound name: " + effects.getSound().getName());
            }
         }

         if (effects.getParticle().isEnabled()) {
            try {
               Particle particle = Particle.valueOf(effects.getParticle().getName().toUpperCase());
               var13 = Bukkit.getOnlinePlayers().iterator();

               while(var13.hasNext()) {
                  player = (Player)var13.next();
                  player.getWorld().spawnParticle(particle, player.getLocation(), effects.getParticle().getCount(), 0.5D, 0.5D, 0.5D, effects.getParticle().getSpeed());
               }
            } catch (IllegalArgumentException var8) {
               this.plugin.getLogger().warning("Invalid particle name: " + effects.getParticle().getName());
            }
         }

         if (effects.getActionBar().isEnabled()) {
            Iterator var12 = Bukkit.getOnlinePlayers().iterator();

            while(var12.hasNext()) {
               Player player = (Player)var12.next();
               String bar = effects.getActionBar().getText();
               player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(this.plugin.getTranslateColors().translateColors(player, bar)));
            }
         }

      }
   }

   public void checkPlayerResponse(Player player, String message) {
      if (this.currentGame != null && this.gameActive) {
         if (!this.winners.contains(player.getName())) {
            List<String> keywords = this.currentGame.getKeywords();
            Iterator var4 = keywords.iterator();

            while(var4.hasNext()) {
               String keyword = (String)var4.next();
               if (keyword.startsWith("[WRITE]")) {
                  String cleanedKeyword = keyword.substring(7).trim();
                  if (cleanedKeyword.equalsIgnoreCase(message)) {
                     this.notifyWinner(player);
                     return;
                  }
               }
            }

         }
      }
   }

   public void notifyWinner(@NotNull Player player) {
      String winMessage = this.plugin.getMessagesManager().getGameWin();
      winMessage = winMessage.replace("%player%", player.getName());
      String prefix = this.plugin.getMessagesManager().getPrefix();
      this.sendToAllPlayers(prefix + winMessage);
      this.winners.add(player.getName());
      UUID playerId = player.getUniqueId();
      int wins = this.plugin.getSaveManager().getChatGamesWins(playerId);
      ++wins;
      this.plugin.getSaveManager().setChatGamesWins(playerId, wins);
      this.executeRewards(player);
      this.showEffects(this.currentGame.getWinnerEffects(), player);
      this.showEffects(this.currentGame.getEndEffects(), (Player)null);
      this.endGame();
   }

   private void startBlockBreakGame(@NotNull String keyword) {
      String[] parts = keyword.split(" ");
      if (parts.length == 3) {
         Material blockType = Material.matchMaterial(parts[1].toUpperCase());

         int requiredAmount;
         try {
            requiredAmount = Integer.parseInt(parts[2]);
         } catch (NumberFormatException var6) {
            this.plugin.getLogger().warning("Invalid amount specified in [BREAK] command.");
            return;
         }

         if (blockType != null) {
            new BlockBreakGame(this.plugin, blockType, requiredAmount);
         } else {
            this.plugin.getLogger().warning("Invalid block type specified in [BREAK] command.");
         }
      } else {
         this.plugin.getLogger().warning("Invalid format for [BREAK] command. Expected: [BREAK] BLOCK_TYPE AMOUNT");
      }

   }

   private String centerText(String message) {
      int maxLength = true;
      String strippedMessage = ChatColor.stripColor(message);
      int length = strippedMessage.length();
      if (length >= 56) {
         return message;
      } else {
         int spaces = (56 - length) / 2;
         StringBuilder centeredMessage = new StringBuilder();
         centeredMessage.append(" ".repeat(spaces));
         centeredMessage.append(message);

         while(centeredMessage.length() < 56) {
            centeredMessage.append(" ");
         }

         return centeredMessage.toString();
      }
   }

   public void stopGame() {
      if (this.gameActive) {
         if (this.countdownTask != null) {
            this.countdownTask.cancel();
            this.countdownTask = null;
         }

         this.gameActive = false;
      }
   }

   public void restartGame() {
      this.stopGame();
      this.currentGameIndex = 0;
      this.startNextGame();
   }

   private void executeRewards(Player player) {
      if (this.currentGame.getRewards() != null) {
         Iterator var2 = this.currentGame.getRewards().iterator();

         while(var2.hasNext()) {
            String reward = (String)var2.next();
            String command = reward.replace("%winner%", player.getName());
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
            });
         }
      }

   }

   private void sendToAllPlayers(String message) {
      Iterator var2 = Bukkit.getOnlinePlayers().iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, message));
      }

   }

   private void applyHoverAndAction(TextComponent textComponent, boolean hoverEnabled, List<String> hoverLines, boolean actionEnabled, String action, String playerName) {
      if (hoverEnabled) {
         List<String> translatedHoverLines = new ArrayList();
         Iterator var8 = hoverLines.iterator();

         while(var8.hasNext()) {
            String line = (String)var8.next();
            String translatedLine = this.plugin.getTranslateColors().translateColors((Player)null, line);
            translatedHoverLines.add(translatedLine);
         }

         String hoverText = String.join("\n", translatedHoverLines);
         textComponent.setHoverEvent(new HoverEvent(Action.SHOW_TEXT, (new ComponentBuilder(hoverText)).create()));
      }

      if (actionEnabled) {
         this.applyClickAction(textComponent, action, playerName);
      }

   }

   @NotNull
   private TextComponent processMessage(@NotNull String message, boolean hoverEnabled, List<String> hoverLines, boolean actionEnabled, String action, String playerName) {
      if (message.contains("%center%")) {
         message = message.replace("%center%", "");
         message = this.centerText(message);
      }

      TextComponent textComponent = new TextComponent(message);
      this.applyHoverAndAction(textComponent, hoverEnabled, hoverLines, actionEnabled, action, playerName);
      return textComponent;
   }

   private void sendMessagesWithEffects(Player player, @NotNull List<String> messages, boolean hoverEnabled, List<String> hoverLines, boolean actionEnabled, String action) {
      Iterator var7 = messages.iterator();

      while(var7.hasNext()) {
         String message = (String)var7.next();
         message = this.plugin.getTranslateColors().translateColors(player, message);
         TextComponent textComponent = this.processMessage(message, hoverEnabled, hoverLines, actionEnabled, action, player.getName());
         player.spigot().sendMessage(textComponent);
      }

   }

   private void applyClickAction(TextComponent component, @NotNull String clickAction, String playerName) {
      String replacedAction = clickAction.replace("%player%", playerName);
      String command;
      if (replacedAction.startsWith("[EXECUTE]")) {
         command = replacedAction.substring("[EXECUTE] ".length());
         component.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, command));
      } else if (replacedAction.startsWith("[OPEN]")) {
         command = replacedAction.substring("[OPEN] ".length());
         component.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.OPEN_URL, command));
      } else if (replacedAction.startsWith("[SUGGEST]")) {
         command = replacedAction.substring("[SUGGEST] ".length());
         component.setClickEvent(new ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.SUGGEST_COMMAND, command));
      }

   }

   public boolean isGameActive() {
      return this.gameActive;
   }
}
