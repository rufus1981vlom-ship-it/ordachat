package utils;

import config.TagsMenuConfigManager;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public class TagsInventoryManager implements Listener {
   private final TagsMenuConfigManager tagsMenuConfigManager;
   private final OrdaChat plugin;

   public TagsInventoryManager(OrdaChat plugin, TagsMenuConfigManager tagsMenuConfigManager) {
      this.plugin = plugin;
      this.tagsMenuConfigManager = tagsMenuConfigManager;
      Bukkit.getPluginManager().registerEvents(this, plugin);
   }

   public void openMenu(Player player, String menuName) {
      TagsMenuConfigManager.MenuConfig menuConfig = this.tagsMenuConfigManager.getMenu(menuName);
      if (menuConfig == null) {
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, "&cThe menu '" + menuName + "' does not exist."));
      } else {
         String title = this.plugin.getTranslateColors().translateColors(player, menuConfig.getTitle());
         int size = menuConfig.getSize();
         Inventory menu = Bukkit.createInventory((InventoryHolder)null, size, title);
         Iterator var7 = menuConfig.getItems().entrySet().iterator();

         while(var7.hasNext()) {
            Entry<Integer, TagsMenuConfigManager.MenuItem> entry = (Entry)var7.next();
            int slot = (Integer)entry.getKey();
            TagsMenuConfigManager.MenuItem menuItem = (TagsMenuConfigManager.MenuItem)entry.getValue();
            Material material = Material.matchMaterial(menuItem.getMaterial());
            if (material == null) {
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, "&7[&5TChat&7] &cMaterial invalid in slot " + slot + " for the menu: '" + menuName + "' &f(tags_menu.yml)&c."));
            } else {
               ItemStack item = new ItemStack(material);
               ItemMeta meta = item.getItemMeta();
               if (meta != null) {
                  String translatedName = this.plugin.getTranslateColors().translateColors(player, menuItem.getName());
                  meta.setDisplayName(translatedName);
                  List<String> lore = menuItem.getLore();
                  if (lore != null) {
                     lore.replaceAll((message) -> {
                        return this.plugin.getTranslateColors().translateColors(player, message);
                     });
                     meta.setLore(lore);
                  }

                  item.setItemMeta(meta);
               }

               menu.setItem(slot, item);
            }
         }

         player.openInventory(menu);
      }
   }

   @EventHandler
   public void onInventoryClick(@NotNull InventoryClickEvent event) {
      if (this.tagsMenuConfigManager.isEnabled()) {
         HumanEntity var3 = event.getWhoClicked();
         if (var3 instanceof Player) {
            Player player = (Player)var3;
            Inventory clickedInventory = event.getClickedInventory();
            if (clickedInventory != null && event.getView().getTopInventory() == clickedInventory) {
               String currentTitle = this.plugin.getTranslateColors().translateColors(player, event.getView().getTitle());
               currentTitle = currentTitle.replace("§", "&");
               TagsMenuConfigManager.MenuConfig menuConfig = this.tagsMenuConfigManager.getMenuByTitle(currentTitle);
               if (menuConfig != null) {
                  String translatedTitle = this.plugin.getTranslateColors().translateColors(player, menuConfig.getTitle());
                  if (event.getView().getTitle().startsWith(translatedTitle)) {
                     event.setCancelled(true);
                     ItemStack clickedItem = event.getCurrentItem();
                     if (clickedItem != null && clickedItem.hasItemMeta()) {
                        TagsMenuConfigManager.MenuItem menuItem = (TagsMenuConfigManager.MenuItem)menuConfig.getItems().get(event.getSlot());
                        if (menuItem != null) {
                           List<String> commands = menuItem.getCommands();
                           if (commands != null && !commands.isEmpty()) {
                              Iterator var10 = commands.iterator();

                              while(var10.hasNext()) {
                                 String command = (String)var10.next();
                                 String finalCommand = command.replace("%player%", player.getName());
                                 Bukkit.dispatchCommand(player, finalCommand);
                              }
                           }

                           String nextMenu = menuItem.getNextMenu();
                           if (nextMenu != null && !nextMenu.isEmpty()) {
                              this.openMenu(player, nextMenu);
                           }
                        }

                     }
                  }
               }
            }
         }
      }
   }
}
