package listeners;

import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class PlayerMoveListener implements Listener {
   private final OrdaChat plugin;

   public PlayerMoveListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (this.plugin.getPlayerJoinListener().isUnverified(player) && this.plugin.getConfigManager().isAntibotEnabled() && !player.hasPermission(this.plugin.getConfigManager().getAntibotBypass()) && !player.hasPermission("tchat.admin")) {
         this.plugin.getPlayerJoinListener().removeUnverifiedPlayer(player);
         if (this.plugin.getConfigManager().isAntibotMoved()) {
            String prefix = this.plugin.getMessagesManager().getPrefix();
            String message = this.plugin.getMessagesManager().getAntibotMoved();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         }
      }

   }
}
