package listeners;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;

public class AntiFloodListener implements Listener {
   private final OrdaChat plugin;

   public AntiFloodListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void checkFlood(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled()) {
         Player player = event.getPlayer();
         String message = event.getMessage();
         if (!player.hasPermission("tchat.bypass.antiflood") && !player.hasPermission("tchat.admin") && (this.plugin.getConfigManager().isFloodRepeatEnabled() && this.containsFlood(message) || this.plugin.getConfigManager().isFloodPercentEnabled() && this.containsHighPercentageOfSameChar(message))) {
            String message1 = this.plugin.getMessagesManager().getAntiFlood();
            String prefix = this.plugin.getMessagesManager().getPrefix();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message1));
            event.setCancelled(true);
            if (this.plugin.getConfigManager().isDepurationAntiFloodEnabled()) {
               String message2 = this.plugin.getMessagesManager().getDepurationAntiFlood();
               message2 = message2.replace("%player%", player.getName());
               message2 = message2.replace("%message%", message);
               this.plugin.getLogger().warning(message2);
            }
         }

      }
   }

   private boolean containsFlood(String message) {
      char[] chars = message.toCharArray();
      int count = 1;

      for(int i = 1; i < chars.length; ++i) {
         if (chars[i] == chars[i - 1]) {
            ++count;
            if (count >= this.plugin.getConfigManager().getCharactersFlood()) {
               return true;
            }
         } else {
            count = 1;
         }
      }

      return false;
   }

   private boolean containsHighPercentageOfSameChar(String message) {
      if (message.isEmpty()) {
         return false;
      } else {
         Map<Character, Integer> charCount = new HashMap();
         int totalChars = 0;
         char[] var4 = message.toCharArray();
         int count = var4.length;

         for(int var6 = 0; var6 < count; ++var6) {
            char c = var4[var6];
            if (Character.isLetter(c)) {
               charCount.put(c, (Integer)charCount.getOrDefault(c, 0) + 1);
               ++totalChars;
            }
         }

         if (totalChars == 0) {
            return false;
         } else {
            Iterator var8 = charCount.values().iterator();

            double percentage;
            do {
               if (!var8.hasNext()) {
                  return false;
               }

               count = (Integer)var8.next();
               percentage = (double)count / (double)totalChars;
            } while(!(percentage >= this.plugin.getConfigManager().getPercentageFlood()));

            return true;
         }
      }
   }
}
