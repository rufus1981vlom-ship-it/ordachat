package listeners;

import blocked.BannedCommands;
import commands.MuteChatCommand;
import config.AutoBroadcastManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.jetbrains.annotations.NotNull;

public class ChatListener implements Listener {
   private final OrdaChat plugin;
   private final ChatFormatListener chatFormatListener;
   private final Map<Player, String> broadcastNames = new HashMap();
   private final Map<Player, Boolean> broadcastEnabled = new HashMap();
   private final Map<Player, List<String>> broadcastMessages = new HashMap();
   private final Map<Player, Boolean> titleEnabled = new HashMap();
   private final Map<Player, String> title = new HashMap();
   private final Map<Player, String> subtitle = new HashMap();
   private final Map<Player, Boolean> soundEnabled = new HashMap();
   private final Map<Player, String> sound = new HashMap();
   private final Map<Player, Boolean> particlesEnabled = new HashMap();
   private final Map<Player, String> particle = new HashMap();
   private final Map<Player, Integer> particleCount = new HashMap();
   private final Map<Player, Boolean> actionbarEnabled = new HashMap();
   private final Map<Player, String> actionbar = new HashMap();
   private final Map<Player, String> permissions = new HashMap();

   public ChatListener(OrdaChat plugin, ChatFormatListener chatFormatListener) {
      this.plugin = plugin;
      this.chatFormatListener = chatFormatListener;
   }

   @EventHandler
   public void onPlayerChat(@NotNull AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      String message = event.getMessage();
      this.plugin.getCheckPlayerMuted().checkMuted(event);
      this.plugin.getChatEnabledListener().checkChatEnabled(event);
      this.chatMuted(event);
      this.plugin.getChatCooldownListener().chatCooldown(event);
      this.plugin.getAntiUnicodeListener().checkUnicode(event);
      this.plugin.getChatBotListener().chatBot(event);
      this.plugin.getAntiAdvertising().checkAdvertising(event);
      this.plugin.getCapListener().playerAntiCap(event);
      this.antiBot(event, player, (PlayerCommandPreprocessEvent)null);
      this.plugin.getAntiFloodListener().checkFlood(event);
      this.plugin.getBannedWords().playerBannedWords(event);
      this.replacer(event);
      this.grammar(event);
      this.chatFormatListener.playerFormat(event);
      this.plugin.getChatGamesSender().checkPlayerResponse(player, message);
      if (this.plugin.getConfigManager().isLogsChatEnabled()) {
         this.plugin.getLogsManager().logChatMessage(player.getName(), message);
      }

      this.plugin.getLevelListener().addXp(event);
      this.handleBroadcastAddition(player, message);
   }

   @EventHandler
   public void onPlayerCommandPreprocess(@NotNull PlayerCommandPreprocessEvent event) {
      Player player = event.getPlayer();
      String command = event.getMessage();
      if (this.plugin.getConfigManager().isSpyEnabled() && !player.hasPermission("tchat.admin")) {
         this.plugin.getSocialSpyListener().spy(event, player, command);
      }

      if (this.plugin.getConfigManager().isLogsCommandEnabled()) {
         this.plugin.getLogsManager().logCommand(player.getName(), command);
      }

      this.plugin.getAntiAdvertising().checkAdvertisingCommand(event, player, command);
      this.plugin.getChatCooldownListener().commandCooldown(event);
      if (this.plugin.getConfigManager().isRepeatCommandsEnabled() && !player.hasPermission("tchat.admin") && !player.hasPermission("tchat.bypass.repeat-commands")) {
         this.plugin.getRepeatCommandsListener().checkRepeatCommand(event);
      }

      this.antiBot((AsyncPlayerChatEvent)null, player, event);
      (new BannedCommands(this.plugin)).onPlayerCommandPreprocess(event);
   }

   private void handleBroadcastAddition(Player player, String message) {
      if (this.broadcastNames.containsKey(player)) {
         String prefix = this.plugin.getMessagesManager().getPrefix();
         if (this.broadcastEnabled.containsKey(player)) {
            boolean enabled = message.equalsIgnoreCase("yes");
            this.broadcastEnabled.put(player, enabled);
            this.broadcastNames.remove(player);
         } else if (this.broadcastMessages.containsKey(player)) {
            List<String> messages = (List)this.broadcastMessages.get(player);
            if (message.equalsIgnoreCase("done")) {
               String channel;
               if (messages.isEmpty()) {
                  channel = this.plugin.getMessagesManager().getAutoBroadcastAddOneLine();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + channel));
                  return;
               }

               channel = this.plugin.getChannelsManager().getPlayerChannel(player);
               if (channel == null || channel.isEmpty()) {
                  channel = "none";
               }

               String permission = (String)this.permissions.getOrDefault(player, "default_permission");
               AutoBroadcastManager.Broadcast broadcast = new AutoBroadcastManager.Broadcast((Boolean)this.broadcastEnabled.get(player), messages, (Boolean)this.titleEnabled.getOrDefault(player, false), (String)this.title.getOrDefault(player, (Object)null), (String)this.subtitle.getOrDefault(player, (Object)null), (Boolean)this.soundEnabled.getOrDefault(player, false), (String)this.sound.getOrDefault(player, (Object)null), (Boolean)this.particlesEnabled.getOrDefault(player, false), (String)this.particle.getOrDefault(player, (Object)null), (Integer)this.particleCount.getOrDefault(player, 0), (Boolean)this.actionbarEnabled.getOrDefault(player, false), (String)this.actionbar.getOrDefault(player, (Object)null), channel, permission);
               this.plugin.getAutoBroadcastManager().addBroadcast((String)this.broadcastNames.get(player), (Boolean)this.broadcastEnabled.get(player), messages, broadcast.titleEnabled(), broadcast.title(), broadcast.subtitle(), broadcast.soundEnabled(), broadcast.sound(), broadcast.particlesEnabled(), broadcast.particle(), broadcast.particleCount(), broadcast.actionbarEnabled(), broadcast.actionbar(), broadcast.channel(), broadcast.permission());
               this.plugin.getAutoBroadcastManager().reloadConfig();
               this.broadcastNames.remove(player);
               this.broadcastEnabled.remove(player);
               this.broadcastMessages.remove(player);
               this.titleEnabled.remove(player);
               this.title.remove(player);
               this.subtitle.remove(player);
               this.soundEnabled.remove(player);
               this.sound.remove(player);
               this.particlesEnabled.remove(player);
               this.particle.remove(player);
               this.particleCount.remove(player);
               this.actionbarEnabled.remove(player);
               this.actionbar.remove(player);
               this.permissions.remove(player);
            } else {
               messages.add(message);
            }
         }
      }

   }

   public void antiBot(AsyncPlayerChatEvent chatEvent, Player player, PlayerCommandPreprocessEvent commandEvent) {
      if (chatEvent != null) {
         if (chatEvent.isCancelled()) {
            return;
         }
      } else if (commandEvent != null && commandEvent.isCancelled()) {
         return;
      }

      if (this.plugin.getPlayerJoinListener().isUnverified(player) && this.plugin.getConfigManager().isAntibotEnabled() && !player.hasPermission(this.plugin.getConfigManager().getAntibotBypass()) && !player.hasPermission("tchat.admin")) {
         if (chatEvent != null) {
            this.plugin.getAntiBotListener().playerChat(chatEvent, player);
         } else if (commandEvent != null) {
            this.plugin.getAntiBotListener().playerCommand(commandEvent);
         }
      }

   }

   public void replacer(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled()) {
         if (this.plugin.getReplacerManager().getReplacerEnabled()) {
            String message = event.getMessage();
            message = this.plugin.getReplacerManager().replaceWords(message, event.getPlayer());
            event.setMessage(message);
         }

      }
   }

   public void grammar(AsyncPlayerChatEvent event) {
      if (this.plugin.getConfigManager().isGrammarEnabled()) {
         Player player = event.getPlayer();
         String message = event.getMessage();
         this.plugin.getGrammarListener().checkGrammar(event, player, message);
         message = event.getMessage();
         event.setMessage(message);
      }

   }

   public void chatMuted(@NotNull AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      if (MuteChatCommand.isChatMuted() && !player.hasPermission(this.plugin.getConfigManager().getBypassMuteChatPermission())) {
         String prefix = this.plugin.getMessagesManager().getPrefix();
         String message = this.plugin.getMessagesManager().getChatMuted();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         event.setCancelled(true);
      }

   }
}
