package listeners;

import java.util.Arrays;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import utils.Poll;

public class PollListener implements Listener {
   private final OrdaChat plugin;

   public PollListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      Poll currentPoll = Poll.getCurrentPoll();
      if (currentPoll != null && !currentPoll.hasEnded()) {
         String message1 = this.plugin.getMessagesManager().getPollMessage();
         message1 = message1.replace("%poll%", currentPoll.getTitle());
         event.getPlayer().sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, message1));
         String message2 = this.plugin.getMessagesManager().getPollOptionsMessage();
         message2 = message2.replace("%options%", Arrays.toString(currentPoll.getOptions()));
         event.getPlayer().sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, message2));
      }

   }
}
