package listeners;

import java.lang.Character.UnicodeBlock;
import java.util.regex.Pattern;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.jetbrains.annotations.NotNull;
import utils.TranslateColors;

public class AntiUnicodeListener implements Listener {
   private final OrdaChat plugin;
   private final Pattern allowedPattern;

   public AntiUnicodeListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      String regex = plugin.getConfigManager().getUnicodeMatch();
      this.allowedPattern = regex != null && !regex.isEmpty() ? Pattern.compile(regex) : Pattern.compile(".*");
   }

   @EventHandler
   public void checkUnicode(@NotNull AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      String message = event.getMessage();
      if (this.plugin.getConfigManager().isUnicodeEnabled() && !player.hasPermission("tchat.bypass.unicode") && !player.hasPermission("tchat.admin")) {
         if (event.isCancelled()) {
            return;
         }

         if (this.containsInvalidCharacters(message)) {
            if (this.plugin.getConfigManager().getUnicodeMode() == 1) {
               event.setCancelled(true);
               TranslateColors var10001 = this.plugin.getTranslateColors();
               String var10003 = this.plugin.getMessagesManager().getPrefix();
               player.sendMessage(var10001.translateColors(player, var10003 + this.plugin.getMessagesManager().getAntiUnicode()));
            } else {
               String censoredMessage = this.censorUnicode(message);
               event.setMessage(censoredMessage);
            }
         }
      }

   }

   private boolean containsInvalidCharacters(String message) {
      if (!this.plugin.getConfigManager().isUnicodeBlockAll()) {
         return !this.allowedPattern.matcher(message).matches();
      } else {
         char[] var2 = message.toCharArray();
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            char c = var2[var4];
            if (UnicodeBlock.of(c) != UnicodeBlock.BASIC_LATIN) {
               return true;
            }
         }

         return false;
      }
   }

   @NotNull
   private String censorUnicode(@NotNull String message) {
      StringBuilder censored = new StringBuilder();
      char[] var3 = message.toCharArray();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         char c = var3[var5];
         if (UnicodeBlock.of(c) != UnicodeBlock.BASIC_LATIN) {
            censored.append(this.plugin.getConfigManager().getUnicodeCensor());
         } else {
            censored.append(c);
         }
      }

      return censored.toString();
   }
}
