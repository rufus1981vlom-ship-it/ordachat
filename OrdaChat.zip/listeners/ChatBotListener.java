package listeners;

import config.ChatBotManager;
import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

public class ChatBotListener implements Listener {
   private final ChatBotManager chatBotManager;
   private final OrdaChat plugin;

   public ChatBotListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.chatBotManager = plugin.getChatBotManager();
   }

   @EventHandler
   public void chatBot(@NotNull AsyncPlayerChatEvent event) {
      if (!event.isCancelled()) {
         final Player player = event.getPlayer();
         String message = event.getMessage();
         if (this.chatBotManager.isEnabled()) {
            final List<String> responses = this.chatBotManager.getMessages(message);
            if (!responses.isEmpty()) {
               (new BukkitRunnable() {
                  public void run() {
                     Iterator var1 = responses.iterator();

                     while(var1.hasNext()) {
                        String response = (String)var1.next();
                        player.sendMessage(ChatBotListener.this.plugin.getTranslateColors().translateColors(player, response));
                     }

                  }
               }).runTaskLater(this.plugin, 1L);
            }
         }

      }
   }
}
