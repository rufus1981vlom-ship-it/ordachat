package listeners;

import java.util.HashMap;
import java.util.Map;
import minealex.tchat.OrdaChat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.jetbrains.annotations.NotNull;

public class ChatCooldownListener implements Listener {
   private final Map<Player, Long> lastChatTimes = new HashMap();
   private final Map<Player, Long> lastCommandTimes = new HashMap();
   private final OrdaChat plugin;
   private final long chatCooldownTime;
   private final long commandCooldownTime;

   public ChatCooldownListener(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.chatCooldownTime = plugin.getConfigManager().getCooldownChatTime();
      this.commandCooldownTime = plugin.getConfigManager().getCooldownCommandTime();
   }

   @EventHandler
   public void chatCooldown(@NotNull AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      if (!event.isCancelled()) {
         String channelName = this.plugin.getChannelsManager().getPlayerChannel(player);
         if (channelName == null || !this.plugin.getChannelsConfigManager().getChannel(channelName).cooldownEnabled()) {
            if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.bypass.chatcooldown") && this.plugin.getConfigManager().isCooldownChat()) {
               long currentTime = System.currentTimeMillis();
               if (this.isCooldownActive(player, this.lastChatTimes, currentTime, this.chatCooldownTime)) {
                  long timeRemainingMillis = this.chatCooldownTime - (currentTime - (Long)this.lastChatTimes.get(player));
                  long timeRemaining = timeRemainingMillis / 1000L;
                  String prefix = this.plugin.getMessagesManager().getPrefix();
                  String message = this.plugin.getMessagesManager().getCooldownChat();
                  message = message.replace("%cooldown%", String.valueOf(timeRemaining));
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  if (this.plugin.getConfigManager().isDepurationChatEnabled()) {
                     String message1 = this.plugin.getMessagesManager().getDepurationChatCooldown();
                     if (message1 != null) {
                        message1 = message1.replace("%player%", player.getName());
                        message1 = message1.replace("%time%", String.valueOf(timeRemaining));
                        this.plugin.getLogger().warning(message1);
                     } else {
                        this.plugin.getLogger().warning("Depuration message is null for chat cooldown.");
                     }
                  }

                  event.setCancelled(true);
                  return;
               }

               this.lastChatTimes.put(player, currentTime);
            }

         }
      }
   }

   @EventHandler
   public void commandCooldown(@NotNull PlayerCommandPreprocessEvent event) {
      Player player = event.getPlayer();
      if (!event.isCancelled()) {
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.bypass.commandcooldown") && this.plugin.getConfigManager().isCooldownCommand()) {
            long currentTime = System.currentTimeMillis();
            if (this.isCooldownActive(player, this.lastCommandTimes, currentTime, this.commandCooldownTime)) {
               long timeRemainingMillis = this.commandCooldownTime - (currentTime - (Long)this.lastCommandTimes.get(player));
               long timeRemaining = timeRemainingMillis / 1000L;
               String prefix = this.plugin.getMessagesManager().getPrefix();
               String message = this.plugin.getMessagesManager().getCooldownCommand();
               message = message.replace("%cooldown%", String.valueOf(timeRemaining));
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               if (this.plugin.getConfigManager().isDepurationCommandEnabled()) {
                  String message1 = this.plugin.getMessagesManager().getDepurationCommandCooldown();
                  if (message1 != null) {
                     message1 = message1.replace("%player%", player.getName());
                     message1 = message1.replace("%time%", String.valueOf(timeRemaining));
                     this.plugin.getLogger().warning(message1);
                  } else {
                     this.plugin.getLogger().warning("Depuration message is null for chat cooldown.");
                  }
               }

               event.setCancelled(true);
               return;
            }

            this.lastCommandTimes.put(player, currentTime);
         }

      }
   }

   private boolean isCooldownActive(Player player, @NotNull Map<Player, Long> cooldownMap, long currentTime, long cooldownTime) {
      if (cooldownMap.containsKey(player)) {
         long lastTime = (Long)cooldownMap.get(player);
         return currentTime - lastTime < cooldownTime;
      } else {
         return false;
      }
   }
}
