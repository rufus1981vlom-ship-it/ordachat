package listeners;

import config.DeathManager;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.jetbrains.annotations.NotNull;

public class DeathsListener implements Listener {
   private final DeathManager deathManager;
   private final OrdaChat plugin;

   public DeathsListener(DeathManager deathManager, OrdaChat plugin) {
      this.deathManager = deathManager;
      this.plugin = plugin;
   }

   @EventHandler
   public void onPlayerDeath(@NotNull PlayerDeathEvent event) {
      Player player = event.getEntity();
      String playerName = player.getName();
      if (this.deathManager.isTitleEnabled() || this.deathManager.isActionBarEnabled() || this.deathManager.isSoundEnabled() || this.deathManager.isParticlesEnabled() || this.deathManager.getDeathMessage("player-killed-by-environment") != null) {
         if (this.plugin.getDiscordManager().isDiscordEnabled() && this.plugin.getDiscordManager().isDeathEnabled()) {
            this.plugin.getDiscordHook().sendDeathMessage(playerName);
         }

         String killerName = player.getKiller() != null ? player.getKiller().getName() : "unknown";
         String causeMessage = null;
         String actionBarText;
         if (player.getLastDamageCause() != null) {
            DamageCause damageCause = player.getLastDamageCause().getCause();
            String var10000;
            switch(damageCause) {
            case ENTITY_ATTACK:
               var10000 = player.getKiller() != null ? this.deathManager.getDeathMessage("player-killed-by-player") : this.deathManager.getDeathMessage("player-killed-by-entity");
               break;
            case ENTITY_EXPLOSION:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-explosion");
               break;
            case FALL:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-falling");
               break;
            case DROWNING:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-drowning");
               break;
            case LAVA:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-lava");
               break;
            case FIRE:
            case FIRE_TICK:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-fire");
               break;
            case POISON:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-poison");
               break;
            case MAGIC:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-magic");
               break;
            case SUFFOCATION:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-suffocation");
               break;
            case VOID:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-void");
               break;
            case STARVATION:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-starvation");
               break;
            case WITHER:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-wither");
               break;
            case THORNS:
               var10000 = this.deathManager.getDeathMessage("player-killed-by-thorns");
               break;
            case FALLING_BLOCK:
               Entity var8 = player.getLastDamageCause().getEntity();
               if (var8 instanceof FallingBlock) {
                  FallingBlock fallingBlock = (FallingBlock)var8;
                  if (fallingBlock.getBlockData().getMaterial() == Material.ANVIL) {
                     var10000 = this.deathManager.getDeathMessage("player-killed-by-anvil");
                     break;
                  }
               }

               var10000 = this.deathManager.getDeathMessage("player-killed-by-falling-block");
               break;
            default:
               actionBarText = this.deathManager.getDeathMessage("player-killed-by-environment");
               var10000 = actionBarText != null ? actionBarText.replace("%cause%", damageCause.toString()) : null;
            }

            causeMessage = var10000;
         }

         if (causeMessage == null) {
            causeMessage = this.deathManager.getDeathMessage("player-killed-by-environment");
         }

         if (causeMessage != null) {
            if (this.plugin.getConfigManager().isDeathLogs()) {
               this.plugin.getLogsManager().logDeaths(playerName);
            }

            String deathMessage = causeMessage.replace("%player%", playerName).replace("%killer%", killerName);
            event.setDeathMessage(this.plugin.getTranslateColors().translateColors(player, deathMessage));
            if (this.deathManager.isTitleEnabled()) {
               actionBarText = this.deathManager.getTitle() != null ? this.deathManager.getTitle().replace("%player%", playerName) : "";
               String subtitle = this.deathManager.getSubtitle() != null ? this.deathManager.getSubtitle().replace("%player%", playerName) : "";
               player.sendTitle(this.plugin.getTranslateColors().translateColors(player, actionBarText), this.plugin.getTranslateColors().translateColors(player, subtitle), 10, 70, 20);
            }

            if (this.deathManager.isActionBarEnabled()) {
               actionBarText = this.deathManager.getActionBarText() != null ? this.deathManager.getActionBarText().replace("%player%", playerName) : "";
               player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(this.plugin.getTranslateColors().translateColors(player, actionBarText)));
            }

            if (this.deathManager.isSoundEnabled()) {
               try {
                  Sound sound = Sound.valueOf(this.deathManager.getSound());
                  player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
               } catch (IllegalArgumentException var10) {
                  this.plugin.getLogger().warning("Sonido configurado no válido: " + this.deathManager.getSound());
               }
            }

            if (this.deathManager.isParticlesEnabled()) {
               try {
                  Particle particle = Particle.valueOf(this.deathManager.getParticle());
                  player.getWorld().spawnParticle(particle, player.getLocation(), this.deathManager.getNumberOfParticles());
               } catch (IllegalArgumentException var9) {
                  this.plugin.getLogger().warning("Partícula configurada no válida: " + this.deathManager.getParticle());
               }
            }
         }

      }
   }
}
