package listeners;

import java.util.Iterator;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class SocialSpyListener implements Listener {
   private final OrdaChat plugin;

   public SocialSpyListener(OrdaChat plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void spy(PlayerCommandPreprocessEvent event, Player sender, String command) {
      int mode = this.plugin.getConfigManager().getSocialSpyMode();
      Iterator var5 = Bukkit.getServer().getOnlinePlayers().iterator();

      while(true) {
         while(true) {
            Player admin;
            do {
               if (!var5.hasNext()) {
                  return;
               }

               admin = (Player)var5.next();
            } while(!admin.hasPermission("tchat.admin") && !admin.hasPermission("tchat.social-spy"));

            String adminMessage = this.plugin.getConfigManager().getSpyFormat().replace("%player%", sender.getName()).replace("%command%", command);
            if (mode == 1) {
               admin.sendMessage(this.plugin.getTranslateColors().translateColors(admin, adminMessage));
            } else {
               List commands;
               if (mode == 2) {
                  commands = this.plugin.getConfigManager().getSocialSpyCommands();
                  Iterator var12 = commands.iterator();

                  while(var12.hasNext()) {
                     String allowedCommand = (String)var12.next();
                     if (command.toLowerCase().startsWith(allowedCommand.toLowerCase())) {
                        admin.sendMessage(this.plugin.getTranslateColors().translateColors(admin, adminMessage));
                        break;
                     }
                  }
               } else if (mode == 3) {
                  commands = this.plugin.getConfigManager().getSocialSpyCommands();
                  boolean isAllowed = false;
                  Iterator var10 = commands.iterator();

                  while(var10.hasNext()) {
                     String allowedCommand = (String)var10.next();
                     if (command.toLowerCase().startsWith(allowedCommand.toLowerCase())) {
                        isAllowed = true;
                        break;
                     }
                  }

                  if (!isAllowed) {
                     admin.sendMessage(this.plugin.getTranslateColors().translateColors(admin, adminMessage));
                  }
               }
            }
         }
      }
   }
}
