package minealex.tchat;

import blocked.AntiAdvertising;
import blocked.BannedWords;
import commands.AnnouncementCommand;
import commands.AutoBroadcastCommand;
import commands.BannedCommandsCommand;
import commands.BannedWordsCommand;
import commands.BroadcastCommand;
import commands.CalculatorCommand;
import commands.ChannelCommand;
import commands.ChatClearCommand;
import commands.ChatColorCommand;
import commands.ChatGamesCommand;
import commands.CommandTimerCommand;
import commands.Commands;
import commands.HelpOpCommand;
import commands.IgnoreCommand;
import commands.InvseeCommand;
import commands.ListCommand;
import commands.LogsCommand;
import commands.MeCommand;
import commands.MentionCommand;
import commands.MuteChatCommand;
import commands.MuteCommand;
import commands.NickCommand;
import commands.PingCommand;
import commands.PlayerCommand;
import commands.PollCommand;
import commands.PremadeCommand;
import commands.PrintCommand;
import commands.PrivateMessageCommand;
import commands.RealNameCommand;
import commands.ReplacerCommand;
import commands.ReplyCommand;
import commands.RulesCommand;
import commands.SeenCommand;
import commands.ServerCommand;
import commands.ShowCoordsCommand;
import commands.ShowEnderChestCommand;
import commands.ShowItemCommand;
import commands.SocialSpyCommand;
import commands.StaffListCommand;
import commands.TagsCommand;
import commands.WarningCommand;
import config.AutoBroadcastManager;
import config.BannedCommandsManager;
import config.BannedWordsManager;
import config.BroadcastPremadeManager;
import config.ChannelsConfigManager;
import config.ChatBotManager;
import config.ChatColorManager;
import config.ChatGamesManager;
import config.CommandProgrammerManager;
import config.CommandTimerManager;
import config.CommandsManager;
import config.ConfigManager;
import config.DeathManager;
import config.DiscordManager;
import config.GroupManager;
import config.InvseeConfigManager;
import config.JoinManager;
import config.LevelsManager;
import config.LogsManager;
import config.MentionsManager;
import config.MessagesManager;
import config.PlaceholdersConfig;
import config.ReplacerManager;
import config.SaveManager;
import config.ShowEnderChestConfigManager;
import config.TagsManager;
import config.TagsMenuConfigManager;
import config.WorldsManager;
import hook.DiscordHook;
import java.util.Objects;
import listeners.AntiBotListener;
import listeners.AntiFloodListener;
import listeners.AntiUnicodeListener;
import listeners.CapListener;
import listeners.ChatBotListener;
import listeners.ChatCooldownListener;
import listeners.ChatEnabledListener;
import listeners.ChatFormatListener;
import listeners.ChatListener;
import listeners.ChatPlaceholdersListener;
import listeners.DeathsListener;
import listeners.GrammarListener;
import listeners.LevelListener;
import listeners.PlayerJoinListener;
import listeners.PlayerLeftListener;
import listeners.PlayerMoveListener;
import listeners.PollListener;
import listeners.RepeatCommandsListener;
import listeners.RepeatMessagesListener;
import listeners.SignListener;
import listeners.SocialSpyListener;
import listeners.TabCompleteListener;
import minealex.tchat.libs.bstats.bukkit.Metrics;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import placeholders.Placeholders;
import utils.AutoBroadcastSender;
import utils.AutoBroadcastTabCompleter;
import utils.ChannelsCompleter;
import utils.ChannelsManager;
import utils.ChatColorInventoryManager;
import utils.ChatGamesSender;
import utils.CheckPlayerMuted;
import utils.CommandProgrammerSender;
import utils.CustomCommands;
import utils.PollScheduler;
import utils.TagsInventoryManager;
import utils.TranslateColors;

public class OrdaChat extends JavaPlugin {
   private ConfigManager configManager;
   private MessagesManager messagesManager;
   private GroupManager groupManager;
   private BannedWordsManager bannedWordsManager;
   private BannedWords bannedWords;
   private BannedCommandsManager bannedCommandsManager;
   private ReplacerManager replacerManager;
   private AntiAdvertising antiAdvertising;
   private ChatColorInventoryManager chatColorInventoryManager;
   private SaveManager saveManager;
   private CapListener capListener;
   private TranslateColors translateColors;
   private ChatColorManager chatColorManager;
   private ChannelsConfigManager channelsConfigManager;
   private ChannelsManager channelsManager;
   private GrammarListener grammarListener;
   private AutoBroadcastManager autoBroadcastManager;
   private ChatBotManager chatBotManager;
   private ChatBotListener chatBotListener;
   private CommandTimerManager commandTimerManager;
   private RepeatMessagesListener repeatMessagesListener;
   private AntiBotListener antiBotListener;
   private PlayerJoinListener playerJoinListener;
   private ChatGamesManager chatGamesManager;
   private ChatGamesSender chatGamesSender;
   private AutoBroadcastSender autoBroadcastSender;
   private LogsManager logsManager;
   private ChatCooldownListener chatCooldownListener;
   private AntiFloodListener antiFloodListener;
   private AntiUnicodeListener antiUnicodeListener;
   private ChatClearCommand chatClearCommand;
   private MuteChatCommand muteChatCommand;
   private CommandProgrammerManager commandProgrammerManager;
   private CommandsManager commandsManager;
   private DiscordHook discordHook;
   private DiscordManager discordManager;
   private SocialSpyListener socialSpyListener;
   private LevelListener levelListener;
   private LevelsManager levelsManager;
   private DeathManager deathManager;
   private WorldsManager worldsManager;
   private ChatEnabledListener chatEnabledListener;
   private PlayerLeftListener playerLeftListener;
   private PlaceholdersConfig placeholdersConfig;
   private JoinManager joinManager;
   private MentionsManager mentionsManager;
   private CheckPlayerMuted checkPlayerMuted;
   private InvseeConfigManager invseeConfigManager;
   private ShowEnderChestConfigManager showEnderChestConfigManager;
   private TagsManager tagsManager;
   private TagsMenuConfigManager tagsMenuConfigManager;
   private TagsInventoryManager tagsInventoryManager;
   private TabCompleteListener tabCompleteListener;
   private RepeatCommandsListener repeatCommandsListener;
   private BroadcastPremadeManager broadcastPremadeManager;

   @Override
   public void onEnable() {
      Bukkit.getConsoleSender().sendMessage(ChatColor.GRAY + "[" + ChatColor.DARK_PURPLE + "OrdaChat" + ChatColor.GRAY + "] " + ChatColor.GREEN + "Starting OrdaChat...");
      this.registerConfigFiles();
      this.initializeManagers();
      this.registerListeners();
      this.registerCommands();
      this.registerPlaceholders();
      Bukkit.getConsoleSender().sendMessage(ChatColor.GRAY + "[" + ChatColor.DARK_PURPLE + "OrdaChat" + ChatColor.GRAY + "] " + ChatColor.GREEN + "OrdaChat started.");
   }

   @Override
   public void onDisable() {
      Bukkit.getConsoleSender().sendMessage(ChatColor.GRAY + "[" + ChatColor.DARK_PURPLE + "OrdaChat" + ChatColor.GRAY + "] " + ChatColor.RED + "OrdaChat stopped");
   }

   public void registerListeners() {
      ChatFormatListener chatFormatListener = new ChatFormatListener(this, this.configManager, this.groupManager);
      this.bannedWords = new BannedWords(this, this.bannedWordsManager);
      ChatListener chatListener = new ChatListener(this, chatFormatListener);
      this.antiAdvertising = new AntiAdvertising(this);
      this.capListener = new CapListener(this);
      this.grammarListener = new GrammarListener(this);
      this.chatBotListener = new ChatBotListener(this);
      this.repeatMessagesListener = new RepeatMessagesListener(this);
      this.playerJoinListener = new PlayerJoinListener(this);
      this.playerLeftListener = new PlayerLeftListener(this);
      PlayerMoveListener playerMoveListener = new PlayerMoveListener(this);
      this.antiBotListener = new AntiBotListener(this);
      this.autoBroadcastSender = new AutoBroadcastSender(this);
      this.chatCooldownListener = new ChatCooldownListener(this);
      this.antiFloodListener = new AntiFloodListener(this);
      this.antiUnicodeListener = new AntiUnicodeListener(this);
      new CommandProgrammerSender(this, this.commandProgrammerManager);
      this.discordHook = new DiscordHook(this);
      this.socialSpyListener = new SocialSpyListener(this);
      SignListener signListener = new SignListener(this);
      this.levelListener = new LevelListener(this);
      this.chatEnabledListener = new ChatEnabledListener(this);
      this.checkPlayerMuted = new CheckPlayerMuted(this);
      this.tabCompleteListener = new TabCompleteListener(this);
      this.repeatCommandsListener = new RepeatCommandsListener(this);
      this.getServer().getPluginManager().registerEvents(new ChatPlaceholdersListener(this, new ShowItemCommand(this)), this);
      this.getServer().getPluginManager().registerEvents(new PollListener(this), this);
      this.getServer().getPluginManager().registerEvents(signListener, this);
      this.getServer().getPluginManager().registerEvents(chatListener, this);
      this.getServer().getPluginManager().registerEvents(this.bannedWords, this);
      this.getServer().getPluginManager().registerEvents(this.tabCompleteListener, this);
      this.getServer().getPluginManager().registerEvents(this.playerJoinListener, this);
      this.getServer().getPluginManager().registerEvents(this.playerLeftListener, this);
      this.getServer().getPluginManager().registerEvents(playerMoveListener, this);
      this.getServer().getPluginManager().registerEvents(new DeathsListener(this.deathManager, this), this);
      PollScheduler.startPollChecker(this);
   }

   public void registerConfigFiles() {
      this.replacerManager = new ReplacerManager(this);
      this.bannedWordsManager = new BannedWordsManager(this);
      this.commandTimerManager = new CommandTimerManager(this);
      this.configManager = new ConfigManager(this);
      this.levelsManager = new LevelsManager(this);
      this.messagesManager = new MessagesManager(this);
      this.bannedCommandsManager = new BannedCommandsManager(this);
      this.saveManager = new SaveManager(this);
      this.chatColorManager = new ChatColorManager(this);
      this.channelsConfigManager = new ChannelsConfigManager(this);
      this.autoBroadcastManager = new AutoBroadcastManager(this);
      this.chatBotManager = new ChatBotManager(this);
      this.chatGamesManager = new ChatGamesManager(this);
      this.chatGamesSender = new ChatGamesSender(this);
      this.logsManager = new LogsManager(this);
      this.commandProgrammerManager = new CommandProgrammerManager(this);
      this.commandsManager = new CommandsManager(this);
      this.discordManager = new DiscordManager(this);
      this.deathManager = new DeathManager(this);
      this.worldsManager = new WorldsManager(this);
      this.placeholdersConfig = new PlaceholdersConfig(this);
      this.joinManager = new JoinManager(this);
      this.mentionsManager = new MentionsManager(this);
      this.invseeConfigManager = new InvseeConfigManager(this);
      this.showEnderChestConfigManager = new ShowEnderChestConfigManager(this);
      this.tagsManager = new TagsManager(this);
      this.tagsMenuConfigManager = new TagsMenuConfigManager(this);
      this.broadcastPremadeManager = new BroadcastPremadeManager(this);
   }

   public void initializeManagers() {
      this.groupManager = new GroupManager(this);
      this.chatColorInventoryManager = new ChatColorInventoryManager(this);
      this.translateColors = new TranslateColors();
      this.channelsManager = new ChannelsManager();
      new Metrics(this, 23305);
      this.tagsInventoryManager = new TagsInventoryManager(this, this.tagsMenuConfigManager);
   }

   public void registerCommands() {
      new Commands(this);

      if (this.getConfigManager().isChatColorEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("chatcolor"))).setExecutor(new ChatColorCommand(this));
      }

      ((PluginCommand) Objects.requireNonNull(this.getCommand("channel"))).setExecutor(new ChannelCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("channel"))).setTabCompleter(new ChannelsCompleter(this));

      if (this.getConfigManager().isMsgEnabled()) {
         PrivateMessageCommand privateMessageCommand = new PrivateMessageCommand(this);
         ((PluginCommand) Objects.requireNonNull(this.getCommand("msg"))).setExecutor(privateMessageCommand);

         if (this.getConfigManager().isReplyEnabled()) {
            ((PluginCommand) Objects.requireNonNull(this.getCommand("reply"))).setExecutor(new ReplyCommand(this, privateMessageCommand));
         }
      }

      if (this.getConfigManager().isChatClearEnabled()) {
         this.chatClearCommand = new ChatClearCommand(this);
         ((PluginCommand) Objects.requireNonNull(this.getCommand("chatclear"))).setExecutor(this.chatClearCommand);
      }

      if (this.getConfigManager().isMuteChatEnabled()) {
         this.muteChatCommand = new MuteChatCommand(this);
         ((PluginCommand) Objects.requireNonNull(this.getCommand("mutechat"))).setExecutor(this.muteChatCommand);
      }

      new CustomCommands(this);

      if (this.getConfigManager().isPingEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("ping"))).setExecutor(new PingCommand(this));
      }

      if (this.getConfigManager().isBroadcastEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("broadcast"))).setExecutor(new BroadcastCommand(this));
      }

      if (this.getConfigManager().isWarningEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("warning"))).setExecutor(new WarningCommand(this));
      }

      if (this.getConfigManager().isAnnouncementEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("announcement"))).setExecutor(new AnnouncementCommand(this));
      }

      ((PluginCommand) Objects.requireNonNull(this.getCommand("ignore"))).setExecutor(new IgnoreCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("poll"))).setExecutor(new PollCommand(this));

      if (this.getConfigManager().isRulesEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("rules"))).setExecutor(new RulesCommand(this));
      }

      if (this.getConfigManager().isPrintEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("print"))).setExecutor(new PrintCommand(this));
      }

      AutoBroadcastCommand autoBroadcastCommand = new AutoBroadcastCommand(this);
      ((PluginCommand) Objects.requireNonNull(this.getCommand("autobroadcast"))).setExecutor(autoBroadcastCommand);
      ((PluginCommand) Objects.requireNonNull(this.getCommand("autobroadcast"))).setTabCompleter(new AutoBroadcastTabCompleter(this.autoBroadcastManager));

      ((PluginCommand) Objects.requireNonNull(this.getCommand("plugin"))).setExecutor(new commands.PluginCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("bannedcommands"))).setExecutor(new BannedCommandsCommand(this.bannedCommandsManager, this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("helpop"))).setExecutor(new HelpOpCommand(this));

      if (this.getConfigManager().isSicEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("showitem"))).setExecutor(new ShowItemCommand(this));
      }

      ((PluginCommand) Objects.requireNonNull(this.getCommand("list"))).setExecutor(new ListCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("calculator"))).setExecutor(new CalculatorCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("player"))).setExecutor(new PlayerCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("server"))).setExecutor(new ServerCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("socialspy"))).setExecutor(new SocialSpyCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("socialspy"))).setTabCompleter(new SocialSpyCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("commandtimer"))).setExecutor(new CommandTimerCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("nick"))).setExecutor(new NickCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("seen"))).setExecutor(new SeenCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("realname"))).setExecutor(new RealNameCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("stafflist"))).setExecutor(new StaffListCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("bannedwords"))).setExecutor(new BannedWordsCommand(this, this.bannedWordsManager));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("mute"))).setExecutor(new MuteCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("logs"))).setExecutor(new LogsCommand(this));
      ((PluginCommand) Objects.requireNonNull(this.getCommand("logs"))).setTabCompleter(new LogsCommand(this));

      if (this.getInvseeConfigManager().isEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("invsee"))).setExecutor(new InvseeCommand(this));
      }

      ((PluginCommand) Objects.requireNonNull(this.getCommand("mention"))).setExecutor(new MentionCommand(this));

      if (this.getShowEnderChestConfigManager().isEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("showenderchest"))).setExecutor(new ShowEnderChestCommand(this));
      }

      if (this.getConfigManager().isMeEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("me"))).setExecutor(new MeCommand(this));
      }

      if (this.getConfigManager().isSccEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("showcoords"))).setExecutor(new ShowCoordsCommand(this));
      }

      ((PluginCommand) Objects.requireNonNull(this.getCommand("chatgames"))).setExecutor(new ChatGamesCommand(this, this.chatGamesSender, this.chatGamesManager));
      new TagsCommand(this, this.tagsManager, this.tagsInventoryManager);

      if (this.replacerManager.getReplacerEnabled()) {
         ((PluginCommand) Objects.requireNonNull(this.getCommand("replacer"))).setExecutor(new ReplacerCommand(this));
      }

      ((PluginCommand) Objects.requireNonNull(this.getCommand("premade"))).setExecutor(new PremadeCommand(this));
   }

   public void registerPlaceholders() {
      (new Placeholders(this, this.groupManager)).register();
   }

   public BroadcastPremadeManager getBroadcastPremadeManager() {
      return this.broadcastPremadeManager;
   }

   public RepeatCommandsListener getRepeatCommandsListener() {
      return this.repeatCommandsListener;
   }

   public TabCompleteListener getTabCompleteListener() {
      return this.tabCompleteListener;
   }

   public TagsMenuConfigManager getTagsMenuConfigManager() {
      return this.tagsMenuConfigManager;
   }

   public TagsManager getTagsManager() {
      return this.tagsManager;
   }

   public ShowEnderChestConfigManager getShowEnderChestConfigManager() {
      return this.showEnderChestConfigManager;
   }

   public InvseeConfigManager getInvseeConfigManager() {
      return this.invseeConfigManager;
   }

   public CheckPlayerMuted getCheckPlayerMuted() {
      return this.checkPlayerMuted;
   }

   public MentionsManager getMentionsManager() {
      return this.mentionsManager;
   }

   public JoinManager getJoinManager() {
      return this.joinManager;
   }

   public PlaceholdersConfig getPlaceholdersConfig() {
      return this.placeholdersConfig;
   }

   public AutoBroadcastSender getAutoBroadcastSender() {
      return this.autoBroadcastSender;
   }

   public PlayerLeftListener getPlayerLeftListener() {
      return this.playerLeftListener;
   }

   public ChatEnabledListener getChatEnabledListener() {
      return this.chatEnabledListener;
   }

   public WorldsManager getWorldsManager() {
      return this.worldsManager;
   }

   public LevelsManager getLevelsManager() {
      return this.levelsManager;
   }

   public LevelListener getLevelListener() {
      return this.levelListener;
   }

   public SocialSpyListener getSocialSpyListener() {
      return this.socialSpyListener;
   }

   public DiscordManager getDiscordManager() {
      return this.discordManager;
   }

   public DiscordHook getDiscordHook() {
      return this.discordHook;
   }

   public CommandsManager getCommandsManager() {
      return this.commandsManager;
   }

   public CommandProgrammerManager getCommandProgrammerManager() {
      return this.commandProgrammerManager;
   }

   public MuteChatCommand getMuteChatCommand() {
      return this.muteChatCommand;
   }

   public ChatClearCommand getChatClearCommand() {
      return this.chatClearCommand;
   }

   public AntiUnicodeListener getAntiUnicodeListener() {
      return this.antiUnicodeListener;
   }

   public AntiFloodListener getAntiFloodListener() {
      return this.antiFloodListener;
   }

   public ChatCooldownListener getChatCooldownListener() {
      return this.chatCooldownListener;
   }

   public LogsManager getLogsManager() {
      return this.logsManager;
   }

   public ChatGamesSender getChatGamesSender() {
      return this.chatGamesSender;
   }

   public ChatGamesManager getChatGamesManager() {
      return this.chatGamesManager;
   }

   public PlayerJoinListener getPlayerJoinListener() {
      return this.playerJoinListener;
   }

   public AntiBotListener getAntiBotListener() {
      return this.antiBotListener;
   }

   public RepeatMessagesListener getRepeatMessagesListener() {
      return this.repeatMessagesListener;
   }

   public CommandTimerManager getCommandTimerManager() {
      return this.commandTimerManager;
   }

   public ChatBotListener getChatBotListener() {
      return this.chatBotListener;
   }

   public ChatBotManager getChatBotManager() {
      return this.chatBotManager;
   }

   public AutoBroadcastManager getAutoBroadcastManager() {
      return this.autoBroadcastManager;
   }

   public GrammarListener getGrammarListener() {
      return this.grammarListener;
   }

   public ChannelsManager getChannelsManager() {
      return this.channelsManager;
   }

   public ChannelsConfigManager getChannelsConfigManager() {
      return this.channelsConfigManager;
   }

   public ChatColorInventoryManager getChatColorInventoryManager() {
      return this.chatColorInventoryManager;
   }

   public SaveManager getSaveManager() {
      return this.saveManager;
   }

   public AntiAdvertising getAntiAdvertising() {
      return this.antiAdvertising;
   }

   public CapListener getCapListener() {
      return this.capListener;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public MessagesManager getMessagesManager() {
      return this.messagesManager;
   }

   public GroupManager getGroupManager() {
      return this.groupManager;
   }

   public BannedWordsManager getBannedWordsManager() {
      return this.bannedWordsManager;
   }

   public BannedWords getBannedWords() {
      return this.bannedWords;
   }

   public BannedCommandsManager getBannedCommandsManager() {
      return this.bannedCommandsManager;
   }

   public TranslateColors getTranslateColors() {
      return this.translateColors;
   }

   public ReplacerManager getReplacerManager() {
      return this.replacerManager;
   }

   public ChatColorManager getChatColorManager() {
      return this.chatColorManager;
   }
}