package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class PlayerCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public PlayerCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String playerName;
      if (!sender.hasPermission("tchat.player")) {
         playerName = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + playerName));
         return true;
      } else if (args.length != 1) {
         playerName = this.plugin.getMessagesManager().getUsagePlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + playerName));
         return false;
      } else {
         playerName = args[0];
         Player targetPlayer = Bukkit.getPlayerExact(playerName);
         if (targetPlayer == null) {
            String message = this.plugin.getMessagesManager().getPlayerNotFound();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return true;
         } else {
            Iterator var8 = this.plugin.getMessagesManager().getPlayerMessage().iterator();

            String m;
            while(var8.hasNext()) {
               m = (String)var8.next();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(targetPlayer, m));
            }

            if (sender.hasPermission("tchat.admin.player")) {
               var8 = this.plugin.getMessagesManager().getPlayerMessageAdmin().iterator();

               while(var8.hasNext()) {
                  m = (String)var8.next();
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors(targetPlayer, m));
               }
            }

            return true;
         }
      }
   }
}
