package commands;

import java.util.UUID;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class RealNameCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public RealNameCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String providedNick;
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (args.length != 1) {
            providedNick = this.plugin.getMessagesManager().getUsageRealName();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + providedNick));
            return true;
         } else {
            providedNick = args[0];
            UUID playerId = this.plugin.getSaveManager().getPlayerIdByNick(providedNick);
            if (playerId == null) {
               String message = this.plugin.getMessagesManager().getNoPlayerRealName().replace("%nick%", providedNick);
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return true;
            } else {
               Player realPlayer = Bukkit.getPlayer(playerId);
               String message;
               if (realPlayer == null) {
                  message = this.plugin.getMessagesManager().getOfflineRealName();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  return true;
               } else {
                  message = this.plugin.getMessagesManager().getRealName().replace("%nick%", providedNick).replace("%player%", realPlayer.getName());
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  return true;
               }
            }
         }
      } else {
         providedNick = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + providedNick));
         return true;
      }
   }
}
