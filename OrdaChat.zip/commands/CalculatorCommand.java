package commands;

import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class CalculatorCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public CalculatorCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (args.length != 3) {
         String message = this.plugin.getMessagesManager().getUsageCalculator();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return false;
      } else {
         try {
            double num1 = Double.parseDouble(args[0]);
            String operator = args[1];
            double num2 = Double.parseDouble(args[2]);
            byte var14 = -1;
            switch(operator.hashCode()) {
            case 42:
               if (operator.equals("*")) {
                  var14 = 2;
               }
               break;
            case 43:
               if (operator.equals("+")) {
                  var14 = 0;
               }
            case 44:
            case 46:
            default:
               break;
            case 45:
               if (operator.equals("-")) {
                  var14 = 1;
               }
               break;
            case 47:
               if (operator.equals("/")) {
                  var14 = 3;
               }
            }

            double result;
            String message;
            switch(var14) {
            case 0:
               result = num1 + num2;
               break;
            case 1:
               result = num1 - num2;
               break;
            case 2:
               result = num1 * num2;
               break;
            case 3:
               if (num2 == 0.0D) {
                  message = this.plugin.getMessagesManager().getDivisionZero();
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
                  return false;
               }

               result = num1 / num2;
               break;
            default:
               message = this.plugin.getMessagesManager().getInvalidOperator();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
               return false;
            }

            String message = this.plugin.getMessagesManager().getCalculatorResult();
            message = message.replace("%result%", String.valueOf(result));
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return true;
         } catch (NumberFormatException var16) {
            String message = this.plugin.getMessagesManager().getInvalidNumber();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return false;
         }
      }
   }
}
