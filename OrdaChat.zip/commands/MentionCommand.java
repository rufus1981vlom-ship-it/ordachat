package commands;

import config.MentionsManager;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class MentionCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public MentionCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String m;
      if (!sender.hasPermission("tchat.command.mention") && !sender.hasPermission("tchat.admin")) {
         m = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
      }

      if (args.length != 1) {
         m = this.plugin.getMessagesManager().getUsageMention();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         String m;
         if (target != null && target.isOnline()) {
            this.executeActions(target, sender);
            m = this.plugin.getMessagesManager().getMentionOther();
            if (m.contains("%mentioned%")) {
               m = m.replace("%mentioned%", target.getName());
            }

            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
            return true;
         } else {
            m = this.plugin.getMessagesManager().getPlayerNotFound();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
            return true;
         }
      }
   }

   public void executeActions(Player player, @NotNull CommandSender sender) {
      String groupName = this.plugin.getGroupManager().getGroup(player);
      MentionsManager.EventConfig personalConfig = this.plugin.getMentionsManager().getPersonalEventConfig(groupName);
      String senderName = sender.getName();
      String particle;
      if (personalConfig.isMessageEnabled()) {
         particle = String.join("\n", personalConfig.getMessage()).replace("%mentioned%", senderName);
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, particle));
      }

      if (personalConfig.isTitleEnabled() || personalConfig.isSubtitleEnabled()) {
         particle = personalConfig.isTitleEnabled() ? this.plugin.getTranslateColors().translateColors(player, personalConfig.getTitle().replace("%mentioned%", senderName)) : "";
         String subtitle = personalConfig.isSubtitleEnabled() ? this.plugin.getTranslateColors().translateColors(player, personalConfig.getSubtitle().replace("%mentioned%", senderName)) : "";
         player.sendTitle(particle, subtitle, 10, 70, 20);
      }

      if (personalConfig.isSoundEnabled()) {
         particle = personalConfig.getSound();
         player.playSound(player.getLocation(), particle, 1.0F, 1.0F);
      }

      if (personalConfig.isParticlesEnabled()) {
         particle = personalConfig.getParticle();
         player.getWorld().spawnParticle(Particle.valueOf(particle.toUpperCase()), player.getLocation(), 10);
      }

      if (personalConfig.isActionbarEnabled()) {
         player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(this.plugin.getTranslateColors().translateColors(player, personalConfig.getActionbarMessage().replace("%mentioned%", senderName))));
      }

   }
}
