package commands;

import java.util.Iterator;
import java.util.Map.Entry;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public class ShowItemCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public ShowItemCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!(sender instanceof Player)) {
         message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return false;
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.showitem")) {
            message = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         } else {
            this.components(player, prefix);
         }

         return true;
      }
   }

   private void components(@NotNull Player player, String prefix) {
      ItemStack item = player.getInventory().getItemInMainHand();
      if (item.getType().isAir()) {
         String m = this.plugin.getMessagesManager().getNoItemInHand();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + m));
      } else {
         ItemMeta meta = item.getItemMeta();
         String itemName;
         if (meta == null) {
            itemName = this.plugin.getMessagesManager().getInvalidItemMeta();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + itemName));
         } else {
            itemName = meta.hasDisplayName() ? meta.getDisplayName() : item.getType().toString();
            String itemTagJson = this.getItemTagJson(meta);

            assert meta instanceof Damageable;

            String itemJson = String.format("{\"id\":\"%s\",\"Count\":%d,\"tag\":%s,\"Damage\":%d}", item.getType().getKey().getKey(), item.getAmount(), itemTagJson, ((Damageable)meta).getDamage());
            TextComponent prefixComponent = new TextComponent(this.plugin.getTranslateColors().translateColors(player, this.plugin.getConfigManager().getSicPrefix()));
            TextComponent suffixComponent = new TextComponent(this.plugin.getTranslateColors().translateColors(player, this.plugin.getConfigManager().getSicSuffix()));
            TextComponent itemComponent = new TextComponent(itemName);
            itemComponent.setHoverEvent(new HoverEvent(Action.SHOW_ITEM, (new ComponentBuilder(itemJson)).create()));
            TextComponent finalMessage = new TextComponent();
            finalMessage.addExtra(prefixComponent);
            finalMessage.addExtra(itemComponent);
            finalMessage.addExtra(suffixComponent);
            player.spigot().sendMessage(finalMessage);
         }
      }
   }

   @NotNull
   public String getItemTagJson(@NotNull ItemMeta meta) {
      StringBuilder tagJson = new StringBuilder();
      tagJson.append("{");
      if (meta.hasDisplayName()) {
         tagJson.append("\"display\":{\"Name\":\"").append(this.escapeJson(meta.getDisplayName())).append("\"},");
      }

      boolean first;
      Iterator var5;
      Entry entry;
      if (meta instanceof EnchantmentStorageMeta) {
         EnchantmentStorageMeta enchantmentMeta = (EnchantmentStorageMeta)meta;
         tagJson.append("\"Enchantments\":[");
         first = true;
         var5 = enchantmentMeta.getStoredEnchants().entrySet().iterator();

         while(var5.hasNext()) {
            entry = (Entry)var5.next();
            if (!first) {
               tagJson.append(",");
            }

            first = false;
            tagJson.append("{\"id\":\"").append(((Enchantment)entry.getKey()).getKey()).append("\",\"lvl\":").append(entry.getValue()).append("}");
         }

         tagJson.append("],");
      } else if (meta.hasEnchants()) {
         tagJson.append("\"Enchantments\":[");
         first = true;
         var5 = meta.getEnchants().entrySet().iterator();

         while(var5.hasNext()) {
            entry = (Entry)var5.next();
            if (!first) {
               tagJson.append(",");
            }

            first = false;
            tagJson.append("{\"id\":\"").append(((Enchantment)entry.getKey()).getKey()).append("\",\"lvl\":").append(entry.getValue()).append("}");
         }

         tagJson.append("],");
      }

      if (tagJson.charAt(tagJson.length() - 1) == ',') {
         tagJson.deleteCharAt(tagJson.length() - 1);
      }

      tagJson.append("}");
      return tagJson.toString();
   }

   @NotNull
   private String escapeJson(@NotNull String text) {
      return text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\b", "\\b").replace("\f", "\\f").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
   }
}
