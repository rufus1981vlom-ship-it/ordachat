package commands;

import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public class ShowEnderChestCommand implements CommandExecutor, Listener {
   private final OrdaChat plugin;

   public ShowEnderChestCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      plugin.getServer().getPluginManager().registerEvents(this, plugin);
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (!sender.hasPermission("tchat.admin") && !sender.hasPermission("tchat.command.showec")) {
         String m = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
         return false;
      } else if (sender instanceof Player) {
         Player player = (Player)sender;
         Player target = player;
         if (args.length > 0) {
            Player potentialTarget = Bukkit.getPlayer(args[0]);
            if (potentialTarget == null) {
               String m = this.plugin.getMessagesManager().getPlayerNotFound();
               player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + m));
               return false;
            }

            target = potentialTarget;
         }

         this.inventory(player, target);
         return true;
      } else {
         String m = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
         return false;
      }
   }

   @EventHandler
   public void onInventoryClick(@NotNull InventoryClickEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof Player) {
         Player player = (Player)var3;
         String title = this.plugin.getTranslateColors().translateColors(player, this.plugin.getShowEnderChestConfigManager().getMenuTitle());
         if (event.getView().getTitle().startsWith(title)) {
            event.setCancelled(true);
         }
      }

   }

   public void inventory(@NotNull Player viewer, @NotNull Player target) {
      String title = this.plugin.getShowEnderChestConfigManager().getMenuTitle();
      title = this.plugin.getTranslateColors().translateColors(target, title);
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, this.plugin.getShowEnderChestConfigManager().getSlots(), title);
      ItemStack[] items = target.getEnderChest().getContents();

      for(int i = this.plugin.getShowEnderChestConfigManager().getStartSlotEnder(); i < items.length; ++i) {
         if (i < this.plugin.getShowEnderChestConfigManager().getEndSlotEnder()) {
            inv.setItem(i, items[i]);
         }
      }

      ItemStack glass = this.plugin.getShowEnderChestConfigManager().createGlass();

      for(int i = this.plugin.getShowEnderChestConfigManager().getStartSlotGlass(); i < this.plugin.getShowEnderChestConfigManager().getEndSlotGlass(); ++i) {
         inv.setItem(i, glass);
      }

      ItemStack head = this.plugin.getShowEnderChestConfigManager().createHead(target);
      inv.setItem(this.plugin.getShowEnderChestConfigManager().getHeadSlot(), head);
      viewer.openInventory(inv);
   }
}
