package commands;

import java.util.Iterator;
import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class HelpOpCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public HelpOpCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!(sender instanceof Player)) {
         message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return true;
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.helpop")) {
            message = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         } else if (args.length == 0) {
            message = this.plugin.getMessagesManager().getUsageHelpOp();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         } else {
            message = String.join(" ", args);
            String formattedMessage = this.plugin.getConfigManager().getHelpOpFormat();
            formattedMessage = formattedMessage.replace("%player%", player.getName());
            formattedMessage = formattedMessage.replace("%message%", message);
            Iterator var9 = Bukkit.getOnlinePlayers().iterator();

            while(true) {
               Player onlinePlayer;
               do {
                  if (!var9.hasNext()) {
                     String message1 = this.plugin.getMessagesManager().getHelpOp();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message1));
                     return true;
                  }

                  onlinePlayer = (Player)var9.next();
               } while(!onlinePlayer.hasPermission("tchat.admin") && !onlinePlayer.hasPermission("tchat.admin.helpop"));

               onlinePlayer.sendMessage(this.plugin.getTranslateColors().translateColors(player, formattedMessage));
            }
         }
      }
   }
}
