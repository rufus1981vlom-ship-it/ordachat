package commands;

import java.util.Arrays;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class CommandTimerCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public CommandTimerCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (args.length < 2) {
            message = this.plugin.getMessagesManager().getUsageCommandTimer();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         } else if (args[0].equalsIgnoreCase("create")) {
            return this.handleCreateCommand(player, args);
         } else if (args[0].equalsIgnoreCase("remove")) {
            return this.handleRemoveCommand(player, args);
         } else {
            message = this.plugin.getMessagesManager().getUsageCommandTimer();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         }
      } else {
         message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return true;
      }
   }

   private boolean handleCreateCommand(Player player, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String name;
      if (args.length < 4) {
         name = this.plugin.getMessagesManager().getUsageCommandTimerAdd();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + name));
         return true;
      } else {
         name = args[1];

         int time;
         try {
            time = Integer.parseInt(args[2]);
         } catch (NumberFormatException var9) {
            String message = this.plugin.getMessagesManager().getCommandTimerInvalidNumber();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         }

         String[] commands = String.join(" ", (CharSequence[])Arrays.copyOfRange(args, 3, args.length)).split("\\|");
         List<String> commandList = Arrays.stream(commands).map(String::trim).toList();
         String message;
         if (this.plugin.getCommandTimerManager().addCommandTimer(name, time, commandList)) {
            message = this.plugin.getMessagesManager().getCommandTimerAdded();
            message = message.replace("%timer%", name);
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         } else {
            message = this.plugin.getMessagesManager().getCommandTimerAlreadyAdded();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         }

         return true;
      }
   }

   private boolean handleRemoveCommand(Player player, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String name;
      if (args.length < 2) {
         name = this.plugin.getMessagesManager().getUsageCommandTimerRemove();
         player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + name));
         return true;
      } else {
         name = args[1];
         String message;
         if (this.plugin.getCommandTimerManager().removeCommandTimer(name)) {
            message = this.plugin.getMessagesManager().getCommandTimerRemoved();
            message = message.replace("%timer%", name);
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         } else {
            message = this.plugin.getMessagesManager().getCommandTimerNotExist();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         }

         return true;
      }
   }
}
