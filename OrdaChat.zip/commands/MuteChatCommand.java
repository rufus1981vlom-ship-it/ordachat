package commands;

import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class MuteChatCommand implements CommandExecutor {
   private final OrdaChat plugin;
   private static boolean chatMuted = false;

   public MuteChatCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (sender.hasPermission(this.plugin.getConfigManager().getMuteChatPermission())) {
         chatMuted = !chatMuted;
         if (sender instanceof Player) {
            Player player = (Player)sender;
            message = chatMuted ? this.plugin.getTranslateColors().translateColors(player, prefix + this.plugin.getMessagesManager().getChatMute()) : this.plugin.getTranslateColors().translateColors(player, prefix + this.plugin.getMessagesManager().getChatUnmute());
         } else {
            message = chatMuted ? this.plugin.getTranslateColors().translateColors((Player)null, prefix + this.plugin.getMessagesManager().getChatMute()) : this.plugin.getTranslateColors().translateColors((Player)null, prefix + this.plugin.getMessagesManager().getChatUnmute());
         }

         sender.getServer().broadcastMessage(message);
      } else {
         message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
      }

      return true;
   }

   public static boolean isChatMuted() {
      return chatMuted;
   }
}
