package commands;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class IgnoreCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public IgnoreCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      if (!(sender instanceof Player)) {
         String message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return true;
      } else {
         Player player = (Player)sender;
         List blacklist = this.plugin.getConfigManager().getBlackLIgnore();
         String targetName;
         if (!sender.hasPermission("tchat.ignore") && !sender.hasPermission("tchat.admin")) {
            targetName = this.plugin.getMessagesManager().getNoPermission();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + targetName));
         } else {
            if (args.length == 0) {
               targetName = this.plugin.getMessagesManager().getIgnoreUsage();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + targetName));
               return true;
            }

            String addedMessage;
            if (args[0].equalsIgnoreCase("list")) {
               if (sender.hasPermission("tchat.ignore.list")) {
                  List<String> ignoreList = this.plugin.getSaveManager().getIgnoreList(player.getUniqueId());
                  String message;
                  if (ignoreList.isEmpty()) {
                     message = this.plugin.getMessagesManager().getIgnoreListEmpty();
                     sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  } else {
                     message = (String)ignoreList.stream().map(UUID::fromString).map((uuid) -> {
                        return this.plugin.getServer().getOfflinePlayer(uuid).getName();
                     }).collect(Collectors.joining(", "));
                     addedMessage = this.plugin.getMessagesManager().getIgnoreListMessage().replace("%players%", message);
                     sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + addedMessage));
                  }
               } else {
                  targetName = this.plugin.getMessagesManager().getNoPermission();
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + targetName));
               }

               return true;
            }

            if (args[0].equalsIgnoreCase("all")) {
               UUID senderId = player.getUniqueId();
               List<String> ignoreList = this.plugin.getSaveManager().getIgnoreList(senderId);
               if (ignoreList.contains("all")) {
                  addedMessage = this.plugin.getMessagesManager().getIgnoreAlready().replace("%player%", "all");
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + addedMessage));
                  ignoreList.remove("all");
                  this.plugin.getSaveManager().setIgnore(senderId, ignoreList);
                  return true;
               }

               ignoreList.add("all");
               this.plugin.getSaveManager().setIgnore(senderId, ignoreList);
               if (this.plugin.getConfigManager().isIgnoreLogEnabled()) {
                  this.plugin.getLogsManager().logIgnore(player.getName(), "all");
               }

               addedMessage = this.plugin.getMessagesManager().getIgnoreMessage().replace("%player%", "all");
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + addedMessage));
               return true;
            }

            targetName = args[0];
            Player target = this.plugin.getServer().getPlayer(targetName);
            if (target == null) {
               addedMessage = this.plugin.getMessagesManager().getPlayerNotFound().replace("%player%", targetName);
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + addedMessage));
               return true;
            }

            UUID senderId = player.getUniqueId();
            UUID targetId = target.getUniqueId();
            String message;
            if (blacklist.contains(targetId.toString())) {
               message = this.plugin.getMessagesManager().getIgnoreBlacklist().replace("%player%", target.getName());
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return true;
            }

            if (targetId.equals(senderId)) {
               message = this.plugin.getMessagesManager().getIgnoreSelf();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return true;
            }

            List<String> ignoreList = this.plugin.getSaveManager().getIgnoreList(senderId);
            String addedMessage;
            if (ignoreList.contains(targetId.toString())) {
               addedMessage = this.plugin.getMessagesManager().getIgnoreAlready().replace("%player%", target.getName());
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + addedMessage));
               this.plugin.getSaveManager().removeIgnore(senderId, targetId);
               return true;
            }

            ignoreList.add(targetId.toString());
            this.plugin.getSaveManager().setIgnore(senderId, ignoreList);
            if (this.plugin.getConfigManager().isIgnoreLogEnabled()) {
               this.plugin.getLogsManager().logIgnore(player.getName(), target.getName());
            }

            addedMessage = this.plugin.getMessagesManager().getIgnoreMessage().replace("%player%", target.getName());
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + addedMessage));
         }

         return true;
      }
   }
}
