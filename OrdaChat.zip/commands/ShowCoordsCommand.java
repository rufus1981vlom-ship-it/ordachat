package commands;

import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class ShowCoordsCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public ShowCoordsCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String noPermissionMessage;
      if (!(sender instanceof Player)) {
         noPermissionMessage = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + noPermissionMessage));
         return true;
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.scc") && !player.hasPermission("tchat.admin")) {
            noPermissionMessage = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + noPermissionMessage));
         } else {
            int x = player.getLocation().getBlockX();
            int y = player.getLocation().getBlockY();
            int z = player.getLocation().getBlockZ();
            String format = this.plugin.getConfigManager().getSccFormat();
            format = format.replace("%x", String.valueOf(x)).replace("%y", String.valueOf(y)).replace("%z", String.valueOf(z));
            Bukkit.broadcastMessage(this.plugin.getTranslateColors().translateColors(player, format));
         }

         return true;
      }
   }
}
