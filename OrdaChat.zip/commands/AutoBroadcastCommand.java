package commands;

import config.AutoBroadcastManager;
import java.util.ArrayList;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.conversations.Conversation;
import org.bukkit.conversations.ConversationContext;
import org.bukkit.conversations.ConversationFactory;
import org.bukkit.conversations.Prompt;
import org.bukkit.conversations.StringPrompt;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class AutoBroadcastCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public AutoBroadcastCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!sender.hasPermission("tchat.admin.autobroadcast") && !sender.hasPermission("tchat.command.autobroadcast.toggle")) {
         message = this.plugin.getMessagesManager().getNoPermission();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return false;
      } else if (args.length < 1) {
         message = this.plugin.getMessagesManager().getAutoBroadcastUsage();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return false;
      } else {
         AutoBroadcastManager autoBroadcastManager = this.plugin.getAutoBroadcastManager();
         String var9 = args[0].toLowerCase();
         byte var10 = -1;
         switch(var9.hashCode()) {
         case -934610812:
            if (var9.equals("remove")) {
               var10 = 3;
            }
            break;
         case -868304044:
            if (var9.equals("toggle")) {
               var10 = 5;
            }
            break;
         case 96417:
            if (var9.equals("add")) {
               var10 = 4;
            }
            break;
         case 3540994:
            if (var9.equals("stop")) {
               var10 = 1;
            }
            break;
         case 109757538:
            if (var9.equals("start")) {
               var10 = 0;
            }
            break;
         case 1097506319:
            if (var9.equals("restart")) {
               var10 = 2;
            }
         }

         switch(var10) {
         case 0:
            this.plugin.getAutoBroadcastSender().startBroadcastTask();
            String startMessage = this.plugin.getMessagesManager().getAutoBroadcastStart();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + startMessage));
            break;
         case 1:
            this.plugin.getAutoBroadcastSender().stopBroadcastTask();
            String stopMessage = this.plugin.getMessagesManager().getAutoBroadcastStop();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + stopMessage));
            break;
         case 2:
            this.plugin.getAutoBroadcastSender().restartBroadcasts();
            String restartMessage = this.plugin.getMessagesManager().getAutoBroadcastRestart();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + restartMessage));
            break;
         case 3:
            String broadcastKeyToRemove;
            if (args.length < 2) {
               broadcastKeyToRemove = this.plugin.getMessagesManager().getAutoBroadcastUsageRemove();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + broadcastKeyToRemove));
               return false;
            }

            broadcastKeyToRemove = args[1];
            autoBroadcastManager.removeBroadcast(broadcastKeyToRemove);
            String removeMessage = this.plugin.getMessagesManager().getAutoBroadcastRemove();
            removeMessage = removeMessage.replace("%broadcast%", broadcastKeyToRemove);
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + removeMessage));
            break;
         case 4:
            String newBroadcastKey;
            if (!(sender instanceof Player)) {
               newBroadcastKey = this.plugin.getMessagesManager().getNoPlayer();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + newBroadcastKey));
               return false;
            }

            Player player = (Player)sender;
            if (args.length < 2) {
               newBroadcastKey = this.plugin.getMessagesManager().getAutoBroadcastUsageAdd();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + newBroadcastKey));
               return false;
            }

            newBroadcastKey = args[1];
            this.startAddBroadcastConversation(player, newBroadcastKey);
            break;
         case 5:
            String m;
            if (!(sender instanceof Player)) {
               m = this.plugin.getMessagesManager().getNoPlayer();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
               return false;
            }

            Player player = (Player)sender;
            if (!player.hasPermission("tchat.admin") && !player.hasPermission("tchat.command.autobroadcast.toggle")) {
               m = this.plugin.getMessagesManager().getNoPermission();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + m));
               return false;
            }

            boolean isToggled = this.plugin.getAutoBroadcastManager().togglePlayerBroadcast(player);
            String toggleMessage = isToggled ? this.plugin.getMessagesManager().getAutoBroadcastToggleOff() : this.plugin.getMessagesManager().getAutoBroadcastToggleOn();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + toggleMessage));
            break;
         default:
            String usageMessage = this.plugin.getMessagesManager().getAutoBroadcastUsage();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + usageMessage));
            return false;
         }

         return true;
      }
   }

   private void startAddBroadcastConversation(Player player, String broadcastKey) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      ConversationFactory factory = (new ConversationFactory(this.plugin)).withFirstPrompt(new AutoBroadcastCommand.BroadcastNamePrompt(broadcastKey)).withLocalEcho(false).withEscapeSequence("cancel").thatExcludesNonPlayersWithMessage(this.plugin.getTranslateColors().translateColors(player, prefix + this.plugin.getMessagesManager().getNoPlayer()));
      Conversation conversation = factory.buildConversation(player);
      player.beginConversation(conversation);
   }

   private class BroadcastNamePrompt extends StringPrompt {
      private final String broadcastKey;

      public BroadcastNamePrompt(String broadcastKey) {
         this.broadcastKey = broadcastKey;
      }

      @NotNull
      public String getPromptText(@NotNull ConversationContext context) {
         String prefix = AutoBroadcastCommand.this.plugin.getMessagesManager().getPrefix();
         String message = AutoBroadcastCommand.this.plugin.getMessagesManager().getAutoBroadcastAddEnabled();
         return AutoBroadcastCommand.this.plugin.getTranslateColors().translateColors((Player)null, prefix + message);
      }

      @Contract("_, _ -> new")
      @NotNull
      public Prompt acceptInput(@NotNull ConversationContext context, String input) {
         assert input != null;

         boolean enabled = input.equalsIgnoreCase("yes");
         context.setSessionData("enabled", enabled);
         return AutoBroadcastCommand.this.new BroadcastMessagePrompt(this.broadcastKey, enabled);
      }
   }

   private class BroadcastActionsPrompt extends StringPrompt {
      private final String broadcastKey;
      private final boolean enabled;
      private final List<String> messages;

      public BroadcastActionsPrompt(String broadcastKey, boolean enabled, List<String> messages) {
         this.broadcastKey = broadcastKey;
         this.enabled = enabled;
         this.messages = (List)(messages != null ? messages : new ArrayList());
      }

      @NotNull
      public String getPromptText(@NotNull ConversationContext context) {
         String prefix = AutoBroadcastCommand.this.plugin.getMessagesManager().getPrefix();
         String message = AutoBroadcastCommand.this.plugin.getMessagesManager().getAutoBroadcastActionsPrompt();
         return AutoBroadcastCommand.this.plugin.getTranslateColors().translateColors((Player)null, prefix + message);
      }

      public Prompt acceptInput(@NotNull ConversationContext context, String input) {
         assert input != null;

         String lowerInput = input.toLowerCase();
         String prefix = AutoBroadcastCommand.this.plugin.getMessagesManager().getPrefix();
         boolean actionbarEnabledx;
         String actionbarx;
         if (lowerInput.equals("done")) {
            actionbarEnabledx = context.getSessionData("titleEnabled") != null ? (Boolean)context.getSessionData("titleEnabled") : false;
            actionbarx = (String)context.getSessionData("title");
            String subtitle = (String)context.getSessionData("subtitle");
            boolean soundEnabled = context.getSessionData("soundEnabled") != null ? (Boolean)context.getSessionData("soundEnabled") : false;
            String sound = (String)context.getSessionData("sound");
            boolean particlesEnabled = context.getSessionData("particlesEnabled") != null ? (Boolean)context.getSessionData("particlesEnabled") : false;
            String particle = (String)context.getSessionData("particle");
            int particleCount = context.getSessionData("particleCount") != null ? (Integer)context.getSessionData("particleCount") : 0;
            boolean actionbarEnabled = context.getSessionData("actionbarEnabled") != null ? (Boolean)context.getSessionData("actionbarEnabled") : false;
            String actionbar = (String)context.getSessionData("actionbar");
            String channel = context.getSessionData("channel") != null ? (String)context.getSessionData("channel") : "none";
            String permission = context.getSessionData("permission") != null ? (String)context.getSessionData("permission") : "none";
            AutoBroadcastCommand.this.plugin.getAutoBroadcastManager().addBroadcast(this.broadcastKey, this.enabled, this.messages, actionbarEnabledx, actionbarx, subtitle, soundEnabled, sound, particlesEnabled, particle, particleCount, actionbarEnabled, actionbar, channel, permission);
            String message = AutoBroadcastCommand.this.plugin.getMessagesManager().getAutoBroadcastAddAdded();
            message = message.replace("%broadcast%", this.broadcastKey);
            context.getForWhom().sendRawMessage(AutoBroadcastCommand.this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
            return Prompt.END_OF_CONVERSATION;
         } else {
            if (lowerInput.startsWith("title")) {
               actionbarEnabledx = true;
               actionbarx = lowerInput.substring(6).trim();
               context.setSessionData("titleEnabled", actionbarEnabledx);
               context.setSessionData("title", actionbarx);
            } else {
               String permissionx;
               if (lowerInput.startsWith("subtitle")) {
                  permissionx = lowerInput.substring(9).trim();
                  context.setSessionData("subtitle", permissionx);
               } else if (lowerInput.startsWith("sound")) {
                  actionbarEnabledx = true;
                  actionbarx = lowerInput.substring(6).trim();
                  context.setSessionData("soundEnabled", actionbarEnabledx);
                  context.setSessionData("sound", actionbarx);
               } else if (lowerInput.startsWith("particles")) {
                  try {
                     int count = Integer.parseInt(lowerInput.substring(11).trim());
                     context.setSessionData("particleCount", count);
                  } catch (NumberFormatException var18) {
                     context.getForWhom().sendRawMessage(AutoBroadcastCommand.this.plugin.getTranslateColors().translateColors((Player)null, prefix + "Invalid number for particles."));
                  }
               } else if (lowerInput.startsWith("particle")) {
                  actionbarEnabledx = true;
                  actionbarx = lowerInput.substring(9).trim();
                  context.setSessionData("particlesEnabled", actionbarEnabledx);
                  context.setSessionData("particle", actionbarx);
               } else if (lowerInput.startsWith("actionbar")) {
                  actionbarEnabledx = true;
                  actionbarx = lowerInput.substring(10).trim();
                  context.setSessionData("actionbarEnabled", actionbarEnabledx);
                  context.setSessionData("actionbar", actionbarx);
               } else if (lowerInput.startsWith("channel")) {
                  permissionx = lowerInput.substring(8).trim();
                  context.setSessionData("channel", permissionx);
               } else if (lowerInput.startsWith("permission")) {
                  permissionx = lowerInput.substring(10).trim();
                  context.setSessionData("permission", permissionx);
               } else {
                  context.getForWhom().sendRawMessage(AutoBroadcastCommand.this.plugin.getTranslateColors().translateColors((Player)null, prefix + "Unknown command. Use 'done' to finish."));
               }
            }

            return this;
         }
      }
   }

   private class BroadcastMessagePrompt extends StringPrompt {
      private final String broadcastKey;
      private final boolean enabled;

      public BroadcastMessagePrompt(String broadcastKey, boolean enabled) {
         this.broadcastKey = broadcastKey;
         this.enabled = enabled;
      }

      @NotNull
      public String getPromptText(@NotNull ConversationContext context) {
         String prefix = AutoBroadcastCommand.this.plugin.getMessagesManager().getPrefix();
         String message = AutoBroadcastCommand.this.plugin.getMessagesManager().getAutoBroadcastAddNewLine();
         return AutoBroadcastCommand.this.plugin.getTranslateColors().translateColors((Player)null, prefix + message);
      }

      public Prompt acceptInput(@NotNull ConversationContext context, String input) {
         if (input != null && !input.trim().isEmpty()) {
            List<String> messages = (List)context.getSessionData("messages");
            if (messages == null) {
               messages = new ArrayList();
               context.setSessionData("messages", messages);
            }

            String prefix = AutoBroadcastCommand.this.plugin.getMessagesManager().getPrefix();
            if (input.equalsIgnoreCase("done")) {
               if (((List)messages).isEmpty()) {
                  String message = AutoBroadcastCommand.this.plugin.getMessagesManager().getAutoBroadcastAddOneLine();
                  context.getForWhom().sendRawMessage(AutoBroadcastCommand.this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
                  return this;
               } else {
                  context.setSessionData("messages", messages);
                  return AutoBroadcastCommand.this.new BroadcastActionsPrompt(this.broadcastKey, this.enabled, (List)messages);
               }
            } else {
               ((List)messages).add(input);
               return this;
            }
         } else {
            return this;
         }
      }
   }
}
