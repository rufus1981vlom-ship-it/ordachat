package commands;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class Commands implements CommandExecutor, TabCompleter {
   private final OrdaChat plugin;

   public Commands(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      Objects.requireNonNull(plugin.getCommand("ordachat")).setExecutor(this);
      Objects.requireNonNull(plugin.getCommand("ordachat")).setTabCompleter(this);
   }

   @Override
   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
      Player player = sender instanceof Player ? (Player) sender : null;
      String message;
      String prefix;

      if (!sender.hasPermission("tchat.admin")
              && !sender.hasPermission("tchat.admin.version")
              && !sender.hasPermission("tchat.admin.reload")) {
         message = this.plugin.getMessagesManager().getNoPermission();
         prefix = this.plugin.getMessagesManager().getPrefix();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         return true;
      }

      if (args.length >= 1) {
         if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("tchat.admin") && !sender.hasPermission("tchat.admin.reload")) {
               message = this.plugin.getMessagesManager().getNoPermission();
               prefix = this.plugin.getMessagesManager().getPrefix();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return true;
            }

            this.plugin.getConfigManager().reloadConfig();
            this.plugin.getMessagesManager().reloadConfig();
            this.plugin.getGroupManager().reloadGroups();
            this.plugin.getBannedWordsManager().reloadBannedWords();
            this.plugin.getBannedCommandsManager().reloadConfig();
            this.plugin.getReplacerManager().reloadConfig();
            this.plugin.getSaveManager().reloadConfig();
            this.plugin.getChatColorManager().reloadConfig();
            this.plugin.getChannelsConfigManager().reloadConfig();
            this.plugin.getAutoBroadcastManager().reloadConfig();
            this.plugin.getChatBotManager().reloadConfig();
            this.plugin.getCommandTimerManager().reloadConfig();
            this.plugin.getChatGamesManager().reloadConfig();
            this.plugin.getCommandProgrammerManager().reloadConfig();
            this.plugin.getCommandsManager().reloadConfig();
            this.plugin.getDiscordManager().reloadConfig();
            this.plugin.getLevelsManager().reloadConfig();
            this.plugin.getWorldsManager().reloadConfig();
            this.plugin.getPlaceholdersConfig().reloadConfig();
            this.plugin.getJoinManager().reloadConfig();
            this.plugin.getMentionsManager().reloadConfig();
            this.plugin.getInvseeConfigManager().reloadConfig();
            this.plugin.getChatGamesSender().restartGame();
            this.plugin.getAutoBroadcastSender().restartBroadcasts();
            this.plugin.getTagsManager().reloadConfig();
            this.plugin.getTagsMenuConfigManager().reloadConfig();
            this.plugin.getTabCompleteListener().reloadConfig();

            message = this.plugin.getMessagesManager().getReloadMessage();
            prefix = this.plugin.getMessagesManager().getPrefix();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         }

         if (args[0].equalsIgnoreCase("version")) {
            if (!sender.hasPermission("tchat.admin") && !sender.hasPermission("tchat.admin.version")) {
               message = this.plugin.getMessagesManager().getNoPermission();
               prefix = this.plugin.getMessagesManager().getPrefix();
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return true;
            }

            String version = this.plugin.getDescription().getVersion();
            message = this.plugin.getMessagesManager().getVersionMessage().replace("%version%", version);
            prefix = this.plugin.getMessagesManager().getPrefix();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
            return true;
         }

         if (args[0].equalsIgnoreCase("clear")) {
            this.plugin.getChatClearCommand().onCommand(sender, command, alias, args);
            return true;
         }

         if (args[0].equalsIgnoreCase("mute")) {
            this.plugin.getMuteChatCommand().onCommand(sender, command, alias, args);
            return true;
         }

         message = this.plugin.getMessagesManager().getUnknownMessage();
         prefix = this.plugin.getMessagesManager().getPrefix();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         return true;
      }

      List<String> helpMessage = this.plugin.getMessagesManager().getChatMessage();
      Iterator<String> iterator = helpMessage.iterator();

      while (iterator.hasNext()) {
         String line = iterator.next();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, line));
      }

      return true;
   }

   @Override
   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
      List<String> completions = new ArrayList<>();

      if (args.length == 1) {
         if (sender.hasPermission("tchat.admin.reload") || sender.hasPermission("tchat.admin")) {
            completions.add("reload");
         }

         if (sender.hasPermission("tchat.admin.version") || sender.hasPermission("tchat.admin")) {
            completions.add("version");
         }

         if (sender.hasPermission("tchat.admin.chatclear") || sender.hasPermission("tchat.admin")) {
            completions.add("clear");
         }

         if (sender.hasPermission("tchat.admin.mutechat") || sender.hasPermission("tchat.admin")) {
            completions.add("mute");
         }
      }

      return completions;
   }
}