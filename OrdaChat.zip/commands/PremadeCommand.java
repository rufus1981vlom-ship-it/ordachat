package commands;

import config.BroadcastPremadeManager;
import java.util.Iterator;
import minealex.tchat.OrdaChat;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class PremadeCommand implements CommandExecutor {
   private final OrdaChat plugin;
   private final BroadcastPremadeManager broadcastManager;

   public PremadeCommand(@NotNull OrdaChat plugin) {
      this.plugin = plugin;
      this.broadcastManager = plugin.getBroadcastPremadeManager();
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      String p = this.plugin.getMessagesManager().getPrefix();
      String broadcastName;
      if (args.length >= 2 && args[0].equalsIgnoreCase("broadcast")) {
         broadcastName = args[1];
         BroadcastPremadeManager.Broadcast broadcast = (BroadcastPremadeManager.Broadcast)this.broadcastManager.getBroadcasts().get(broadcastName);
         if (broadcast == null) {
            String m = this.plugin.getMessagesManager().getBroadcastPremadeNull();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
            return false;
         } else {
            String[] broadcastArgs = new String[args.length - 2];
            System.arraycopy(args, 2, broadcastArgs, 0, args.length - 2);
            String joinedArgs = String.join(" ", broadcastArgs);
            Particle particle = Particle.valueOf(broadcast.getParticleType().toUpperCase());
            String sound = broadcast.getSound();
            double volume = (double)broadcast.getVolume();
            double pitch = (double)broadcast.getPitch();
            String title = broadcast.getTitle();
            String subtitle = broadcast.getSubtitle();
            String actionbar = broadcast.getActionBar();
            int particles = broadcast.getParticleAmount();
            Iterator var20 = Bukkit.getOnlinePlayers().iterator();

            while(var20.hasNext()) {
               Player player = (Player)var20.next();
               if (!broadcast.getMessage().isEmpty() && broadcast.isMessageEnabled()) {
                  Iterator var22 = broadcast.getMessage().iterator();

                  while(var22.hasNext()) {
                     String message = (String)var22.next();
                     message = message.replace("%args%", joinedArgs);
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, message));
                  }
               }

               if (broadcast.getTitle() != null && broadcast.getSubtitle() != null && broadcast.isTitleEnabled()) {
                  player.sendTitle(this.plugin.getTranslateColors().translateColors(player, title), subtitle, broadcast.getFadeIn(), broadcast.getStay(), broadcast.getFadeOut());
               }

               if (broadcast.getSound() != null && !broadcast.getSound().isEmpty() && broadcast.isSoundEnabled()) {
                  player.playSound(player.getLocation(), sound, (float)volume, (float)pitch);
               }

               if (broadcast.getActionBar() != null && !broadcast.getActionBar().isEmpty() && broadcast.isActionBarEnabled()) {
                  player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(this.plugin.getTranslateColors().translateColors(player, actionbar)));
               }

               if (broadcast.isParticlesEnabled()) {
                  player.getWorld().spawnParticle(particle, player.getLocation(), particles);
               }
            }

            String m = this.plugin.getMessagesManager().getBroadcastSent();
            m = m.replace("%broadcast%", broadcastName);
            sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + m));
            return true;
         }
      } else {
         broadcastName = this.plugin.getMessagesManager().getUsagePremade();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, p + broadcastName));
         return false;
      }
   }
}
