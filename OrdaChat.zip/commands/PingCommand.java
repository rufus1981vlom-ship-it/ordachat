package commands;

import minealex.tchat.OrdaChat;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class PingCommand implements CommandExecutor {
   private final OrdaChat plugin;

   public PingCommand(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String message;
      if (!(sender instanceof Player)) {
         message = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + message));
         return true;
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.ping") && !player.hasPermission("tchat.admin")) {
            message = this.plugin.getMessagesManager().getNoPermission();
            sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
         } else {
            String message;
            String message;
            if (args.length == 0) {
               int ping = player.getPing();
               message = this.plugin.getMessagesManager().getPing();
               message = this.plugin.getConfigManager().getColorForPing(ping);
               message = message.replace("%ping%", String.valueOf(ping)).replace("%color%", message);
               sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               return true;
            }

            if (args.length == 1) {
               Player target = Bukkit.getPlayer(args[0]);
               if (target != null) {
                  int ping = target.getPing();
                  message = this.plugin.getMessagesManager().getOtherPing();
                  String color = this.plugin.getConfigManager().getColorForPing(ping);
                  message = message.replace("%player%", target.getName()).replace("%ping%", String.valueOf(ping)).replace("%color%", color);
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               } else {
                  message = this.plugin.getMessagesManager().getPlayerNotFound();
                  sender.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               }

               return true;
            }
         }

         return true;
      }
   }
}
