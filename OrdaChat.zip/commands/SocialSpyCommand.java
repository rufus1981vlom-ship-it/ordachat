package commands;

import config.ConfigManager;
import java.util.ArrayList;
import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SocialSpyCommand implements CommandExecutor, TabCompleter {
   private final OrdaChat plugin;
   private final ConfigManager configManager;

   public SocialSpyCommand(OrdaChat plugin) {
      this.plugin = plugin;
      this.configManager = plugin.getConfigManager();
   }

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      String prefix = this.plugin.getMessagesManager().getPrefix();
      String action;
      if (!(sender instanceof Player)) {
         action = this.plugin.getMessagesManager().getNoPlayer();
         sender.sendMessage(this.plugin.getTranslateColors().translateColors((Player)null, prefix + action));
         return true;
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("tchat.admin.command.social-spy") && !player.hasPermission("tchat.admin")) {
            action = this.plugin.getMessagesManager().getNoPermission();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + action));
            return true;
         } else if (args.length == 0) {
            action = this.plugin.getMessagesManager().getUsageSocialSpy();
            player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + action));
            return true;
         } else {
            action = args[0].toLowerCase();
            FileConfiguration config = this.configManager.getConfig();
            if (config == null) {
               player.sendMessage("[ERROR] SocialSpyCommand.java - Error in config.yml! (#7a8cn)");
               return true;
            } else {
               byte var11 = -1;
               switch(action.hashCode()) {
               case -1298848381:
                  if (action.equals("enable")) {
                     var11 = 0;
                  }
                  break;
               case 3357091:
                  if (action.equals("mode")) {
                     var11 = 2;
                  }
                  break;
               case 1671308008:
                  if (action.equals("disable")) {
                     var11 = 1;
                  }
               }

               String message;
               switch(var11) {
               case 0:
                  if (this.plugin.getConfigManager().isSpyEnabled()) {
                     message = this.plugin.getMessagesManager().getAlreadyEnabledSpy();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  } else {
                     config.set("spy.commands.enabled", true);
                     this.configManager.saveConfig();
                     this.configManager.reloadConfig();
                     message = this.plugin.getMessagesManager().getEnabledSpy();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  }
                  break;
               case 1:
                  if (!this.plugin.getConfigManager().isSpyEnabled()) {
                     message = this.plugin.getMessagesManager().getAlreadyDisabledSpy();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  } else {
                     config.set("spy.commands.enabled", false);
                     this.configManager.saveConfig();
                     message = this.plugin.getMessagesManager().getDisabledSpy();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                  }
                  break;
               case 2:
                  if (args.length < 2) {
                     message = this.plugin.getMessagesManager().getInvalidModeSpy();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                     return true;
                  }

                  try {
                     int mode = Integer.parseInt(args[1]);
                     if (mode >= 1 && mode <= 3) {
                        config.set("spy.commands.mode", mode);
                        this.configManager.saveConfig();
                        this.configManager.reloadConfig();
                        message = this.plugin.getMessagesManager().getModeSpy();
                        player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message).replace("%mode%", String.valueOf(mode)));
                        break;
                     }

                     message = this.plugin.getMessagesManager().getInvalidModeSpy();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                     return true;
                  } catch (NumberFormatException var13) {
                     message = this.plugin.getMessagesManager().getInvalidModeSpy();
                     player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
                     break;
                  }
               default:
                  message = this.plugin.getMessagesManager().getUsageSocialSpy();
                  player.sendMessage(this.plugin.getTranslateColors().translateColors(player, prefix + message));
               }

               return true;
            }
         }
      }
   }

   @Nullable
   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      List<String> completions = new ArrayList();
      if (!(sender instanceof Player)) {
         return null;
      } else {
         if (args.length == 1) {
            completions.add("enable");
            completions.add("disable");
            completions.add("mode");
         } else if (args.length == 2 && "mode".equalsIgnoreCase(args[0])) {
            completions.add("1");
            completions.add("2");
            completions.add("3");
         }

         return completions;
      }
   }
}
