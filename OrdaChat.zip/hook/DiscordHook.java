package hook;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import minealex.tchat.OrdaChat;
import org.jetbrains.annotations.NotNull;

public class DiscordHook {
   private final OrdaChat plugin;

   public DiscordHook(OrdaChat plugin) {
      this.plugin = plugin;
   }

   public void sendMessage(String message, String URL) {
      HttpURLConnection connection = null;

      try {
         URL url = new URL(URL);
         connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json; utf-8");
         connection.setRequestProperty("Accept", "application/json");
         connection.setDoOutput(true);
         String var10000 = this.escapeJson(message);
         String jsonPayload = "{\"content\": \"" + var10000 + "\"}";
         OutputStream os = connection.getOutputStream();

         try {
            byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
         } catch (Throwable var15) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var14) {
                  var15.addSuppressed(var14);
               }
            }

            throw var15;
         }

         if (os != null) {
            os.close();
         }

         int code = connection.getResponseCode();
         if (code != 204) {
            this.plugin.getLogger().info("Failed to send message. HTTP error code: " + code);
         }
      } catch (Exception var16) {
         var16.printStackTrace();
      } finally {
         if (connection != null) {
            connection.disconnect();
         }

      }

   }

   public void sendJoinMessage(String username) {
      if (this.plugin.getDiscordManager().isJoinEnabled()) {
         HttpURLConnection connection = null;

         try {
            URL url = new URL(this.plugin.getDiscordManager().getDiscordHook());
            connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            String jsonPayload = this.buildEmbedJoin(username);
            OutputStream os = connection.getOutputStream();

            try {
               byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
               os.write(input, 0, input.length);
            } catch (Throwable var14) {
               if (os != null) {
                  try {
                     os.close();
                  } catch (Throwable var13) {
                     var14.addSuppressed(var13);
                  }
               }

               throw var14;
            }

            if (os != null) {
               os.close();
            }

            int code = connection.getResponseCode();
            if (code != 204) {
               this.plugin.getLogger().info("Failed to send message. HTTP error code: " + code);
            }
         } catch (Exception var15) {
            var15.printStackTrace();
         } finally {
            if (connection != null) {
               connection.disconnect();
            }

         }
      }

   }

   public void sendLeftMessage(String username) {
      if (this.plugin.getDiscordManager().isQuitEnabled()) {
         HttpURLConnection connection = null;

         try {
            URL url = new URL(this.plugin.getDiscordManager().getDiscordHook());
            connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            String jsonPayload = this.buildEmbedLeft(username);
            OutputStream os = connection.getOutputStream();

            try {
               byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
               os.write(input, 0, input.length);
            } catch (Throwable var14) {
               if (os != null) {
                  try {
                     os.close();
                  } catch (Throwable var13) {
                     var14.addSuppressed(var13);
                  }
               }

               throw var14;
            }

            if (os != null) {
               os.close();
            }

            int code = connection.getResponseCode();
            if (code != 204) {
               this.plugin.getLogger().info("Failed to send message. HTTP error code: " + code);
            }
         } catch (Exception var15) {
            var15.printStackTrace();
         } finally {
            if (connection != null) {
               connection.disconnect();
            }

         }
      }

   }

   @NotNull
   private String buildEmbedLeft(String username) {
      String descriptionTemplate = this.plugin.getDiscordManager().getQuitDescription();
      String description = descriptionTemplate.replace("%player%", this.escapeJson(username));
      String avatarUrl = "https://mc-heads.net/avatar/" + username;
      StringBuilder embedBuilder = new StringBuilder();
      embedBuilder.append("{").append("\"embeds\": [{").append("\"title\": \"").append(this.plugin.getDiscordManager().getQuitTitle()).append("\",").append("\"description\": \"").append(this.escapeJson(description)).append("\",").append("\"color\": ").append(this.plugin.getDiscordManager().getQuitColor());
      if (this.plugin.getDiscordManager().isQuitAvatarEnabled()) {
         embedBuilder.append(",").append("\"thumbnail\": {").append("\"url\": \"").append(this.escapeJson(avatarUrl)).append("\"").append("}");
      }

      embedBuilder.append("}]").append("}");
      return embedBuilder.toString();
   }

   @NotNull
   private String buildEmbedJoin(String username) {
      String descriptionTemplate = this.plugin.getDiscordManager().getJoinDescription();
      String description = descriptionTemplate.replace("%player%", this.escapeJson(username));
      String avatarUrl = "https://mc-heads.net/avatar/" + username;
      StringBuilder embedBuilder = new StringBuilder();
      embedBuilder.append("{").append("\"embeds\": [{").append("\"title\": \"").append(this.plugin.getDiscordManager().getJoinTitle()).append("\",").append("\"description\": \"").append(this.escapeJson(description)).append("\",").append("\"color\": ").append(this.plugin.getDiscordManager().getJoinColor());
      if (this.plugin.getDiscordManager().isJoinAvatarEnabled()) {
         embedBuilder.append(",").append("\"thumbnail\": {").append("\"url\": \"").append(this.escapeJson(avatarUrl)).append("\"").append("}");
      }

      embedBuilder.append("}]").append("}");
      return embedBuilder.toString();
   }

   public void sendDeathMessage(String username) {
      if (this.plugin.getDiscordManager().isDeathEnabled()) {
         HttpURLConnection connection = null;

         try {
            URL url = new URL(this.plugin.getDiscordManager().getDiscordHook());
            connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            String jsonPayload = this.buildEmbedDeath(username);
            OutputStream os = connection.getOutputStream();

            try {
               byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
               os.write(input, 0, input.length);
            } catch (Throwable var14) {
               if (os != null) {
                  try {
                     os.close();
                  } catch (Throwable var13) {
                     var14.addSuppressed(var13);
                  }
               }

               throw var14;
            }

            if (os != null) {
               os.close();
            }

            int code = connection.getResponseCode();
            if (code != 204) {
               this.plugin.getLogger().info("Failed to send message. HTTP error code: " + code);
            }
         } catch (Exception var15) {
            var15.printStackTrace();
         } finally {
            if (connection != null) {
               connection.disconnect();
            }

         }
      }

   }

   @NotNull
   private String buildEmbedDeath(String username) {
      String descriptionTemplate = this.plugin.getDiscordManager().getDeathDescription();
      String description = descriptionTemplate.replace("%player%", this.escapeJson(username));
      String avatarUrl = "https://mc-heads.net/avatar/" + username;
      StringBuilder embedBuilder = new StringBuilder();
      embedBuilder.append("{").append("\"embeds\": [{").append("\"title\": \"").append(this.plugin.getDiscordManager().getDeathTitle()).append("\",").append("\"description\": \"").append(this.escapeJson(description)).append("\",").append("\"color\": ").append(this.plugin.getDiscordManager().getDeathColor());
      if (this.plugin.getDiscordManager().isDeathAvatarEnabled()) {
         embedBuilder.append(",").append("\"thumbnail\": {").append("\"url\": \"").append(this.escapeJson(avatarUrl)).append("\"").append("}");
      }

      embedBuilder.append("}]").append("}");
      return embedBuilder.toString();
   }

   public void sendBannedWordEmbed(String playerName, String word, String message, String URL) {
      HttpURLConnection connection = null;

      try {
         URL url = new URL(URL);
         connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json; utf-8");
         connection.setRequestProperty("Accept", "application/json");
         connection.setDoOutput(true);
         String jsonPayload = this.buildEmbedBannedWord(playerName, word, message);
         OutputStream os = connection.getOutputStream();

         try {
            byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
         } catch (Throwable var17) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var16) {
                  var17.addSuppressed(var16);
               }
            }

            throw var17;
         }

         if (os != null) {
            os.close();
         }

         int code = connection.getResponseCode();
         if (code != 204) {
            this.plugin.getLogger().info("Failed to send message. HTTP error code: " + code);
         }
      } catch (Exception var18) {
         var18.printStackTrace();
      } finally {
         if (connection != null) {
            connection.disconnect();
         }

      }

   }

   @NotNull
   private String buildEmbedBannedWord(String playerName, String word, String message) {
      String title = this.plugin.getDiscordManager().getBannedWordsTitle();
      String descriptionTemplate = this.plugin.getDiscordManager().getBannedWordsDescription();
      int color = this.plugin.getDiscordManager().getBannedWordsColor();
      boolean avatarEnabled = this.plugin.getDiscordManager().isBannedWordsAvatar();
      String description = descriptionTemplate.replace("%player%", this.escapeJson(playerName)).replace("%word%", this.escapeJson(word)).replace("%message%", this.escapeJson(message));
      String avatarUrl = "https://mc-heads.net/avatar/" + playerName;
      StringBuilder embedBuilder = new StringBuilder();
      embedBuilder.append("{").append("\"embeds\": [{").append("\"title\": \"").append(this.escapeJson(title)).append("\",").append("\"description\": \"").append(this.escapeJson(description)).append("\",").append("\"color\": ").append(color);
      if (avatarEnabled) {
         embedBuilder.append(",").append("\"thumbnail\": {").append("\"url\": \"").append(this.escapeJson(avatarUrl)).append("\"").append("}");
      }

      embedBuilder.append("}]").append("}");
      return embedBuilder.toString();
   }

   public void sendMuteEmbed(String playerName, String senderName, String URL) {
      HttpURLConnection connection = null;

      try {
         URL url = new URL(URL);
         connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json; utf-8");
         connection.setRequestProperty("Accept", "application/json");
         connection.setDoOutput(true);
         String jsonPayload = this.buildEmbedMute(playerName, senderName);
         OutputStream os = connection.getOutputStream();

         try {
            byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
         } catch (Throwable var16) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var15) {
                  var16.addSuppressed(var15);
               }
            }

            throw var16;
         }

         if (os != null) {
            os.close();
         }

         int code = connection.getResponseCode();
         if (code != 204) {
            this.plugin.getLogger().info("Failed to send message. HTTP error code: " + code);
         }
      } catch (Exception var17) {
         var17.printStackTrace();
      } finally {
         if (connection != null) {
            connection.disconnect();
         }

      }

   }

   @NotNull
   private String buildEmbedMute(String playerName, @NotNull String senderName) {
      String title = this.plugin.getDiscordManager().getMuteTitle();
      String descriptionTemplate = this.plugin.getDiscordManager().getMuteDescription();
      int color = this.plugin.getDiscordManager().getMuteColor();
      boolean avatarEnabled = this.plugin.getDiscordManager().isMuteAvatar();
      String description = descriptionTemplate.replace("%player%", this.escapeJson(playerName)).replace("%admin%", this.escapeJson(senderName));
      String avatarUrl = "https://mc-heads.net/avatar/" + playerName;
      StringBuilder embedBuilder = new StringBuilder();
      embedBuilder.append("{").append("\"embeds\": [{").append("\"title\": \"").append(this.escapeJson(title)).append("\",").append("\"description\": \"").append(this.escapeJson(description)).append("\",").append("\"color\": ").append(color);
      if (avatarEnabled) {
         embedBuilder.append(",").append("\"thumbnail\": {").append("\"url\": \"").append(this.escapeJson(avatarUrl)).append("\"").append("}");
      }

      embedBuilder.append("}]").append("}");
      return embedBuilder.toString();
   }

   public void sendBannedCommandEmbed(String playerName, String word, String message, String URL) {
      HttpURLConnection connection = null;

      try {
         URL url = new URL(URL);
         connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("POST");
         connection.setRequestProperty("Content-Type", "application/json; utf-8");
         connection.setRequestProperty("Accept", "application/json");
         connection.setDoOutput(true);
         String jsonPayload = this.buildEmbedBannedCommand(playerName, word, message);
         OutputStream os = connection.getOutputStream();

         try {
            byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
         } catch (Throwable var17) {
            if (os != null) {
               try {
                  os.close();
               } catch (Throwable var16) {
                  var17.addSuppressed(var16);
               }
            }

            throw var17;
         }

         if (os != null) {
            os.close();
         }

         int code = connection.getResponseCode();
         if (code != 204) {
            this.plugin.getLogger().info("Failed to send message. HTTP error code: " + code);
         }
      } catch (Exception var18) {
         var18.printStackTrace();
      } finally {
         if (connection != null) {
            connection.disconnect();
         }

      }

   }

   @NotNull
   private String buildEmbedBannedCommand(String playerName, String word, String message) {
      String title = this.plugin.getDiscordManager().getBannedCommandsTitle();
      String descriptionTemplate = this.plugin.getDiscordManager().getBannedCommandsDescription();
      int color = this.plugin.getDiscordManager().getBannedCommandsColor();
      boolean avatarEnabled = this.plugin.getDiscordManager().isBannedCommandsAvatar();
      String description = descriptionTemplate.replace("%player%", this.escapeJson(playerName)).replace("%word%", this.escapeJson(word)).replace("%message%", this.escapeJson(message));
      String avatarUrl = "https://mc-heads.net/avatar/" + playerName;
      StringBuilder embedBuilder = new StringBuilder();
      embedBuilder.append("{").append("\"embeds\": [{").append("\"title\": \"").append(this.escapeJson(title)).append("\",").append("\"description\": \"").append(this.escapeJson(description)).append("\",").append("\"color\": ").append(color);
      if (avatarEnabled) {
         embedBuilder.append(",").append("\"thumbnail\": {").append("\"url\": \"").append(this.escapeJson(avatarUrl)).append("\"").append("}");
      }

      embedBuilder.append("}]").append("}");
      return embedBuilder.toString();
   }

   @NotNull
   private String escapeJson(@NotNull String message) {
      return message.replace("\\", "\\\\").replace("\"", "\\\"").replace("\b", "\\b").replace("\f", "\\f").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
   }
}
