package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class ChannelsConfigManager {
   private final ConfigFile channelsFile;
   private final Map<String, ChannelsConfigManager.Channel> channels = new HashMap();

   public ChannelsConfigManager(OrdaChat plugin) {
      this.channelsFile = new ConfigFile("channels.yml", (String)null, plugin);
      this.channelsFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.channelsFile.getConfig();
      this.channels.clear();
      Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("channels"))).getKeys(false).iterator();

      while(var2.hasNext()) {
         String channelName = (String)var2.next();
         String path = "channels." + channelName + ".";
         boolean enabled = config.getBoolean(path + "enabled");
         String permission = config.getString(path + "permission");
         boolean formatEnabled = config.getBoolean(path + "format.enabled");
         String format = config.getString(path + "format.format");
         int messageMode = config.getInt(path + "message-mode");
         int announceMode = config.getInt(path + "announce-mode");
         int pLimit = config.getInt(path + ".channel-limit", 0);
         boolean discordEnabled = config.getBoolean(path + "discord.enabled");
         String discordHook = config.getString(path + "discord.hook", "");
         boolean cooldownEnabled = config.getBoolean(path + "cooldown.enabled");
         int cooldown = config.getInt(path + "cooldown.cooldown");
         this.channels.put(channelName, new ChannelsConfigManager.Channel(enabled, permission, format, formatEnabled, messageMode, announceMode, pLimit, discordEnabled, discordHook, cooldownEnabled, cooldown));
      }

   }

   public void reloadConfig() {
      this.channelsFile.reloadConfig();
      this.loadConfig();
   }

   public Map<String, ChannelsConfigManager.Channel> getChannels() {
      return this.channels;
   }

   public ChannelsConfigManager.Channel getChannel(String name) {
      return (ChannelsConfigManager.Channel)this.channels.get(name);
   }

   public static record Channel(boolean enabled, String permission, String format, boolean formatEnabled, int messageMode, int announceMode, int pLimit, boolean discordEnabled, String discordHook, boolean cooldownEnabled, int cooldown) {
      public Channel(boolean enabled, String permission, String format, boolean formatEnabled, int messageMode, int announceMode, int pLimit, boolean discordEnabled, String discordHook, boolean cooldownEnabled, int cooldown) {
         this.enabled = enabled;
         this.permission = permission;
         this.format = format;
         this.formatEnabled = formatEnabled;
         this.messageMode = messageMode;
         this.announceMode = announceMode;
         this.pLimit = pLimit;
         this.discordEnabled = discordEnabled;
         this.discordHook = discordHook;
         this.cooldownEnabled = cooldownEnabled;
         this.cooldown = cooldown;
      }

      public boolean enabled() {
         return this.enabled;
      }

      public String permission() {
         return this.permission;
      }

      public String format() {
         return this.format;
      }

      public boolean formatEnabled() {
         return this.formatEnabled;
      }

      public int messageMode() {
         return this.messageMode;
      }

      public int announceMode() {
         return this.announceMode;
      }

      public int pLimit() {
         return this.pLimit;
      }

      public boolean discordEnabled() {
         return this.discordEnabled;
      }

      public String discordHook() {
         return this.discordHook;
      }

      public boolean cooldownEnabled() {
         return this.cooldownEnabled;
      }

      public int cooldown() {
         return this.cooldown;
      }
   }
}
