package config;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class SaveManager {
   private final ConfigFile savesFile;
   private FileConfiguration config;

   public SaveManager(OrdaChat plugin) {
      this.savesFile = new ConfigFile("saves.yml", (String)null, plugin);
      this.savesFile.registerConfig();
      this.config = this.savesFile.getConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      this.config = this.savesFile.getConfig();
   }

   public void reloadConfig() {
      this.savesFile.reloadConfig();
      this.loadConfig();
   }

   public void removeChatColor(@NotNull UUID playerId) {
      String path = "players." + playerId + ".chatcolor";
      this.config.set(path, (Object)null);
      this.savesFile.saveConfig();
   }

   public void removeFormat(@NotNull UUID playerId) {
      String path = "players." + playerId + ".format";
      this.config.set(path, (Object)null);
      this.savesFile.saveConfig();
   }

   public void saveSelectedTag(@NotNull UUID playerId, String tag) {
      String path = "players." + playerId + ".selected-tag";
      this.config.set(path, tag);
      this.savesFile.saveConfig();
   }

   public String getSelectedTag(@NotNull UUID playerId) {
      String path = "players." + playerId + ".selected-tag";
      return this.config.getString(path, (String)null);
   }

   public String getChatColor(@NotNull UUID playerId) {
      String path = "players." + playerId + ".chatcolor";
      return this.config.getString(path, "");
   }

   public void setChatColor(@NotNull UUID playerId, String chatColor) {
      String path = "players." + playerId + ".chatcolor";
      this.config.set(path, chatColor);
      this.savesFile.saveConfig();
   }

   public void setNick(@NotNull UUID playerId, String nick) {
      String path = "players." + playerId + ".nick";
      this.config.set(path, nick);
      this.savesFile.saveConfig();
   }

   public String getNick(@NotNull UUID playerId, @NotNull Player p) {
      String path = "players." + playerId + ".nick";
      return this.config.getString(path, p.getName());
   }

   public int getChatGamesWins(@NotNull UUID playerId) {
      String path = "players." + playerId + ".chatgames-wins";
      return this.config.getInt(path, 0);
   }

   public void setChatGamesWins(@NotNull UUID playerId, int chatGamesWins) {
      String path = "players." + playerId + ".chatgames-wins";
      this.config.set(path, chatGamesWins);
      this.savesFile.saveConfig();
   }

   public List<String> getIgnoreList(@NotNull UUID playerId) {
      String path = "players." + playerId + ".ignore";
      return this.config.getStringList(path);
   }

   public void setIgnore(@NotNull UUID playerId, List<String> ignoreList) {
      String path = "players." + playerId + ".ignore";
      this.config.set(path, ignoreList);
      this.savesFile.saveConfig();
   }

   public void removeIgnore(@NotNull UUID playerId, @NotNull UUID targetId) {
      String path = "players." + playerId + ".ignore";
      List<String> ignoreList = this.config.getStringList(path);
      if (ignoreList.remove(targetId.toString())) {
         this.config.set(path, ignoreList);
         this.savesFile.saveConfig();
      }

   }

   public String getFormat(@NotNull UUID playerId) {
      String path = "players." + playerId + ".format";
      return this.config.getString(path, "");
   }

   public int getLevel(@NotNull UUID playerId) {
      String path = "players." + playerId + ".level";

      try {
         return this.config.getInt(path, 0);
      } catch (Exception var4) {
         return 0;
      }
   }

   public int getXp(@NotNull UUID playerId) {
      String path = "players." + playerId + ".xp";

      try {
         return this.config.getInt(path, 0);
      } catch (Exception var4) {
         return 0;
      }
   }

   public void setLevel(@NotNull UUID playerId, int level) {
      String path = "players." + playerId + ".level";
      this.config.set(path, level);
      this.savesFile.saveConfig();
   }

   public void setXp(@NotNull UUID playerId, int xp) {
      String path = "players." + playerId + ".xp";
      this.config.set(path, xp);
      this.savesFile.saveConfig();
   }

   public void setFormat(@NotNull UUID playerId, String format) {
      String path = "players." + playerId + ".format";
      this.config.set(path, format);
      this.savesFile.saveConfig();
   }

   public UUID getPlayerIdByNick(String nick) {
      if (this.config.getConfigurationSection("players") == null) {
         return null;
      } else {
         Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(this.config.getConfigurationSection("players"))).getKeys(false).iterator();

         String playerKey;
         String storedNick;
         do {
            if (!var2.hasNext()) {
               return null;
            }

            playerKey = (String)var2.next();
            storedNick = this.config.getString("players." + playerKey + ".nick");
         } while(storedNick == null || !storedNick.equalsIgnoreCase(nick));

         return UUID.fromString(playerKey);
      }
   }

   public List<UUID> getAllPlayerUUIDs() {
      return this.config.getConfigurationSection("players") == null ? List.of() : ((ConfigurationSection)Objects.requireNonNull(this.config.getConfigurationSection("players"))).getKeys(false).stream().map(UUID::fromString).toList();
   }

   public void mutePlayer(@NotNull UUID playerId, long duration) {
      String path = "players." + playerId + ".mute";
      this.config.set(path + ".duration", duration);
      this.config.set(path + ".startTime", System.currentTimeMillis());
      this.savesFile.saveConfig();
   }

   public boolean isPlayerMuted(@NotNull UUID playerId) {
      String path = "players." + playerId + ".mute";
      if (!this.config.contains(path)) {
         return false;
      } else {
         long duration = this.config.getLong(path + ".duration", 0L);
         long startTime = this.config.getLong(path + ".startTime", 0L);
         if (duration == -1L) {
            return true;
         } else if (System.currentTimeMillis() - startTime >= duration) {
            this.config.set(path, (Object)null);
            this.savesFile.saveConfig();
            return false;
         } else {
            return true;
         }
      }
   }
}
