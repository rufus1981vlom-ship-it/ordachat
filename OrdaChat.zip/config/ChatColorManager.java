package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class ChatColorManager {
   private final ConfigFile messagesFile;
   private String title;
   private Material topMaterial;
   private Material leftMaterial;
   private Material rightMaterial;
   private Material bottomMaterial;
   private int amountTop;
   private int amountLeft;
   private int amountRight;
   private int amountBottom;
   private Material closeMaterial;
   private int closeSlot;
   private int amountClose;
   private String topName;
   private String leftName;
   private String rightName;
   private String bottomName;
   private String closeName;
   private List<String> loreTop;
   private List<String> loreLeft;
   private List<String> loreRight;
   private List<String> loreBottom;
   private List<String> loreClose;
   private int addTop;
   private int startTop;
   private int endTop;
   private int addLeft;
   private int startLeft;
   private int endLeft;
   private int addRight;
   private int startRight;
   private int endRight;
   private int addBottom;
   private int startBottom;
   private int endBottom;
   private int slots;
   private long cooldown;
   public final Map<String, ChatColorManager.ChatColorItem> items = new HashMap();
   private static final String MENU_TITLE = "menu.title";
   private static final String SLOTS = "menu.slots";
   private static final String COOLDOWN = "menu.cooldown";
   private static final String MENU_BACKGROUND_TOP_MATERIAL = "menu.background.top.material";
   private static final String MENU_BACKGROUND_LEFT_MATERIAL = "menu.background.left.material";
   private static final String MENU_BACKGROUND_RIGHT_MATERIAL = "menu.background.right.material";
   private static final String MENU_BACKGROUND_BOTTOM_MATERIAL = "menu.background.bottom.material";
   private static final String MENU_BACKGROUND_TOP_AMOUNT = "menu.background.top.amount";
   private static final String MENU_BACKGROUND_LEFT_AMOUNT = "menu.background.left.amount";
   private static final String MENU_BACKGROUND_RIGHT_AMOUNT = "menu.background.right.amount";
   private static final String MENU_BACKGROUND_BOTTOM_AMOUNT = "menu.background.bottom.amount";
   private static final String MENU_BACKGROUND_CLOSE_MATERIAL = "menu.background.close.material";
   private static final String MENU_BACKGROUND_CLOSE_AMOUNT = "menu.background.close.amount";
   private static final String MENU_BACKGROUND_CLOSE_SLOT = "menu.background.close.slot";
   private static final String MENU_BACKGROUND_TOP_NAME = "menu.background.top.name";
   private static final String MENU_BACKGROUND_LEFT_NAME = "menu.background.left.name";
   private static final String MENU_BACKGROUND_CLOSE_NAME = "menu.background.close.name";
   private static final String MENU_BACKGROUND_RIGHT_NAME = "menu.background.right.name";
   private static final String MENU_BACKGROUND_BOTTOM_NAME = "menu.background.bottom.name";
   private static final String MENU_BACKGROUND_TOP_LORE = "menu.background.top.lore";
   private static final String MENU_BACKGROUND_LEFT_LORE = "menu.background.left.lore";
   private static final String MENU_BACKGROUND_RIGHT_LORE = "menu.background.right.lore";
   private static final String MENU_BACKGROUND_BOTTOM_LORE = "menu.background.bottom.lore";
   private static final String MENU_BACKGROUND_CLOSE_LORE = "menu.background.close.lore";
   private static final String MENU_BACKGROUND_TOP_ADD = "menu.background.top.for.add";
   private static final String MENU_BACKGROUND_TOP_START = "menu.background.top.for.start-slot";
   private static final String MENU_BACKGROUND_TOP_END = "menu.background.top.for.end-slot";
   private static final String MENU_BACKGROUND_LEFT_ADD = "menu.background.left.for.add";
   private static final String MENU_BACKGROUND_LEFT_START = "menu.background.left.for.start-slot";
   private static final String MENU_BACKGROUND_LEFT_END = "menu.background.left.for.end-slot";
   private static final String MENU_BACKGROUND_RIGHT_ADD = "menu.background.right.for.add";
   private static final String MENU_BACKGROUND_RIGHT_START = "menu.background.right.for.start-slot";
   private static final String MENU_BACKGROUND_RIGHT_END = "menu.background.right.for.end-slot";
   private static final String MENU_BACKGROUND_BOTTOM_ADD = "menu.background.bottom.for.add";
   private static final String MENU_BACKGROUND_BOTTOM_START = "menu.background.bottom.for.start-slot";
   private static final String MENU_BACKGROUND_BOTTOM_END = "menu.background.bottom.for.end-slot";
   private static final String MENU_ITEMS_PREFIX = "menu.items.";

   public ChatColorManager(OrdaChat plugin) {
      this.messagesFile = new ConfigFile("chatcolor.yml", "menus", plugin);
      this.messagesFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.messagesFile.getConfig();
      this.title = config.getString("menu.title");
      this.slots = config.getInt("menu.slots");
      this.cooldown = config.getLong("menu.cooldown");
      this.topMaterial = Material.valueOf(config.getString("menu.background.top.material"));
      this.leftMaterial = Material.valueOf(config.getString("menu.background.left.material"));
      this.rightMaterial = Material.valueOf(config.getString("menu.background.right.material"));
      this.bottomMaterial = Material.valueOf(config.getString("menu.background.bottom.material"));
      this.addTop = config.getInt("menu.background.top.for.add");
      this.startTop = config.getInt("menu.background.top.for.start-slot");
      this.endTop = config.getInt("menu.background.top.for.end-slot");
      this.addLeft = config.getInt("menu.background.left.for.add");
      this.startLeft = config.getInt("menu.background.left.for.start-slot");
      this.endLeft = config.getInt("menu.background.left.for.end-slot");
      this.addRight = config.getInt("menu.background.right.for.add");
      this.startRight = config.getInt("menu.background.right.for.start-slot");
      this.endRight = config.getInt("menu.background.right.for.end-slot");
      this.addBottom = config.getInt("menu.background.bottom.for.add");
      this.startBottom = config.getInt("menu.background.bottom.for.start-slot");
      this.endBottom = config.getInt("menu.background.bottom.for.end-slot");
      this.amountTop = config.getInt("menu.background.top.amount");
      this.amountLeft = config.getInt("menu.background.left.amount");
      this.amountRight = config.getInt("menu.background.right.amount");
      this.amountBottom = config.getInt("menu.background.bottom.amount");
      this.closeMaterial = Material.valueOf(config.getString("menu.background.close.material"));
      this.amountClose = config.getInt("menu.background.close.amount");
      this.closeSlot = config.getInt("menu.background.close.slot");
      this.topName = config.getString("menu.background.top.name");
      this.leftName = config.getString("menu.background.left.name");
      this.rightName = config.getString("menu.background.right.name");
      this.bottomName = config.getString("menu.background.bottom.name");
      this.closeName = config.getString("menu.background.close.name");
      this.loreTop = config.getStringList("menu.background.top.lore");
      this.loreLeft = config.getStringList("menu.background.left.lore");
      this.loreRight = config.getStringList("menu.background.right.lore");
      this.loreBottom = config.getStringList("menu.background.bottom.lore");
      this.loreClose = config.getStringList("menu.background.close.lore");
      this.items.clear();
      Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("menu.items."))).getKeys(false).iterator();

      while(var2.hasNext()) {
         String key = (String)var2.next();
         String path = "menu.items." + key + ".";
         String material = config.getString(path + "material");
         int amount = config.getInt(path + "amount");
         String name = config.getString(path + "name");
         List<String> lorePerm = config.getStringList(path + "lore-perm");
         List<String> loreNoPerm = config.getStringList(path + "lore-no-perm");
         String id = config.getString(path + "id", (String)null);
         int slot = config.getInt(path + "slot");
         this.items.put(key, new ChatColorManager.ChatColorItem(slot, id, material, amount, name, lorePerm, loreNoPerm));
      }

   }

   public void reloadConfig() {
      this.messagesFile.reloadConfig();
      this.loadConfig();
   }

   public int getAddTop() {
      return this.addTop;
   }

   public int getStartTop() {
      return this.startTop;
   }

   public int getEndTop() {
      return this.endTop;
   }

   public int getAddLeft() {
      return this.addLeft;
   }

   public int getStartLeft() {
      return this.startLeft;
   }

   public int getEndLeft() {
      return this.endLeft;
   }

   public int getAddRight() {
      return this.addRight;
   }

   public int getStartRight() {
      return this.startRight;
   }

   public int getEndRight() {
      return this.endRight;
   }

   public int getAddBottom() {
      return this.addBottom;
   }

   public int getStartBottom() {
      return this.startBottom;
   }

   public int getEndBottom() {
      return this.endBottom;
   }

   public List<String> getLoreTop() {
      return this.loreTop;
   }

   public List<String> getLoreLeft() {
      return this.loreLeft;
   }

   public List<String> getLoreRight() {
      return this.loreRight;
   }

   public List<String> getLoreBottom() {
      return this.loreBottom;
   }

   public List<String> getLoreClose() {
      return this.loreClose;
   }

   public String getTopName() {
      return this.topName;
   }

   public String getLeftName() {
      return this.leftName;
   }

   public String getCloseName() {
      return this.closeName;
   }

   public String getRightName() {
      return this.rightName;
   }

   public String getBottomName() {
      return this.bottomName;
   }

   public String getTitle() {
      return this.title;
   }

   public int getSlots() {
      return this.slots;
   }

   public long getCooldown() {
      return this.cooldown;
   }

   public Material getTopMaterial() {
      return this.topMaterial;
   }

   public Material getLeftMaterial() {
      return this.leftMaterial;
   }

   public Material getRightMaterial() {
      return this.rightMaterial;
   }

   public Material getBottomMaterial() {
      return this.bottomMaterial;
   }

   public int getAmountTop() {
      return this.amountTop;
   }

   public int getAmountLeft() {
      return this.amountLeft;
   }

   public int getAmountRight() {
      return this.amountRight;
   }

   public int getAmountBottom() {
      return this.amountBottom;
   }

   public int getAmountClose() {
      return this.amountClose;
   }

   public int getCloseSlot() {
      return this.closeSlot;
   }

   public Material getCloseMaterial() {
      return this.closeMaterial;
   }

   public ChatColorManager.ChatColorItem getItem(String key) {
      return (ChatColorManager.ChatColorItem)this.items.get(key);
   }

   public static class ChatColorItem {
      private final int slot;
      private final String id;
      private final String material;
      private final int amount;
      private final String name;
      private final List<String> lorePerm;
      private final List<String> loreNoPerm;

      public ChatColorItem(int slot, String id, String material, int amount, String name, List<String> lorePerm, List<String> loreNoPerm) {
         this.id = id;
         this.slot = slot;
         this.material = material;
         this.amount = amount;
         this.name = name;
         this.lorePerm = lorePerm;
         this.loreNoPerm = loreNoPerm;
      }

      public int getSlot() {
         return this.slot;
      }

      public String getId() {
         return this.id;
      }

      public String getMaterial() {
         return this.material;
      }

      public int getAmount() {
         return this.amount;
      }

      public String getName() {
         return this.name;
      }

      public List<String> getLorePerm() {
         return this.lorePerm;
      }

      public List<String> getLoreNoPerm() {
         return this.loreNoPerm;
      }
   }
}
