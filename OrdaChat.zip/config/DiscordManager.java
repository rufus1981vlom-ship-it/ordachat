package config;

import minealex.tchat.OrdaChat;
import org.bukkit.configuration.file.FileConfiguration;

public class DiscordManager {
   private final ConfigFile configFile;
   private final OrdaChat plugin;
   private boolean discordEnabled;
   private String discordHook;
   private boolean joinEnabled;
   private String joinTitle;
   private String joinDescription;
   private int joinColor;
   private boolean joinAvatarEnabled;
   private boolean quitEnabled;
   private String quitTitle;
   private String quitDescription;
   private int quitColor;
   private boolean quitAvatarEnabled;
   private boolean deathEnabled;
   private String deathTitle;
   private String deathDescription;
   private int deathColor;
   private boolean deathAvatarEnabled;
   private String bannedWordsTitle;
   private String bannedWordsDescription;
   private int bannedWordsColor;
   private boolean bannedWordsAvatar;
   private boolean muteEnabled;
   private String muteWebhook;
   private String muteTitle;
   private String muteDescription;
   private int muteColor;
   private boolean muteAvatar;
   private String bannedCommandsTitle;
   private String bannedCommandsDescription;
   private int bannedCommandsColor;
   private boolean bannedCommandsAvatar;

   public DiscordManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.configFile = new ConfigFile("discord.yml", "hooks", plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.discordEnabled = config.getBoolean("discord.enabled");
      if (this.discordEnabled) {
         this.discordHook = config.getString("discord.webhook");
         this.joinEnabled = config.getBoolean("discord.join.enabled");
         if (this.joinEnabled) {
            this.joinTitle = config.getString("discord.join.title");
            this.joinDescription = config.getString("discord.join.description");
            this.joinColor = config.getInt("discord.join.color");
            this.joinAvatarEnabled = config.getBoolean("discord.join.avatar-enabled");
         }

         this.quitEnabled = config.getBoolean("discord.quit.enabled");
         if (this.quitEnabled) {
            this.quitTitle = config.getString("discord.quit.title");
            this.quitDescription = config.getString("discord.quit.description");
            this.quitColor = config.getInt("discord.quit.color");
            this.quitAvatarEnabled = config.getBoolean("discord.quit.avatar-enabled");
         }

         this.deathEnabled = config.getBoolean("discord.death.enabled");
         if (this.deathEnabled) {
            this.deathTitle = config.getString("discord.death.title");
            this.deathDescription = config.getString("discord.death.description");
            this.deathColor = config.getInt("discord.death.color");
            this.deathAvatarEnabled = config.getBoolean("discord.death.avatar-enabled");
         }
      }

      if (this.plugin.getBannedWordsManager().isDiscordEnabled()) {
         this.bannedWordsTitle = config.getString("discord.banned-words.title", "Banned Word Detected!");
         this.bannedWordsDescription = config.getString("discord.banned-words.description", "Player %player% used a banned word: %word%\nMessage: \"%message%\"");
         this.bannedWordsColor = config.getInt("discord.banned-words.color", 15158332);
         this.bannedWordsAvatar = config.getBoolean("discord.banned-words.avatar-enabled", true);
      }

      this.muteEnabled = config.getBoolean("discord.mute.enabled", false);
      if (this.muteEnabled) {
         this.muteWebhook = config.getString("discord.mute.webhook");
         this.muteTitle = config.getString("discord.mute.title", "Player muted!");
         this.muteDescription = config.getString("discord.mute.description", "Player %player% has muted by %admin%");
         this.muteColor = config.getInt("discord.mute.color", 15158332);
         this.muteAvatar = config.getBoolean("discord.mute.avatar-enabled", true);
      }

      if (this.plugin.getBannedWordsManager().isDiscordEnabled()) {
         this.bannedCommandsTitle = config.getString("discord.banned-commands.title", "Banned Command Detected!");
         this.bannedCommandsDescription = config.getString("discord.banned-commands.description", "Player %player% used a banned command: %word%\nMessage: \"%message%\"");
         this.bannedCommandsColor = config.getInt("discord.banned-commands.color", 15158332);
         this.bannedCommandsAvatar = config.getBoolean("discord.banned-commands.avatar-enabled", true);
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public String getBannedCommandsTitle() {
      return this.bannedCommandsTitle;
   }

   public String getBannedCommandsDescription() {
      return this.bannedCommandsDescription;
   }

   public int getBannedCommandsColor() {
      return this.bannedCommandsColor;
   }

   public boolean isBannedCommandsAvatar() {
      return this.bannedCommandsAvatar;
   }

   public boolean isBannedWordsAvatar() {
      return this.bannedWordsAvatar;
   }

   public String getBannedWordsTitle() {
      return this.bannedWordsTitle;
   }

   public String getBannedWordsDescription() {
      return this.bannedWordsDescription;
   }

   public int getBannedWordsColor() {
      return this.bannedWordsColor;
   }

   public boolean isMuteEnabled() {
      return this.muteEnabled;
   }

   public String getMuteWebhook() {
      return this.muteWebhook;
   }

   public String getMuteTitle() {
      return this.muteTitle;
   }

   public String getMuteDescription() {
      return this.muteDescription;
   }

   public int getMuteColor() {
      return this.muteColor;
   }

   public boolean isMuteAvatar() {
      return this.muteAvatar;
   }

   public boolean isDiscordEnabled() {
      return this.discordEnabled;
   }

   public String getDiscordHook() {
      return this.discordHook;
   }

   public boolean isJoinEnabled() {
      return this.joinEnabled;
   }

   public String getJoinTitle() {
      return this.joinTitle;
   }

   public String getJoinDescription() {
      return this.joinDescription;
   }

   public int getJoinColor() {
      return this.joinColor;
   }

   public boolean isJoinAvatarEnabled() {
      return this.joinAvatarEnabled;
   }

   public boolean isQuitEnabled() {
      return this.quitEnabled;
   }

   public String getQuitTitle() {
      return this.quitTitle;
   }

   public String getQuitDescription() {
      return this.quitDescription;
   }

   public int getQuitColor() {
      return this.quitColor;
   }

   public boolean isQuitAvatarEnabled() {
      return this.quitAvatarEnabled;
   }

   public boolean isDeathEnabled() {
      return this.deathEnabled;
   }

   public String getDeathTitle() {
      return this.deathTitle;
   }

   public String getDeathDescription() {
      return this.deathDescription;
   }

   public int getDeathColor() {
      return this.deathColor;
   }

   public boolean isDeathAvatarEnabled() {
      return this.deathAvatarEnabled;
   }
}
