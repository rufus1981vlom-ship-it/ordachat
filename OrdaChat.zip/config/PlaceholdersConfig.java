package config;

import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.file.FileConfiguration;

public class PlaceholdersConfig {
   private final ConfigFile configFile;
   private boolean coordsEnabled;
   private String coordsFormat;
   private String coordsName;
   private boolean itemEnabled;
   private String itemPrefix;
   private String itemSuffix;
   private String itemName;
   private boolean worldEnabled;
   private String worldFormat;
   private String worldName;
   private boolean inventoryEnabled;
   private String inventoryFormat;
   private String inventoryName;
   private boolean hoverInventoryTextEnabled;
   private boolean hoverInventoryActionEnabled;
   private String hoverInventoryAction;
   private List<String> hoverInventoryText;
   private boolean enderEnabled;
   private String enderFormat;
   private String enderName;
   private boolean hoverEnderTextEnabled;
   private boolean hoverEnderActionEnabled;
   private String hoverEnderAction;
   private List<String> hoverEnderText;
   private boolean commandEnabled;
   private String commandName;
   private String commandFormat;
   private boolean hoverCommandEnabled;
   private List<String> hoverCommand;

   public PlaceholdersConfig(OrdaChat plugin) {
      this.configFile = new ConfigFile("placeholders.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.coordsEnabled = config.getBoolean("chat.coords.enabled");
      if (this.coordsEnabled) {
         this.coordsFormat = config.getString("chat.coords.format");
         this.coordsName = config.getString("chat.coords.name");
      }

      this.itemEnabled = config.getBoolean("chat.item.enabled");
      if (this.itemEnabled) {
         this.itemPrefix = config.getString("chat.item.prefix", "%tchat_format%%before_item%&7[");
         this.itemSuffix = config.getString("chat.item.suffix", "&7]%after_item%");
         this.itemName = config.getString("chat.item.name");
      }

      this.worldEnabled = config.getBoolean("chat.world.enabled");
      if (this.worldEnabled) {
         this.worldName = config.getString("chat.world.name");
         this.worldFormat = config.getString("chat.world.format");
      }

      this.inventoryEnabled = config.getBoolean("chat.inventory.enabled");
      if (this.inventoryEnabled) {
         this.inventoryName = config.getString("chat.inventory.name");
         this.inventoryFormat = config.getString("chat.inventory.format");
         this.hoverInventoryActionEnabled = config.getBoolean("chat.inventory.hover.action.enabled");
         if (this.hoverInventoryActionEnabled) {
            this.hoverInventoryAction = config.getString("chat.inventory.hover.action.command");
         }

         this.hoverInventoryTextEnabled = config.getBoolean("chat.inventory.hover.text.enabled");
         if (this.hoverInventoryTextEnabled) {
            this.hoverInventoryText = config.getStringList("chat.inventory.hover.text.lines");
         }
      }

      this.enderEnabled = config.getBoolean("chat.ender.enabled");
      if (this.enderEnabled) {
         this.enderName = config.getString("chat.ender.name");
         this.enderFormat = config.getString("chat.ender.format");
         this.hoverEnderActionEnabled = config.getBoolean("chat.ender.hover.action.enabled");
         if (this.hoverEnderActionEnabled) {
            this.hoverEnderAction = config.getString("chat.ender.hover.action.command");
         }

         this.hoverEnderTextEnabled = config.getBoolean("chat.ender.hover.text.enabled");
         if (this.hoverEnderTextEnabled) {
            this.hoverEnderText = config.getStringList("chat.ender.hover.text.lines");
         }
      }

      this.commandEnabled = config.getBoolean("chat.command.enabled", true);
      if (this.commandEnabled) {
         this.commandFormat = config.getString("chat.command.format", "%tchat_format%%before_command%&7[&a/%command%&7]%after_command%");
         this.commandName = config.getString("chat.command.name", "\\\\[/([^]]+)]");
         this.hoverCommandEnabled = config.getBoolean("chat.command.hover.enabled", false);
         if (this.hoverCommandEnabled) {
            this.hoverCommand = config.getStringList("chat.command.hover.lines");
         }
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnderEnabled() {
      return this.enderEnabled;
   }

   public String getEnderFormat() {
      return this.enderFormat;
   }

   public String getEnderName() {
      return this.enderName;
   }

   public boolean isHoverEnderTextEnabled() {
      return this.hoverEnderTextEnabled;
   }

   public boolean isHoverEnderActionEnabled() {
      return this.hoverEnderActionEnabled;
   }

   public String getHoverEnderAction() {
      return this.hoverEnderAction;
   }

   public List<String> getHoverEnderText() {
      return this.hoverEnderText;
   }

   public boolean isCommandEnabled() {
      return this.commandEnabled;
   }

   public String getCommandName() {
      return this.commandName;
   }

   public String getCommandFormat() {
      return this.commandFormat;
   }

   public boolean isHoverCommandEnabled() {
      return this.hoverCommandEnabled;
   }

   public List<String> getHoverCommand() {
      return this.hoverCommand;
   }

   public boolean isInventoryEnabled() {
      return this.inventoryEnabled;
   }

   public String getInventoryFormat() {
      return this.inventoryFormat;
   }

   public String getInventoryName() {
      return this.inventoryName;
   }

   public boolean isHoverInventoryTextEnabled() {
      return this.hoverInventoryTextEnabled;
   }

   public boolean isHoverInventoryActionEnabled() {
      return this.hoverInventoryActionEnabled;
   }

   public String getHoverInventoryAction() {
      return this.hoverInventoryAction;
   }

   public List<String> getHoverInventoryText() {
      return this.hoverInventoryText;
   }

   public boolean isWorldEnabled() {
      return this.worldEnabled;
   }

   public String getWorldFormat() {
      return this.worldFormat;
   }

   public String getWorldName() {
      return this.worldName;
   }

   public boolean isItemEnabled() {
      return this.itemEnabled;
   }

   public String getItemPrefix() {
      return this.itemPrefix;
   }

   public String getItemSuffix() {
      return this.itemSuffix;
   }

   public String getItemName() {
      return this.itemName;
   }

   public String getCoordsName() {
      return this.coordsName;
   }

   public boolean isCoordsEnabled() {
      return this.coordsEnabled;
   }

   public String getCoordsFormat() {
      return this.coordsFormat;
   }
}
