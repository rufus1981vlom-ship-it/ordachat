package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {
   private final OrdaChat plugin;
   private final ConfigFile configFile;
   private Map<Integer, String> pingColors;
   private String format;
   private boolean formatGroup;
   private AdvertisingConfig ipv4Config;
   private AdvertisingConfig domainConfig;
   private AdvertisingConfig linksConfig;
   private String advertisingBypass;
   private boolean antiCapEnabled;
   private double antiCapPercent;
   private String antiCapMode;
   private boolean antiCapMessageEnabled;
   private boolean grammarEnabled;
   private boolean grammarCapEnabled;
   private int grammarCapLetters;
   private boolean grammarDotEnabled;
   private String grammarDotCharacter;
   private int grammarMinCharactersCap;
   private int grammarMinCharactersDot;
   private String permissionBypassCap;
   private String permissionBypassFinalDot;
   private boolean msgEnabled;
   private boolean replyEnabled;
   private String msgFormatSender;
   private String msgFormatReceiver;
   private String replyFormatSender;
   private String replyFormatReceiver;
   private String msgPermission;
   private String replyPermission;
   private boolean chatClearEnabled;
   private int messagesChatClear;
   private boolean muteChatEnabled;
   private String bypassMuteChatPermission;
   private String muteChatPermission;
   private boolean repeatMessagesEnabled;
   private double repeatMessagesPercent;
   private String bypassRepeatMessages;
   private boolean antibotEnabled;
   private String antibotBypass;
   private boolean antibotChat;
   private boolean antibotCommand;
   private boolean antibotJoin;
   private boolean antibotMoved;
   private boolean logsChatEnabled;
   private boolean logsCommandEnabled;
   private boolean cooldownChat;
   private boolean cooldownCommand;
   private long cooldownChatTime;
   private long cooldownCommandTime;
   private boolean floodRepeatEnabled;
   private boolean floodPercentEnabled;
   private int charactersFlood;
   private double percentageFlood;
   private boolean unicodeEnabled;
   private boolean unicodeBlockAll;
   private String unicodeMatch;
   private boolean broadcastEnabled;
   private String broadcastFormat;
   private boolean spyEnabled;
   private String spyFormat;
   private boolean ignoreEnabled;
   private String pollFill;
   private String pollEmpty;
   private int pollBar;
   private boolean warningEnabled;
   private String warningFormat;
   private boolean rulesEnabled;
   private boolean rulesPrefixEnabled;
   private List<String> rulesMessage;
   private boolean printEnabled;
   private boolean pingEnabled;
   private boolean formatEnabled;
   private boolean chatColorEnabled;
   private boolean announcementEnabled;
   private String announcementFormat;
   private boolean depurationChatEnabled;
   private boolean depurationCommandEnabled;
   private boolean depurationAntiFloodEnabled;
   private String helpOpFormat;
   private boolean logBannedCommandsEnabled;
   private boolean logBannedWordsEnabled;
   private String listHeader;
   private String listAppend;
   private String listFooter;
   private boolean ignoreLogEnabled;
   private int socialSpyMode;
   private List<String> socialSpyCommands;
   private boolean antiAdvertisingLogEnabled;
   private boolean colorsChatEnabled;
   private List<String> whitelistCommandsAntiBot;
   private String langFile;
   private boolean chatColorMenuEnabled;
   private boolean deathLogs;
   private Map<String, ConfigManager.HoverConfig> pmHoverConfigs;
   private Map<String, ConfigManager.HoverConfig> replyHoverConfigs;
   private int maxRepeatMessages;
   private String printPrefix;
   private boolean meEnabled;
   private String meFormat;
   private boolean sccEnabled;
   private String sccFormat;
   private List<String> blackLIgnore;
   private boolean sicEnabled;
   private String sicPrefix;
   private String sicSuffix;
   private int unicodeMode;
   private String unicodeCensor;
   private boolean repeatCommandsEnabled;

   public ConfigManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.configFile = new ConfigFile("config.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.formatEnabled = config.getBoolean("chat.format-enabled");
      if (this.formatEnabled) {
         this.format = config.getString("chat.format");
         this.formatGroup = config.getBoolean("chat.use-group-format");
      }

      this.ipv4Config = new AdvertisingConfig(config, "advertising.ipv4");
      this.domainConfig = new AdvertisingConfig(config, "advertising.domain");
      this.linksConfig = new AdvertisingConfig(config, "advertising.links");
      this.advertisingBypass = config.getString("advertising.bypass");
      this.ignoreEnabled = config.getBoolean("ignore.enabled");
      if (this.ignoreEnabled) {
         this.blackLIgnore = config.getStringList("ignore.blacklist");
      }

      this.chatColorEnabled = config.getBoolean("chat-color.enabled");
      if (this.chatColorEnabled) {
         this.chatColorMenuEnabled = config.getBoolean("chat-color.menu-enabled");
      }

      this.colorsChatEnabled = config.getBoolean("chat-color.colors-in-chat-enabled");
      this.printEnabled = config.getBoolean("print.enabled");
      if (this.printEnabled) {
         this.printPrefix = config.getString("print.prefix", "%prefix%");
      }

      this.warningEnabled = config.getBoolean("broadcast.warning.enabled");
      if (this.warningEnabled) {
         this.warningFormat = config.getString("broadcast.warning.format");
      }

      this.sccEnabled = config.getBoolean("scc.enabled", true);
      if (this.sccEnabled) {
         this.sccFormat = config.getString("scc.format", "&7[&a%player_name%&7] &#3AFE09These are my coordinates: &#FEB322%x, %y, %z&#3AFE09!");
      }

      this.meEnabled = config.getBoolean("me.enabled", true);
      if (this.meEnabled) {
         this.meFormat = config.getString("me.format", "&5* &#3AFE09%player_name% &#FEAD10> &7%message%");
      }

      this.broadcastEnabled = config.getBoolean("broadcast.broadcast.enabled");
      if (this.broadcastEnabled) {
         this.broadcastFormat = config.getString("broadcast.broadcast.format");
      }

      this.announcementEnabled = config.getBoolean("broadcast.announcement.enabled");
      if (this.announcementEnabled) {
         this.announcementFormat = config.getString("broadcast.announcement.format");
      }

      this.pingEnabled = config.getBoolean("ping.enabled");
      this.spyEnabled = config.getBoolean("spy.commands.enabled");
      if (this.spyEnabled) {
         this.spyFormat = config.getString("spy.commands.format");
         this.socialSpyMode = config.getInt("spy.commands.mode");
         if (this.socialSpyMode != 1) {
            this.socialSpyCommands = config.getStringList("spy.commands.commands");
         }
      }

      this.sicEnabled = config.getBoolean("sic.enabled", false);
      if (this.sicEnabled) {
         this.sicPrefix = config.getString("sic.prefix", "&aThis is my item: &e");
         this.sicSuffix = config.getString("sic.suffix", "&a!");
      }

      this.unicodeEnabled = config.getBoolean("unicode.enabled", false);
      if (this.unicodeEnabled) {
         this.unicodeBlockAll = config.getBoolean("unicode.blockAllNonLatin");
         this.unicodeMatch = config.getString("unicode.match");
         this.unicodeMode = config.getInt("unicode.mode", 1);
         if (this.unicodeMode == 2) {
            this.unicodeCensor = config.getString("unicode.censor-char", "*");
         }
      }

      this.floodPercentEnabled = config.getBoolean("flood.percent.enabled");
      this.floodRepeatEnabled = config.getBoolean("flood.repeat.enabled");
      this.depurationAntiFloodEnabled = config.getBoolean("flood.depuration");
      if (this.floodRepeatEnabled) {
         this.charactersFlood = config.getInt("flood.repeat.characters");
      }

      if (this.floodPercentEnabled) {
         this.percentageFlood = config.getDouble("flood.percent.percentage");
      }

      this.cooldownChat = config.getBoolean("cooldowns.chat.enabled");
      this.cooldownCommand = config.getBoolean("cooldowns.commands.enabled");
      if (this.cooldownChat) {
         this.cooldownChatTime = config.getLong("cooldowns.chat.time");
         this.depurationChatEnabled = config.getBoolean("cooldowns.chat.depuration-enabled");
      }

      if (this.cooldownCommand) {
         this.cooldownCommandTime = config.getLong("cooldowns.commands.time");
         this.depurationCommandEnabled = config.getBoolean("cooldowns.commands.depuration-enabled");
      }

      this.antiCapEnabled = config.getBoolean("cap.enabled");
      if (this.antiCapEnabled) {
         this.antiCapPercent = config.getDouble("cap.percent");
         this.antiCapMode = config.getString("cap.mode");
         this.antiCapMessageEnabled = config.getBoolean("cap.message-enabled");
      }

      this.grammarEnabled = config.getBoolean("grammar.enabled");
      if (this.grammarEnabled) {
         this.grammarCapEnabled = config.getBoolean("grammar.cap.enabled");
         this.grammarDotEnabled = config.getBoolean("grammar.final-dot.enabled");
         this.repeatMessagesEnabled = config.getBoolean("grammar.repeat-messages.enabled");
         if (this.grammarDotEnabled) {
            this.permissionBypassFinalDot = config.getString("grammar.final-dot.bypass-permission");
            this.grammarMinCharactersDot = config.getInt("grammar.final-dot.min-characters");
            this.grammarDotCharacter = config.getString("grammar.final-dot.character");
         }

         if (this.grammarCapEnabled) {
            this.permissionBypassCap = config.getString("grammar.cap.bypass-permission");
            this.grammarMinCharactersCap = config.getInt("grammar.cap.min-characters");
            this.grammarCapLetters = config.getInt("grammar.cap.letters");
         }

         if (this.repeatMessagesEnabled) {
            this.repeatMessagesPercent = config.getDouble("grammar.repeat-messages.percent");
            this.bypassRepeatMessages = config.getString("grammar.repeat-messages.bypass-permission");
            this.maxRepeatMessages = config.getInt("grammar.repeat-messages.max-repeat-messages", 1);
         }
      }

      this.msgEnabled = config.getBoolean("pm.msg.enabled");
      if (this.msgEnabled) {
         this.msgFormatSender = config.getString("pm.msg.formats.sender");
         this.msgFormatReceiver = config.getString("pm.msg.formats.receiver");
         this.msgPermission = config.getString("pm.msg.permission");
      }

      this.replyEnabled = config.getBoolean("pm.reply.enabled");
      if (this.replyEnabled) {
         this.replyPermission = config.getString("pm.reply.permission");
         this.replyFormatSender = config.getString("pm.reply.formats.sender");
         this.replyFormatReceiver = config.getString("pm.reply.formats.receiver");
      }

      this.repeatCommandsEnabled = config.getBoolean("repeat-commands.enabled", false);
      this.chatClearEnabled = config.getBoolean("chat-clear.enabled");
      if (this.chatClearEnabled) {
         this.messagesChatClear = config.getInt("chat-clear.for.messages");
      }

      this.muteChatEnabled = config.getBoolean("mute-chat.enabled");
      if (this.muteChatEnabled) {
         this.bypassMuteChatPermission = config.getString("mute-chat.bypass-permission");
         this.muteChatPermission = config.getString("mute-chat.execute-command-permission");
      }

      this.antibotEnabled = config.getBoolean("antibot.enabled");
      if (this.antibotEnabled) {
         this.antibotBypass = config.getString("antibot.bypass-permission");
         this.antibotChat = config.getBoolean("antibot.antibot-chat");
         this.antibotCommand = config.getBoolean("antibot.antibot-command");
         this.antibotJoin = config.getBoolean("antibot.messages.antibot-join");
         this.antibotMoved = config.getBoolean("antibot.messages.antibot-moved");
         if (this.antibotCommand) {
            this.whitelistCommandsAntiBot = config.getStringList("antibot.commands.whitelist");
         }
      }

      this.rulesEnabled = config.getBoolean("rules.enabled");
      if (this.rulesEnabled) {
         this.rulesMessage = config.getStringList("rules.message");
         this.rulesPrefixEnabled = config.getBoolean("rules.use-prefix");
      }

      this.logsChatEnabled = config.getBoolean("logs.chat.enabled");
      this.logsCommandEnabled = config.getBoolean("logs.command.enabled");
      this.logBannedCommandsEnabled = config.getBoolean("logs.banned-commands.enabled");
      this.logBannedWordsEnabled = config.getBoolean("logs.banned-words.enabled");
      this.antiAdvertisingLogEnabled = config.getBoolean("logs.anti-advertising.enabled");
      this.ignoreLogEnabled = config.getBoolean("logs.ignore.enabled");
      this.deathLogs = config.getBoolean("logs.death.enabled");
      this.pollBar = config.getInt("poll.options.bar.length");
      this.pollFill = config.getString("poll.options.bar.filled");
      this.pollEmpty = config.getString("poll.options.bar.empty");
      this.helpOpFormat = config.getString("helpop.format");
      this.listAppend = config.getString("list.append");
      this.listFooter = config.getString("list.footer");
      this.listHeader = config.getString("list.header");
      this.langFile = config.getString("chat.lang");
      this.pingColors = new HashMap();
      List<Map<?, ?>> colorConfigs = config.getMapList("ping.colors");
      Iterator var3 = colorConfigs.iterator();

      String group;
      String colorCode;
      label181:
      while(var3.hasNext()) {
         Map<?, ?> colorConfig = (Map)var3.next();
         group = (String)colorConfig.get("range");
         colorCode = (String)colorConfig.get("color");
         if (group != null && colorCode != null) {
            String[] parts = group.split("-");
            if (parts.length >= 1 && parts.length <= 2) {
               int min;
               try {
                  min = Integer.parseInt(parts[0].trim());
               } catch (NumberFormatException var13) {
                  throw new IllegalArgumentException("[Ping]: '" + parts[0] + "' is not valid (0)", var13);
               }

               int max;
               try {
                  max = Integer.parseInt(parts[1].trim());
               } catch (NumberFormatException var12) {
                  throw new IllegalArgumentException("[Ping]: '" + parts[1] + "' is not valid (1)", var12);
               }

               int i = min;

               while(true) {
                  if (i > max) {
                     continue label181;
                  }

                  this.pingColors.put(i, colorCode);
                  ++i;
               }
            }

            throw new IllegalArgumentException("[Ping]: '" + group + "' does not have min-max format: '" + group + "'");
         }

         throw new IllegalArgumentException("[Ping] Error in config: " + colorConfig);
      }

      this.pmHoverConfigs = new HashMap();
      ConfigurationSection hoverSection = config.getConfigurationSection("pm.msg.hover");
      if (hoverSection != null) {
         Iterator var15 = hoverSection.getKeys(false).iterator();

         while(var15.hasNext()) {
            group = (String)var15.next();
            List<String> senderTexts = hoverSection.getStringList(group + ".sender");
            String senderAction = hoverSection.getString(group + ".sender-action");
            List<String> receiverTexts = hoverSection.getStringList(group + ".receiver");
            String receiverAction = hoverSection.getString(group + ".receiver-action");
            ConfigManager.HoverConfig hoverConfig = new ConfigManager.HoverConfig(senderTexts, senderAction, receiverTexts, receiverAction);
            this.pmHoverConfigs.put(group, hoverConfig);
         }
      } else {
         this.plugin.getLogger().warning("'pm.msg.hover' not found in config.yml");
      }

      this.replyHoverConfigs = new HashMap();
      ConfigurationSection replyHoverSection = config.getConfigurationSection("pm.reply.hover");
      if (replyHoverSection != null) {
         Iterator var17 = replyHoverSection.getKeys(false).iterator();

         while(var17.hasNext()) {
            colorCode = (String)var17.next();
            List<String> senderTexts = replyHoverSection.getStringList(colorCode + ".sender");
            String senderAction = replyHoverSection.getString(colorCode + ".sender-action");
            List<String> receiverTexts = replyHoverSection.getStringList(colorCode + ".receiver");
            String receiverAction = replyHoverSection.getString(colorCode + ".receiver-action");
            ConfigManager.HoverConfig hoverConfig = new ConfigManager.HoverConfig(senderTexts, senderAction, receiverTexts, receiverAction);
            this.replyHoverConfigs.put(colorCode, hoverConfig);
         }
      } else {
         this.plugin.getLogger().warning("'pm.reply.hover' not found in config.yml");
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public ConfigManager.HoverConfig getPmHoverConfig(String group) {
      return (ConfigManager.HoverConfig)this.pmHoverConfigs.get(group);
   }

   public ConfigManager.HoverConfig getReplyHoverConfig(String group) {
      return (ConfigManager.HoverConfig)this.replyHoverConfigs.get(group);
   }

   public boolean isRepeatCommandsEnabled() {
      return this.repeatCommandsEnabled;
   }

   public int getUnicodeMode() {
      return this.unicodeMode;
   }

   public String getUnicodeCensor() {
      return this.unicodeCensor;
   }

   public boolean isSicEnabled() {
      return this.sicEnabled;
   }

   public String getSicPrefix() {
      return this.sicPrefix;
   }

   public String getSicSuffix() {
      return this.sicSuffix;
   }

   public List<String> getBlackLIgnore() {
      return this.blackLIgnore;
   }

   public boolean isSccEnabled() {
      return this.sccEnabled;
   }

   public String getSccFormat() {
      return this.sccFormat;
   }

   public boolean isMeEnabled() {
      return this.meEnabled;
   }

   public String getMeFormat() {
      return this.meFormat;
   }

   public String getPrintPrefix() {
      return this.printPrefix;
   }

   public int getMaxRepeatMessages() {
      return this.maxRepeatMessages;
   }

   public boolean isDeathLogs() {
      return this.deathLogs;
   }

   public boolean isChatColorMenuEnabled() {
      return this.chatColorMenuEnabled;
   }

   public String getLangFile() {
      return this.langFile;
   }

   public List<String> getWhitelistCommandsAntiBot() {
      return this.whitelistCommandsAntiBot;
   }

   public boolean isColorsChatEnabled() {
      return this.colorsChatEnabled;
   }

   public boolean isAntiAdvertisingLogEnabled() {
      return this.antiAdvertisingLogEnabled;
   }

   public List<String> getSocialSpyCommands() {
      return this.socialSpyCommands;
   }

   public int getSocialSpyMode() {
      return this.socialSpyMode;
   }

   public boolean isIgnoreLogEnabled() {
      return this.ignoreLogEnabled;
   }

   public String getListFooter() {
      return this.listFooter;
   }

   public String getListAppend() {
      return this.listAppend;
   }

   public String getListHeader() {
      return this.listHeader;
   }

   public boolean isLogBannedWordsEnabled() {
      return this.logBannedWordsEnabled;
   }

   public boolean isLogBannedCommandsEnabled() {
      return this.logBannedCommandsEnabled;
   }

   public String getHelpOpFormat() {
      return this.helpOpFormat;
   }

   public boolean isDepurationAntiFloodEnabled() {
      return this.depurationAntiFloodEnabled;
   }

   public boolean isDepurationCommandEnabled() {
      return this.depurationCommandEnabled;
   }

   public boolean isDepurationChatEnabled() {
      return this.depurationChatEnabled;
   }

   public String getAnnouncementFormat() {
      return this.announcementFormat;
   }

   public boolean isAnnouncementEnabled() {
      return this.announcementEnabled;
   }

   public boolean isChatColorEnabled() {
      return this.chatColorEnabled;
   }

   public boolean isFormatEnabled() {
      return this.formatEnabled;
   }

   public boolean isPingEnabled() {
      return this.pingEnabled;
   }

   public boolean isPrintEnabled() {
      return this.printEnabled;
   }

   public List<String> getRulesMessage() {
      return this.rulesMessage;
   }

   public boolean isRulesPrefixEnabled() {
      return this.rulesPrefixEnabled;
   }

   public boolean isRulesEnabled() {
      return this.rulesEnabled;
   }

   public boolean isWarningEnabled() {
      return this.warningEnabled;
   }

   public String getWarningFormat() {
      return this.warningFormat;
   }

   public int getPollBar() {
      return this.pollBar;
   }

   public String getPollEmpty() {
      return this.pollEmpty;
   }

   public String getPollFill() {
      return this.pollFill;
   }

   public boolean isIgnoreEnabled() {
      return this.ignoreEnabled;
   }

   public String getSpyFormat() {
      return this.spyFormat;
   }

   public boolean isSpyEnabled() {
      return this.spyEnabled;
   }

   public String getBroadcastFormat() {
      return this.broadcastFormat;
   }

   public boolean isBroadcastEnabled() {
      return this.broadcastEnabled;
   }

   public boolean isUnicodeBlockAll() {
      return this.unicodeBlockAll;
   }

   public String getUnicodeMatch() {
      return this.unicodeMatch;
   }

   public boolean isUnicodeEnabled() {
      return this.unicodeEnabled;
   }

   public double getPercentageFlood() {
      return this.percentageFlood;
   }

   public int getCharactersFlood() {
      return this.charactersFlood;
   }

   public boolean isFloodPercentEnabled() {
      return this.floodPercentEnabled;
   }

   public boolean isFloodRepeatEnabled() {
      return this.floodRepeatEnabled;
   }

   public long getCooldownCommandTime() {
      return this.cooldownCommandTime;
   }

   public long getCooldownChatTime() {
      return this.cooldownChatTime;
   }

   public boolean isCooldownCommand() {
      return this.cooldownCommand;
   }

   public boolean isCooldownChat() {
      return this.cooldownChat;
   }

   public boolean isLogsCommandEnabled() {
      return this.logsCommandEnabled;
   }

   public boolean isLogsChatEnabled() {
      return this.logsChatEnabled;
   }

   public boolean isAntibotMoved() {
      return this.antibotMoved;
   }

   public boolean isAntibotJoin() {
      return this.antibotJoin;
   }

   public boolean isAntibotCommand() {
      return this.antibotCommand;
   }

   public boolean isAntibotChat() {
      return this.antibotChat;
   }

   public String getAntibotBypass() {
      return this.antibotBypass;
   }

   public boolean isAntibotEnabled() {
      return this.antibotEnabled;
   }

   public String getBypassRepeatMessages() {
      return this.bypassRepeatMessages;
   }

   public double getRepeatMessagesPercent() {
      return this.repeatMessagesPercent;
   }

   public boolean isRepeatMessagesEnabled() {
      return this.repeatMessagesEnabled;
   }

   public String getMuteChatPermission() {
      return this.muteChatPermission;
   }

   public String getBypassMuteChatPermission() {
      return this.bypassMuteChatPermission;
   }

   public boolean isMuteChatEnabled() {
      return this.muteChatEnabled;
   }

   public int getMessagesChatClear() {
      return this.messagesChatClear;
   }

   public boolean isChatClearEnabled() {
      return this.chatClearEnabled;
   }

   public String getMsgPermission() {
      return this.msgPermission;
   }

   public String getReplyPermission() {
      return this.replyPermission;
   }

   public String getReplyFormatReceiver() {
      return this.replyFormatReceiver;
   }

   public String getReplyFormatSender() {
      return this.replyFormatSender;
   }

   public String getMsgFormatReceiver() {
      return this.msgFormatReceiver;
   }

   public String getMsgFormatSender() {
      return this.msgFormatSender;
   }

   public boolean isReplyEnabled() {
      return this.replyEnabled;
   }

   public boolean isMsgEnabled() {
      return this.msgEnabled;
   }

   public String getPermissionBypassCap() {
      return this.permissionBypassCap;
   }

   public String getPermissionBypassFinalDot() {
      return this.permissionBypassFinalDot;
   }

   public int getGrammarMinCharactersCap() {
      return this.grammarMinCharactersCap;
   }

   public int getGrammarMinCharactersDot() {
      return this.grammarMinCharactersDot;
   }

   public String getGrammarDotCharacter() {
      return this.grammarDotCharacter;
   }

   public boolean isGrammarDotEnabled() {
      return this.grammarDotEnabled;
   }

   public boolean isGrammarEnabled() {
      return this.grammarEnabled;
   }

   public boolean isGrammarCapEnabled() {
      return this.grammarCapEnabled;
   }

   public int getGrammarCapLetters() {
      return this.grammarCapLetters;
   }

   public String getFormat() {
      return this.format;
   }

   public boolean isFormatGroup() {
      return this.formatGroup;
   }

   public AdvertisingConfig getIpv4Config() {
      return this.ipv4Config;
   }

   public AdvertisingConfig getDomainConfig() {
      return this.domainConfig;
   }

   public AdvertisingConfig getLinksConfig() {
      return this.linksConfig;
   }

   public String getAdvertisingBypass() {
      return this.advertisingBypass;
   }

   public boolean isAntiCapEnabled() {
      return this.antiCapEnabled;
   }

   public double getAntiCapPercent() {
      return this.antiCapPercent;
   }

   public String getAntiCapMode() {
      return this.antiCapMode;
   }

   public boolean isAntiCapMessageEnabled() {
      return this.antiCapMessageEnabled;
   }

   public FileConfiguration getConfig() {
      return this.configFile.getConfig();
   }

   public void saveConfig() {
      this.configFile.saveConfig();
   }

   public String getColorForPing(int ping) {
      return (String)this.pingColors.entrySet().stream().filter((entry) -> {
         return ping >= (Integer)entry.getKey();
      }).reduce((first, second) -> {
         return second;
      }).map(Entry::getValue).orElse("&#FFFFFF");
   }

   public static class HoverConfig {
      private final List<String> senderTexts;
      private final String senderAction;
      private final List<String> receiverTexts;
      private final String receiverAction;

      public HoverConfig(List<String> senderTexts, String senderAction, List<String> receiverTexts, String receiverAction) {
         this.senderTexts = senderTexts;
         this.senderAction = senderAction;
         this.receiverTexts = receiverTexts;
         this.receiverAction = receiverAction;
      }

      public List<String> getSenderTexts() {
         return this.senderTexts;
      }

      public String getSenderAction() {
         return this.senderAction;
      }

      public List<String> getReceiverTexts() {
         return this.receiverTexts;
      }

      public String getReceiverAction() {
         return this.receiverAction;
      }
   }
}
