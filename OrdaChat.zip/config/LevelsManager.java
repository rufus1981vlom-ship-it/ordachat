package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class LevelsManager {
   private final OrdaChat plugin;
   private final ConfigFile levelsFile;
   private boolean enabled;
   private int minXp;
   private int maxXp;
   private final Map<Integer, LevelsManager.Level> levels;
   private final Map<String, LevelsManager.Multiplier> multipliers;

   public LevelsManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.levelsFile = new ConfigFile("levels.yml", (String)null, plugin);
      this.levels = new HashMap();
      this.multipliers = new HashMap();
      this.levelsFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.levelsFile.getConfig();
      this.enabled = config.getBoolean("options.enabled", false);
      if (this.enabled) {
         this.minXp = config.getInt("options.min");
         this.maxXp = config.getInt("options.max");
         this.multipliers.clear();
         Iterator var2;
         String key;
         if (config.contains("multiplier")) {
            var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("multiplier"))).getKeys(false).iterator();

            while(var2.hasNext()) {
               key = (String)var2.next();
               double xpMultiplier = config.getDouble("multiplier." + key + ".xp", 1.0D);
               LevelsManager.Multiplier multiplier = new LevelsManager.Multiplier(xpMultiplier);
               this.multipliers.put(key, multiplier);
            }
         }

         this.levels.clear();
         if (config.contains("levels")) {
            var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("levels"))).getKeys(false).iterator();

            while(var2.hasNext()) {
               key = (String)var2.next();
               int levelId = Integer.parseInt(key);
               int xp = config.getInt("levels." + key + ".xp");
               List<String> rewards = config.getStringList("levels." + key + ".rewards");
               LevelsManager.Level level = new LevelsManager.Level(xp, rewards);
               this.levels.put(levelId, level);
            }
         }
      }

   }

   public void reloadConfig() {
      this.levelsFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getMaxXp() {
      return this.maxXp;
   }

   public int getMinXp() {
      return this.minXp;
   }

   public LevelsManager.Multiplier getMultiplier(Player player) {
      String playerGroup = this.plugin.getGroupManager().getGroup(player);
      return (LevelsManager.Multiplier)this.multipliers.getOrDefault(playerGroup, new LevelsManager.Multiplier(1.0D));
   }

   public LevelsManager.Level getLevel(int levelId) {
      return (LevelsManager.Level)this.levels.get(levelId);
   }

   public Map<Integer, LevelsManager.Level> getLevels() {
      return this.levels;
   }

   public static class Multiplier {
      private final double xpMultiplier;

      public Multiplier(double xpMultiplier) {
         this.xpMultiplier = xpMultiplier;
      }

      public double getXpMultiplier() {
         return this.xpMultiplier;
      }
   }

   public static class Level {
      private final int xp;
      private final List<String> rewards;

      public Level(int xp, List<String> rewards) {
         this.xp = xp;
         this.rewards = rewards;
      }

      public int getXp() {
         return this.xp;
      }

      public List<String> getRewards() {
         return this.rewards;
      }
   }
}
