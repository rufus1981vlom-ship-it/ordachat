package config;

import java.util.List;
import minealex.tchat.OrdaChat;
import org.bukkit.Particle;
import org.bukkit.configuration.file.FileConfiguration;

public class BannedCommandsManager {
   private final OrdaChat plugin;
   private final ConfigFile configFile;
   private List<String> bannedCommands;
   private List<String> blockedMessage;
   private List<String> noTabCompleteCommands;
   private boolean blockAllCommands;
   private boolean titleEnabled;
   private String title;
   private String subTitle;
   private boolean actionBarEnabled;
   private String actionBar;
   private boolean soundEnabled;
   private String sound;
   private String bypassPermissionCommand;
   private String bypassPermissionTab;
   private boolean particlesEnabled;
   private Particle particle;
   private int particles;
   private List<String> addTabCommands;
   private boolean discordEnabled;
   private String discordWebhook;

   public BannedCommandsManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.configFile = new ConfigFile("banned_commands.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.bypassPermissionCommand = config.getString("bypass.command.permission");
      this.bypassPermissionTab = config.getString("bypass.tab.permission");
      this.bannedCommands = config.getStringList("bannedCommands");
      this.blockedMessage = config.getStringList("blockedMessage");
      this.noTabCompleteCommands = config.getStringList("tab.noTabCompleteCommands");
      this.blockAllCommands = config.getBoolean("tab.block-all-additional-commands");
      this.addTabCommands = config.getStringList("tab.add-tab-complete-commands");
      this.titleEnabled = config.getBoolean("title.enabled");
      if (this.titleEnabled) {
         this.title = config.getString("title.title");
         this.subTitle = config.getString("title.subtitle");
      }

      this.actionBarEnabled = config.getBoolean("actionbar.enabled");
      if (this.actionBarEnabled) {
         this.actionBar = config.getString("actionbar.bar");
      }

      this.soundEnabled = config.getBoolean("sound.enabled");
      if (this.soundEnabled) {
         this.sound = config.getString("sound.sound");
      }

      this.particlesEnabled = config.getBoolean("particles.enabled");
      if (this.particlesEnabled) {
         this.particle = Particle.valueOf(config.getString("particles.particle"));
         this.particles = config.getInt("particles.particles");
      }

      this.discordEnabled = config.getBoolean("discord.enabled", false);
      if (this.discordEnabled) {
         this.discordWebhook = config.getString("discord.webhook");
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public void saveConfig() {
      this.configFile.saveConfig();
   }

   public ConfigFile getConfigFile() {
      return this.configFile;
   }

   public boolean isDiscordEnabled() {
      return this.discordEnabled;
   }

   public String getDiscordWebhook() {
      return this.discordWebhook;
   }

   public List<String> getAddTabCommands() {
      return this.addTabCommands;
   }

   public int getParticles() {
      return this.particles;
   }

   public Particle getParticle() {
      return this.particle;
   }

   public boolean isParticlesEnabled() {
      return this.particlesEnabled;
   }

   public String getBypassPermissionCommand() {
      return this.bypassPermissionCommand;
   }

   public String getBypassPermissionTab() {
      return this.bypassPermissionTab;
   }

   public String getSound() {
      return this.sound;
   }

   public boolean getSoundEnabled() {
      return this.soundEnabled;
   }

   public String getActionBar() {
      return this.actionBar;
   }

   public boolean getActionBarEnabled() {
      return this.actionBarEnabled;
   }

   public String getSubTitle() {
      return this.subTitle;
   }

   public String getTitle() {
      return this.title;
   }

   public boolean getTitleEnabled() {
      return this.titleEnabled;
   }

   public boolean getBlockAllCommands() {
      return this.blockAllCommands;
   }

   public List<String> getBannedCommands() {
      return this.bannedCommands;
   }

   public List<String> getBlockedMessage() {
      return this.blockedMessage;
   }

   public List<String> getNoTabCompleteCommands() {
      return this.noTabCompleteCommands;
   }

   public OrdaChat getPlugin() {
      return this.plugin;
   }
}
