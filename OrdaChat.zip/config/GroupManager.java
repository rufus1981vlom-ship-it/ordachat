package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.Map.Entry;
import java.util.logging.Logger;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

public class GroupManager {
   private final OrdaChat plugin;
   private final ConfigFile groupsFile;
   private Map<String, GroupManager.Group> groups;

   public GroupManager(OrdaChat plugin) {
      this.plugin = plugin;
      this.groupsFile = new ConfigFile("groups.yml", (String)null, plugin);
      this.groupsFile.registerConfig();
      this.loadGroups();
   }

   public void loadGroups() {
      this.groups = new HashMap();
      FileConfiguration config = this.groupsFile.getConfig();
      Set<String> groupKeys = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("groups"))).getKeys(false);
      Iterator var3 = groupKeys.iterator();

      while(var3.hasNext()) {
         String key = (String)var3.next();
         String permission = config.getString("groups." + key + ".permission", "");
         String prefix = config.getString("groups." + key + ".prefix", "");
         String suffix = config.getString("groups." + key + ".suffix", "");
         boolean formatEnabled = config.getBoolean("groups." + key + ".format-enabled", false);
         String format = config.getString("groups." + key + ".format", "");
         int priority = config.getInt("groups." + key + ".priority", Integer.MAX_VALUE);
         GroupManager.HoverClickAction playerHoverClick = this.getHoverClickAction(config, "groups." + key + ".hover.player");
         GroupManager.HoverClickAction messageHoverClick = this.getHoverClickAction(config, "groups." + key + ".hover.message");
         this.groups.put(key, new GroupManager.Group(permission, prefix, suffix, formatEnabled, format, priority, playerHoverClick, messageHoverClick));
      }

   }

   @Contract("_, _ -> new")
   @NotNull
   private GroupManager.HoverClickAction getHoverClickAction(@NotNull FileConfiguration config, String path) {
      if (config.getBoolean(path + ".enabled", false)) {
         List<String> hover = config.getStringList(path + ".hover");
         boolean clickEnabled = config.getBoolean(path + ".click.enabled", false);
         String clickAction = config.getString(path + ".click.action", "");
         return new GroupManager.HoverClickAction(true, hover, clickEnabled, clickAction);
      } else {
         return new GroupManager.HoverClickAction(false, (List)null, false, (String)null);
      }
   }

   public void reloadGroups() {
      this.groupsFile.reloadConfig();
      this.loadGroups();
   }

   public String getGroup(@NotNull Player player) {
      FileConfiguration config = this.groupsFile.getConfig();
      String opGroup = config.getString("config.op-group");
      String assignedGroup = config.getString("config.default-group");
      int highestPriority = Integer.MAX_VALUE;
      Iterator var6 = this.groups.entrySet().iterator();

      while(var6.hasNext()) {
         Entry<String, GroupManager.Group> entry = (Entry)var6.next();
         String permission = ((GroupManager.Group)entry.getValue()).getPermission();
         int priority = ((GroupManager.Group)entry.getValue()).getPriority();
         if (permission != null && !permission.isEmpty() && player.hasPermission(permission) && priority < highestPriority) {
            assignedGroup = (String)entry.getKey();
            highestPriority = priority;
         }
      }

      if (player.isOp() && opGroup != null && !opGroup.equals("none") && highestPriority == Integer.MAX_VALUE) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = player.getName();
         var10000.info("Player " + var10001 + " is OP, assigning OP group: " + opGroup);
         return opGroup;
      } else {
         return assignedGroup;
      }
   }

   public String getGroupFormat(String groupName) {
      GroupManager.Group group = (GroupManager.Group)this.groups.get(groupName);
      return group != null ? group.getFormat() : "";
   }

   public String getGroupPrefix(Player player) {
      String group = this.getGroup(player);
      return ((GroupManager.Group)this.groups.get(group)).getPrefix();
   }

   public String getGroupSuffix(Player player) {
      String group = this.getGroup(player);
      return ((GroupManager.Group)this.groups.get(group)).getSuffix();
   }

   public String getGroupName(Player player) {
      return this.getGroup(player);
   }

   public boolean isFormatEnabled(Player player) {
      String group = this.getGroup(player);
      return ((GroupManager.Group)this.groups.get(group)).isFormatEnabled();
   }

   public GroupManager.HoverClickAction getPlayerHoverClickAction(String groupName) {
      GroupManager.Group group = (GroupManager.Group)this.groups.get(groupName);
      return group != null ? group.getPlayerHoverClick() : new GroupManager.HoverClickAction(false, (List)null, false, (String)null);
   }

   public GroupManager.HoverClickAction getMessageHoverClickAction(String groupName) {
      GroupManager.Group group = (GroupManager.Group)this.groups.get(groupName);
      return group != null ? group.getMessageHoverClick() : new GroupManager.HoverClickAction(false, (List)null, false, (String)null);
   }

   public static class HoverClickAction {
      private final boolean enabled;
      private final List<String> hoverText;
      private final boolean clickEnabled;
      private final String clickAction;

      public HoverClickAction(boolean enabled, List<String> hoverText, boolean clickEnabled, String clickAction) {
         this.enabled = enabled;
         this.hoverText = hoverText;
         this.clickEnabled = clickEnabled;
         this.clickAction = clickAction;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public List<String> getHoverText() {
         return this.hoverText;
      }

      public boolean isClickEnabled() {
         return this.clickEnabled;
      }

      public String getClickAction() {
         return this.clickAction;
      }
   }

   private static class Group {
      private final String permission;
      private final String prefix;
      private final String suffix;
      private final boolean formatEnabled;
      private final String format;
      private final int priority;
      private final GroupManager.HoverClickAction playerHoverClick;
      private final GroupManager.HoverClickAction messageHoverClick;

      public Group(String permission, String prefix, String suffix, boolean formatEnabled, String format, int priority, GroupManager.HoverClickAction playerHoverClick, GroupManager.HoverClickAction messageHoverClick) {
         this.permission = permission;
         this.prefix = prefix;
         this.suffix = suffix;
         this.formatEnabled = formatEnabled;
         this.format = format;
         this.priority = priority;
         this.playerHoverClick = playerHoverClick;
         this.messageHoverClick = messageHoverClick;
      }

      public String getPermission() {
         return this.permission;
      }

      public String getPrefix() {
         return this.prefix;
      }

      public boolean isFormatEnabled() {
         return this.formatEnabled;
      }

      public String getSuffix() {
         return this.suffix;
      }

      public String getFormat() {
         return this.format;
      }

      public int getPriority() {
         return this.priority;
      }

      public GroupManager.HoverClickAction getPlayerHoverClick() {
         return this.playerHoverClick;
      }

      public GroupManager.HoverClickAction getMessageHoverClick() {
         return this.messageHoverClick;
      }
   }
}
