package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class BroadcastPremadeManager {
   private final ConfigFile configFile;
   private final Map<String, BroadcastPremadeManager.Broadcast> broadcasts = new HashMap();

   public BroadcastPremadeManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("broadcast.yml", "premades", plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.broadcasts.clear();
      if (config.isConfigurationSection("broadcasts")) {
         Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("broadcasts"))).getKeys(false).iterator();

         while(var2.hasNext()) {
            String key = (String)var2.next();
            String path = "broadcasts." + key;
            boolean messageEnabled = config.getBoolean(path + ".message.enabled", false);
            List<String> message = config.getStringList(path + ".message.message");
            boolean titleEnabled = config.getBoolean(path + ".message.title.enabled", false);
            String title = config.getString(path + ".message.title.main");
            String subtitle = config.getString(path + ".message.title.subtitle");
            int fadeIn = config.getInt(path + ".message.title.fade-in", 10);
            int stay = config.getInt(path + ".message.title.stay", 70);
            int fadeOut = config.getInt(path + ".message.title.fade-out", 20);
            boolean soundEnabled = config.getBoolean(path + ".message.sound.enabled", false);
            String sound = config.getString(path + ".message.sound.sound");
            float volume = (float)config.getDouble(path + ".message.sound.volume", 1.0D);
            float pitch = (float)config.getDouble(path + ".message.sound.pitch", 1.0D);
            boolean actionBarEnabled = config.getBoolean(path + ".message.action-bar.enabled", false);
            String actionBar = config.getString(path + ".message.action-bar.message");
            boolean particlesEnabled = config.getBoolean(path + ".message.particles.enabled", false);
            String particleType = config.getString(path + ".message.particles.type");
            int amount = config.getInt(path + ".message.particles.amount", 10);
            double offsetX = config.getDouble(path + ".message.particles.offset-x", 0.5D);
            double offsetY = config.getDouble(path + ".message.particles.offset-y", 0.5D);
            double offsetZ = config.getDouble(path + ".message.particles.offset-z", 0.5D);
            BroadcastPremadeManager.Broadcast broadcast = new BroadcastPremadeManager.Broadcast(messageEnabled, message, titleEnabled, title, subtitle, fadeIn, stay, fadeOut, soundEnabled, sound, volume, pitch, actionBarEnabled, actionBar, particlesEnabled, particleType, amount, offsetX, offsetY, offsetZ);
            this.broadcasts.put(key, broadcast);
         }
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public Map<String, BroadcastPremadeManager.Broadcast> getBroadcasts() {
      return this.broadcasts;
   }

   public static class Broadcast {
      private final boolean messageEnabled;
      private final List<String> message;
      private final boolean titleEnabled;
      private final String title;
      private final String subtitle;
      private final int fadeIn;
      private final int stay;
      private final int fadeOut;
      private final boolean soundEnabled;
      private final String sound;
      private final float volume;
      private final float pitch;
      private final boolean actionBarEnabled;
      private final String actionBar;
      private final boolean particlesEnabled;
      private final String particleType;
      private final int particleAmount;
      private final double offsetX;
      private final double offsetY;
      private final double offsetZ;

      public Broadcast(boolean messageEnabled, List<String> message, boolean titleEnabled, String title, String subtitle, int fadeIn, int stay, int fadeOut, boolean soundEnabled, String sound, float volume, float pitch, boolean actionBarEnabled, String actionBar, boolean particlesEnabled, String particleType, int particleAmount, double offsetX, double offsetY, double offsetZ) {
         this.messageEnabled = messageEnabled;
         this.message = message;
         this.titleEnabled = titleEnabled;
         this.title = title;
         this.subtitle = subtitle;
         this.fadeIn = fadeIn;
         this.stay = stay;
         this.fadeOut = fadeOut;
         this.soundEnabled = soundEnabled;
         this.sound = sound;
         this.volume = volume;
         this.pitch = pitch;
         this.actionBarEnabled = actionBarEnabled;
         this.actionBar = actionBar;
         this.particlesEnabled = particlesEnabled;
         this.particleType = particleType;
         this.particleAmount = particleAmount;
         this.offsetX = offsetX;
         this.offsetY = offsetY;
         this.offsetZ = offsetZ;
      }

      public boolean isMessageEnabled() {
         return this.messageEnabled;
      }

      public List<String> getMessage() {
         return this.message;
      }

      public boolean isTitleEnabled() {
         return this.titleEnabled;
      }

      public String getTitle() {
         return this.title;
      }

      public String getSubtitle() {
         return this.subtitle;
      }

      public int getFadeIn() {
         return this.fadeIn;
      }

      public int getStay() {
         return this.stay;
      }

      public int getFadeOut() {
         return this.fadeOut;
      }

      public boolean isSoundEnabled() {
         return this.soundEnabled;
      }

      public String getSound() {
         return this.sound;
      }

      public float getVolume() {
         return this.volume;
      }

      public float getPitch() {
         return this.pitch;
      }

      public boolean isActionBarEnabled() {
         return this.actionBarEnabled;
      }

      public String getActionBar() {
         return this.actionBar;
      }

      public boolean isParticlesEnabled() {
         return this.particlesEnabled;
      }

      public String getParticleType() {
         return this.particleType;
      }

      public int getParticleAmount() {
         return this.particleAmount;
      }

      public double getOffsetX() {
         return this.offsetX;
      }

      public double getOffsetY() {
         return this.offsetY;
      }

      public double getOffsetZ() {
         return this.offsetZ;
      }
   }
}
