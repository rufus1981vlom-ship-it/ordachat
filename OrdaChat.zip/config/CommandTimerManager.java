package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class CommandTimerManager {
   private final ConfigFile commandTimerFile;
   private boolean enabled;
   private int time;
   private final Map<String, CommandTimerManager.CommandConfig> commands = new HashMap();

   public CommandTimerManager(OrdaChat plugin) {
      this.commandTimerFile = new ConfigFile("command_timer.yml", (String)null, plugin);
      this.commandTimerFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.commandTimerFile.getConfig();
      this.enabled = config.getBoolean("options.enabled");
      this.time = config.getInt("options.time");
      this.commands.clear();
      Set<String> commandKeys = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("commands"))).getKeys(false);
      Iterator var3 = commandKeys.iterator();

      while(var3.hasNext()) {
         String key = (String)var3.next();
         boolean commandEnabled = config.getBoolean("commands." + key + ".enabled");
         List<String> commandActions = config.getStringList("commands." + key + ".commands");
         this.commands.put(key, new CommandTimerManager.CommandConfig(commandEnabled, commandActions));
      }

   }

   public void reloadConfig() {
      this.commandTimerFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getTime() {
      return this.time;
   }

   public Map<String, CommandTimerManager.CommandConfig> getCommandConfig() {
      return this.commands;
   }

   public boolean addCommandTimer(String name, int time, List<String> commandList) {
      FileConfiguration config = this.commandTimerFile.getConfig();
      if (config.getConfigurationSection("commands." + name) != null) {
         return false;
      } else {
         config.set("commands." + name + ".enabled", true);
         config.set("commands." + name + ".time", time);
         config.set("commands." + name + ".commands", commandList);
         this.commandTimerFile.saveConfig();
         this.loadConfig();
         return true;
      }
   }

   public boolean removeCommandTimer(String name) {
      FileConfiguration config = this.commandTimerFile.getConfig();
      if (config.getConfigurationSection("commands." + name) == null) {
         return false;
      } else {
         config.set("commands." + name, (Object)null);
         this.commandTimerFile.saveConfig();
         this.loadConfig();
         return true;
      }
   }

   public static class CommandConfig {
      private final boolean enabled;
      private final List<String> commands;

      public CommandConfig(boolean enabled, List<String> commands) {
         this.enabled = enabled;
         this.commands = commands;
      }

      public boolean isEnabled() {
         return this.enabled;
      }

      public List<String> getCommands() {
         return this.commands;
      }
   }
}
