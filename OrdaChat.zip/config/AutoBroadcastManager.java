package config;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class AutoBroadcastManager {
   private final ConfigFile autoBroadcastFile;
   private int time;
   private boolean enabled;
   private final Map<String, AutoBroadcastManager.Broadcast> broadcasts = new HashMap();
   private final HashSet<UUID> toggledPlayers = new HashSet();

   public AutoBroadcastManager(OrdaChat plugin) {
      this.autoBroadcastFile = new ConfigFile("autobroadcast.yml", (String)null, plugin);
      this.autoBroadcastFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.autoBroadcastFile.getConfig();
      this.time = config.getInt("options.time");
      this.enabled = config.getBoolean("options.enabled");
      this.broadcasts.clear();
      Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("broadcasts"))).getKeys(false).iterator();

      while(var2.hasNext()) {
         String key = (String)var2.next();
         boolean broadcastEnabled = config.getBoolean("broadcasts." + key + ".enabled");
         List<String> messages = config.getStringList("broadcasts." + key + ".message");
         boolean titleEnabled = config.getBoolean("broadcasts." + key + ".actions.title.enabled");
         String title = config.getString("broadcasts." + key + ".actions.title.title");
         String subtitle = config.getString("broadcasts." + key + ".actions.title.subtitle");
         boolean soundEnabled = config.getBoolean("broadcasts." + key + ".actions.sound.enabled");
         String sound = config.getString("broadcasts." + key + ".actions.sound.sound");
         boolean particlesEnabled = config.getBoolean("broadcasts." + key + ".actions.particles.enabled");
         String particle = config.getString("broadcasts." + key + ".actions.particles.particle");
         int particleCount = config.getInt("broadcasts." + key + ".actions.particles.particles");
         boolean actionbarEnabled = config.getBoolean("broadcasts." + key + ".actions.actionbar.enabled");
         String actionbar = config.getString("broadcasts." + key + ".actions.actionbar.bar");
         String channel = config.getString("broadcasts." + key + ".channel");
         String permission = config.getString("broadcasts." + key + ".permission");
         AutoBroadcastManager.Broadcast broadcast = new AutoBroadcastManager.Broadcast(broadcastEnabled, messages, titleEnabled, title, subtitle, soundEnabled, sound, particlesEnabled, particle, particleCount, actionbarEnabled, actionbar, channel, permission);
         this.broadcasts.put(key, broadcast);
      }

   }

   public void reloadConfig() {
      this.autoBroadcastFile.reloadConfig();
      this.loadConfig();
   }

   public void removeBroadcast(String key) {
      if (this.broadcasts.containsKey(key)) {
         this.broadcasts.remove(key);
         FileConfiguration config = this.autoBroadcastFile.getConfig();
         config.set("broadcasts." + key, (Object)null);
         this.autoBroadcastFile.saveConfig();
         this.loadConfig();
      }

   }

   public void addBroadcast(String key, boolean enabled, List<String> messages, boolean titleEnabled, String title, String subtitle, boolean soundEnabled, String sound, boolean particlesEnabled, String particle, int particleCount, boolean actionbarEnabled, String actionbar, String channel, String permission) {
      AutoBroadcastManager.Broadcast broadcast = new AutoBroadcastManager.Broadcast(enabled, messages, titleEnabled, title, subtitle, soundEnabled, sound, particlesEnabled, particle, particleCount, actionbarEnabled, actionbar, channel, permission);
      this.broadcasts.put(key, broadcast);
      FileConfiguration config = this.autoBroadcastFile.getConfig();
      config.set("broadcasts." + key + ".enabled", enabled);
      config.set("broadcasts." + key + ".message", messages);
      config.set("broadcasts." + key + ".actions.title.enabled", titleEnabled);
      config.set("broadcasts." + key + ".actions.title.title", title);
      config.set("broadcasts." + key + ".actions.title.subtitle", subtitle);
      config.set("broadcasts." + key + ".actions.sound.enabled", soundEnabled);
      config.set("broadcasts." + key + ".actions.sound.sound", sound);
      config.set("broadcasts." + key + ".actions.particles.enabled", particlesEnabled);
      config.set("broadcasts." + key + ".actions.particles.particle", particle);
      config.set("broadcasts." + key + ".actions.particles.particles", particleCount);
      config.set("broadcasts." + key + ".actions.actionbar.enabled", actionbarEnabled);
      config.set("broadcasts." + key + ".actions.actionbar.bar", actionbar);
      config.set("broadcasts." + key + ".channel", channel);
      this.autoBroadcastFile.saveConfig();
      this.loadConfig();
   }

   public int getTime() {
      return this.time;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public Map<String, AutoBroadcastManager.Broadcast> getBroadcasts() {
      return this.broadcasts;
   }

   public boolean togglePlayerBroadcast(@NotNull Player player) {
      UUID playerUUID = player.getUniqueId();
      if (this.toggledPlayers.contains(playerUUID)) {
         this.toggledPlayers.remove(playerUUID);
         return false;
      } else {
         this.toggledPlayers.add(playerUUID);
         return true;
      }
   }

   public boolean isPlayerToggled(@NotNull Player player) {
      return this.toggledPlayers.contains(player.getUniqueId());
   }

   public static record Broadcast(boolean enabled, List<String> message, boolean titleEnabled, String title, String subtitle, boolean soundEnabled, String sound, boolean particlesEnabled, String particle, int particleCount, boolean actionbarEnabled, String actionbar, String channel, String permission) {
      public Broadcast(boolean enabled, List<String> message, boolean titleEnabled, String title, String subtitle, boolean soundEnabled, String sound, boolean particlesEnabled, String particle, int particleCount, boolean actionbarEnabled, String actionbar, String channel, String permission) {
         this.enabled = enabled;
         this.message = message;
         this.titleEnabled = titleEnabled;
         this.title = title;
         this.subtitle = subtitle;
         this.soundEnabled = soundEnabled;
         this.sound = sound;
         this.particlesEnabled = particlesEnabled;
         this.particle = particle;
         this.particleCount = particleCount;
         this.actionbarEnabled = actionbarEnabled;
         this.actionbar = actionbar;
         this.channel = channel;
         this.permission = permission;
      }

      public boolean enabled() {
         return this.enabled;
      }

      public List<String> message() {
         return this.message;
      }

      public boolean titleEnabled() {
         return this.titleEnabled;
      }

      public String title() {
         return this.title;
      }

      public String subtitle() {
         return this.subtitle;
      }

      public boolean soundEnabled() {
         return this.soundEnabled;
      }

      public String sound() {
         return this.sound;
      }

      public boolean particlesEnabled() {
         return this.particlesEnabled;
      }

      public String particle() {
         return this.particle;
      }

      public int particleCount() {
         return this.particleCount;
      }

      public boolean actionbarEnabled() {
         return this.actionbarEnabled;
      }

      public String actionbar() {
         return this.actionbar;
      }

      public String channel() {
         return this.channel;
      }

      public String permission() {
         return this.permission;
      }
   }
}
