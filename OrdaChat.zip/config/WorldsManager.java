package config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import minealex.tchat.OrdaChat;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class WorldsManager {
   private final ConfigFile configFile;
   private final Map<String, WorldsManager.WorldConfigData> worldsConfig;
   private final Map<String, WorldsManager.BridgeConfigData> bridgesConfig;

   public WorldsManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("worlds.yml", (String)null, plugin);
      this.configFile.registerConfig();
      this.worldsConfig = new HashMap();
      this.bridgesConfig = new HashMap();
      this.loadConfig();
   }

   private void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.worldsConfig.clear();
      this.bridgesConfig.clear();
      Iterator var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("worlds"))).getKeys(false).iterator();

      String bridgeName;
      boolean enabled;
      while(var2.hasNext()) {
         bridgeName = (String)var2.next();
         enabled = config.getBoolean("worlds." + bridgeName + ".chat-enabled");
         boolean pwc = config.getBoolean("worlds." + bridgeName + ".pwc");
         boolean chatrEnabled = config.getBoolean("worlds." + bridgeName + ".chat-radius.enabled");
         int chatr = config.getInt("worlds." + bridgeName + ".chat-radius.radius");
         String bcchatr = config.getString("worlds." + bridgeName + ".chat-radius.bypass.char", "!");
         String bpGlobal = config.getString("worlds." + bridgeName + ".chat-radius.bypass.prefixes.global", "&7[&6Global&7]");
         String bpLocal = config.getString("worlds." + bridgeName + ".chat-radius.bypass.prefixes.local", "&7[&9Local&7]");
         String bpNone = config.getString("worlds." + bridgeName + ".chat-radius.bypass.prefixes.none", "");
         this.worldsConfig.put(bridgeName, new WorldsManager.WorldConfigData(enabled, pwc, chatrEnabled, chatr, bcchatr, bpGlobal, bpLocal, bpNone));
      }

      var2 = ((ConfigurationSection)Objects.requireNonNull(config.getConfigurationSection("bridges"))).getKeys(false).iterator();

      while(var2.hasNext()) {
         bridgeName = (String)var2.next();
         enabled = config.getBoolean("bridges." + bridgeName + ".enabled");
         List<String> worlds = config.getStringList("bridges." + bridgeName + ".worlds");
         this.bridgesConfig.put(bridgeName, new WorldsManager.BridgeConfigData(enabled, worlds));
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public Map<String, WorldsManager.WorldConfigData> getWorldsConfig() {
      return this.worldsConfig;
   }

   public Map<String, WorldsManager.BridgeConfigData> getBridgesConfig() {
      return this.bridgesConfig;
   }

   public static record WorldConfigData(boolean chatEnabled, boolean pwc, boolean chatrEnabled, int chatr, String bcchatr, String bpGlobal, String bpLocal, String bpNone) {
      public WorldConfigData(boolean chatEnabled, boolean pwc, boolean chatrEnabled, int chatr, String bcchatr, String bpGlobal, String bpLocal, String bpNone) {
         this.chatEnabled = chatEnabled;
         this.pwc = pwc;
         this.chatrEnabled = chatrEnabled;
         this.chatr = chatr;
         this.bcchatr = bcchatr;
         this.bpGlobal = bpGlobal;
         this.bpLocal = bpLocal;
         this.bpNone = bpNone;
      }

      public boolean chatEnabled() {
         return this.chatEnabled;
      }

      public boolean pwc() {
         return this.pwc;
      }

      public boolean chatrEnabled() {
         return this.chatrEnabled;
      }

      public int chatr() {
         return this.chatr;
      }

      public String bcchatr() {
         return this.bcchatr;
      }

      public String bpGlobal() {
         return this.bpGlobal;
      }

      public String bpLocal() {
         return this.bpLocal;
      }

      public String bpNone() {
         return this.bpNone;
      }
   }

   public static record BridgeConfigData(boolean enabled, List<String> worlds) {
      public BridgeConfigData(boolean enabled, List<String> worlds) {
         this.enabled = enabled;
         this.worlds = worlds;
      }

      public boolean enabled() {
         return this.enabled;
      }

      public List<String> worlds() {
         return this.worlds;
      }
   }
}
