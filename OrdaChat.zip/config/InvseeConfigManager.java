package config;

import minealex.tchat.OrdaChat;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class InvseeConfigManager {
   private final ConfigFile configFile;
   private String inventoryTitle;
   private ItemStack barrier;
   private ItemStack glass;
   private int armorStartSlot;
   private int armorLength;
   private int offhandSlot;
   private int[] glassSlots;
   private int slots;
   private boolean enabled;

   public InvseeConfigManager(OrdaChat plugin) {
      this.configFile = new ConfigFile("invsee.yml", "menus", plugin);
      this.configFile.registerConfig();
      this.loadConfig();
   }

   public void loadConfig() {
      FileConfiguration config = this.configFile.getConfig();
      this.enabled = config.getBoolean("options.enabled", false);
      if (this.enabled) {
         this.inventoryTitle = config.getString("options.title", "&7%player%'s inventory");
         this.slots = config.getInt("options.slots", 45);
         String barrierMaterialName = config.getString("empty.material", "BARRIER");
         Material barrierMaterial = Material.matchMaterial(barrierMaterialName);

         assert barrierMaterial != null;

         this.barrier = new ItemStack(barrierMaterial);
         ItemMeta barrierMeta = this.barrier.getItemMeta();
         if (barrierMeta != null) {
            barrierMeta.setDisplayName(config.getString("empty.name", "&cEmpty"));
            this.barrier.setItemMeta(barrierMeta);
         }

         String glassMaterialName = config.getString("glass.material", "GRAY_STAINED_GLASS_PANE");
         Material glassMaterial = Material.matchMaterial(glassMaterialName);

         assert glassMaterial != null;

         this.glass = new ItemStack(glassMaterial);
         ItemMeta glassMeta = this.glass.getItemMeta();
         if (glassMeta != null) {
            glassMeta.setDisplayName(config.getString("glass.name", " "));
            this.glass.setItemMeta(glassMeta);
         }

         this.armorStartSlot = config.getInt("armor-slots.start", 41);
         this.armorLength = config.getInt("armor-slots.length", 4);
         this.offhandSlot = config.getInt("offhand-slot", 36);
         this.glassSlots = config.getIntegerList("glass-slots").stream().mapToInt(Integer::intValue).toArray();
      }

   }

   public void reloadConfig() {
      this.configFile.reloadConfig();
      this.loadConfig();
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getInventoryTitle() {
      return this.inventoryTitle;
   }

   public ItemStack getBarrier() {
      return this.barrier;
   }

   public ItemStack getGlass() {
      return this.glass;
   }

   public int getArmorStartSlot() {
      return this.armorStartSlot;
   }

   public int getArmorLength() {
      return this.armorLength;
   }

   public int getOffhandSlot() {
      return this.offhandSlot;
   }

   public int[] getGlassSlots() {
      return this.glassSlots;
   }

   public int getSlots() {
      return this.slots;
   }
}
