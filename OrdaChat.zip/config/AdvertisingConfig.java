package config;

import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;
import org.jetbrains.annotations.NotNull;

public class AdvertisingConfig {
   private final boolean enabled;
   private final List<String> whitelist;
   private String match;
   private boolean messageEnabled;
   private List<String> message;
   private boolean titleEnabled;
   private String title;
   private String subtitle;
   private boolean actionBarEnabled;
   private String actionBar;
   private boolean soundEnabled;
   private String sound;
   private boolean particlesEnabled;
   private String particleType;
   private int particles;
   private float soundPitch;
   private float soundVolume;
   private int titleFadeIn;
   private int titleStay;
   private int titleFadeOut;

   public AdvertisingConfig(@NotNull FileConfiguration config, String basePath) {
      this.enabled = config.getBoolean(basePath + ".enabled");
      this.whitelist = config.getStringList("advertising.whitelist");
      if (this.enabled) {
         this.match = config.getString(basePath + ".match");
         this.messageEnabled = config.getBoolean(basePath + ".actions.message.enabled");
         if (this.messageEnabled) {
            this.message = config.getStringList(basePath + ".actions.message.message");
         }

         this.titleEnabled = config.getBoolean(basePath + ".actions.title.enabled");
         if (this.titleEnabled) {
            this.title = config.getString(basePath + ".actions.title.title");
            this.subtitle = config.getString(basePath + ".actions.title.subtitle");
            this.titleFadeIn = config.getInt(basePath + ".actions.title.fade-in");
            this.titleStay = config.getInt(basePath + ".actions.title.stay");
            this.titleFadeOut = config.getInt(basePath + ".actions.title.fade-out");
         }

         this.actionBarEnabled = config.getBoolean(basePath + ".actions.actionbar.enabled");
         if (this.actionBarEnabled) {
            this.actionBar = config.getString(basePath + ".actions.actionbar.bar");
         }

         this.soundEnabled = config.getBoolean(basePath + ".actions.sound.enabled");
         if (this.soundEnabled) {
            this.sound = config.getString(basePath + ".actions.sound.sound");
            this.soundPitch = (float)config.getDouble(basePath + ".actions.sound.pitch");
            this.soundVolume = (float)config.getDouble(basePath + ".actions.sound.volume");
         }

         this.particlesEnabled = config.getBoolean(basePath + ".actions.particles.enabled");
         if (this.particlesEnabled) {
            this.particleType = config.getString(basePath + ".actions.particles.type");
            this.particles = config.getInt(basePath + ".actions.particles.particles");
         }
      }

   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public List<String> getWhitelist() {
      return this.whitelist;
   }

   public String getMatch() {
      return this.match;
   }

   public boolean isMessageEnabled() {
      return this.messageEnabled;
   }

   public List<String> getMessage() {
      return this.message;
   }

   public boolean isTitleEnabled() {
      return this.titleEnabled;
   }

   public String getTitle() {
      return this.title;
   }

   public String getSubtitle() {
      return this.subtitle;
   }

   public boolean isActionBarEnabled() {
      return this.actionBarEnabled;
   }

   public String getActionBar() {
      return this.actionBar;
   }

   public boolean isSoundEnabled() {
      return this.soundEnabled;
   }

   public String getSound() {
      return this.sound;
   }

   public boolean isParticlesEnabled() {
      return this.particlesEnabled;
   }

   public String getParticleType() {
      return this.particleType;
   }

   public int getParticles() {
      return this.particles;
   }

   public float getSoundPitch() {
      return this.soundPitch;
   }

   public float getSoundVolume() {
      return this.soundVolume;
   }

   public int getTitleFadeIn() {
      return this.titleFadeIn;
   }

   public int getTitleStay() {
      return this.titleStay;
   }

   public int getTitleFadeOut() {
      return this.titleFadeOut;
   }
}
